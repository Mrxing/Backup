/*************************************************************************
	> File Name: for99.c
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Tue 29 Oct 2013 02:20:50 PM CST
 ************************************************************************/

#include<stdio.h>

int main(void)
{
	int i,j;
	int mul;
	for(i=1;i<=9;i++)
	{
		for(j=1;j<=i;j++)
		{
			mul = j*i;
			printf("%d*%d=%d\t",j,i,mul);
		}
		printf("\n");
	}
	return 0;
}
