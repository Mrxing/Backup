/*************************************************************************
	> File Name: searchInsert.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Thu 31 Oct 2013 03:54:18 PM CST
 ************************************************************************/

/*
	需求：给定一个元素查看在指定数组中的位置，如果不存在，要插入到数组的话，指出要插入的位置
	思路：如果数组是有序的话，利用二分查找法尝试找到所在的位置，没有的话指出要插入的位置
	方法：二分查找法
*/


class searchInsert
{
	public static void main(String[] args)
	{
		int[] arr = {3,7,27,33,56,78,89,99};
		int index = halfSearch(arr,90);
		System.out.println("index="+index);
	}

	/*
		二分查找法，找出插入元素的位置
	*/
	public static int halfSearch(int[] arr, int key)
	{
		int min, mid, max;
		min = 0;
		max = arr.length - 1;
		while(min < max)
		{
			mid = (min + max) >> 1;
			if(key > arr[mid])
				min = mid + 1;
			else if(key < arr[mid])
				max = mid - 1;
			else 
				return mid;
		}
		return min;
	}
}
