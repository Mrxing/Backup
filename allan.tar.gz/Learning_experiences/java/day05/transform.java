/*************************************************************************
	> File Name: transform.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Thu 31 Oct 2013 04:05:36 PM CST
 ************************************************************************/

/*
	需求：实现十进制向十六进制、八进制、二进制的转换
	思路：十进制数据在计算机中实际的存储方式为三十二位二进制方式，如0000 0000 0000 0000 0000 0110-->6  十六进制是以每四位二进制为以为计算的，
		  分别对每四位计算得到十六进制数据
	方法：移位运算
*/

class transform
{
	public static void main(String[] args)
	{
		toHex(60);
		toOctal(60);
		toBinary(6);
	}

	/*
		十进制转十六进制

	*/
	public static void toHex(int num)
	{
		System.out.print(num+" 的十六进制是: ");
		trans(num,15,4);
	}

	/*
		十进制转八进制
	*/
	public static void toOctal(int num)
	{
		System.out.print(num+" 的八进制是: ");
		trans(num,7,3);
	}
	
	/*
		十进制转二进制
	*/
	public static void toBinary(int num)
	{
		System.out.print(num+" 的二进制是: ");
		trans(num,1,1);
	}

	public static void trans(int num, int base, int offset)
	{
		/*
			通过查表法对应输出数据，建立关系表
		*/
		char[] chs = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

		char[] chr = new char[8];
		int pos = chr.length;
	
		while(num != 0)
		{
			int temp = num & base;
			chr[--pos] = chs[temp];
			num = num >>> offset;
		}
		for(int x = pos; x < chr.length; x++)
		{
			System.out.print(chr[x]);
		}
		System.out.println();
	}
}
