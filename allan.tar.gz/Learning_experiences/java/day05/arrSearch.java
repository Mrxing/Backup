/*************************************************************************
	> File Name: arrSearch.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Thu 31 Oct 2013 03:19:27 PM CST
 ************************************************************************/

/*
	需求：查找某个指定的元素是否在指定数组中，在哪个位置
	思路：比对数组元素与指定元素，然后找到其对应的角标
	方法：1、标准查找法
		  2、二分查找（一般只用于数组有序）
*/

class arrSearch
{
	public static void main(String[] args)
	{
		int[] arr = {2,4,54,6,36,48,66};
		int index = standSearch(arr,8);
		int index1 = halfSearch(arr,8);
		System.out.println("index="+index);
		System.out.println("index1="+index1);
	}

	/*
		标准查找方法
	*/
	public static int standSearch(int[] arr, int key)
	{
		for(int x = 0; x < arr.length; x++)
		{
			if(key == arr[x])
			return x;
		}
		return -1;
	}

	/*
		二分查找
	*/
	public static int halfSearch(int[] arr, int key)
	{
		int min,mid,max;
		min = 0;
		max = arr.length - 1;
		while(min < max)
		{
			mid = (min+max)/2;
			if(key > arr[mid])
				min = mid + 1;
			else if(key < arr[mid])
				max = mid - 1;
			else
				return mid;
		}
		return -1;
	}


}















