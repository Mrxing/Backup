 /*************************************************************************
	> File Name: ArraySort.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Thu 31 Oct 2013 09:12:47 AM CST
 ************************************************************************/

class ArraySort
{
	public static void main(String[] args)
	{
		int[] arr= {2,44,35,29,87,56,74,65,92};
		System.out.print("排序前： ");
		MyPrint(arr);
		// SelectSort(arr);
		dubbleSort(arr);
		System.out.print("排序后： ");
		MyPrint(arr);

	}

	/*
		选择排序
	*/
	public static void SelectSort(int[] arr)
	{
		for(int x = 0; x < arr.length - 1; x++)
		{
			for(int y = x + 1; y < arr.length; y++)
			{
				if(arr[x] > arr[y])
					swap(arr,x,y);
			}
		}
	}

	/*
		冒泡排序
	*/
	public static void dubbleSort(int[] arr)
	{
		for(int x = 0; x < arr.length -1; x++)
		{
			for(int y = 0; y < arr.length - x - 1; y++)
			{
				if(arr[y] > arr[y+1])
					swap(arr, y, y+1);
			}
		}
	}

	/*
		交换功能
	*/
	public static void swap(int[] arr, int a, int b)
	{
		int temp = arr[a];
		arr[a] = arr[b];
		arr[b] = temp;
	}

	/*
		遍历打印
	*/
	public static void MyPrint(int[] arr)
	{
		System.out.print("[ ");
		for(int x = 0; x < arr.length; x++)
		{
			if(x != arr.length - 1)
			{
				System.out.print(arr[x] + ",");
			}
			else
			{
				System.out.print(arr[x] + " ]");
			}
		}
		System.out.println();
	}




}
