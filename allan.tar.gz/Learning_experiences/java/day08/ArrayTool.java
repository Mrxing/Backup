/*************************************************************************
	> File Name: ArrayTool.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Mon 04 Nov 2013 01:55:19 PM CST
 ************************************************************************/

/**
	该类实现数组的基本操作的工具， 如获取最大值，排序，查找等
	@author Allan
	@version v1.0
*/


public class ArrayTool
{

	private ArrayTool(){}//该工具类中的方法都是静态的，不需要再创建对象，为保证其他程序不会为该类创建对象，将构造函数稀有化
	/**
		获取数组中的最大值
		@param arr 传入的数组
		@return 返回最大值
	*/
	public static int getMax(int[] arr)
	{
		int maxindex = 0;
		for(int x = 0; x < arr.length; x++)
		{
			if(arr[x] > arr[maxindex])
			{
				maxindex = x;
			}
		}
		return arr[maxindex];
	}

	/**
		找出给定元素在数组中的位置
		@param arr 传入的指定数组 key 要查找的元素的值
		@return 返回元素所在数组的索引
	*/
	public static int getIndex(int[] arr, int key)
	{
		for(int x = 0; x < arr.length; x++)
		{
			if(arr[x] == key)
			{
				return x;
			}
		}
		return -1;
	}

	/**
		将给定的数组进行排序（升）
		@param arr 传入的指定数组
	*/
	public static void selectSort(int[] arr)
	{
		for(int x = 0; x < arr.length - 1; x++)
		{
			for( int y = x+1; y < arr.length; y++)
			{
				if(arr[x] > arr[y])
					swap(arr,x,y);
			}
		}
	}
	/**
		将数组以字符串的形式显示出来
		@param arr 传入的指定数组
		@return 以字符串形式将数组返回
	*/
	public static String arraytoString(int[] arr)
	{
		String str = "[";
		for(int x = 0; x < arr.length; x++)
		{
			if(x != arr.length - 1)
			{
				str = str + arr[x] + ",";
			}
			else
			{
				str = str + arr[x] + "]";
			}
		}
		return str;
	}
	/*
		用于数组内位置的置换
	*/
	private static void swap(int[] arr, int a, int b)
	{
		int temp = arr[a];
		arr[a] = arr[b];
		arr[b] = temp;
	}

}


















