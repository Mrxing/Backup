
/*
	覆盖：当子类中出现成员函数一模一样的情况，会运行子类的函数

	什么时候使用覆盖操作呢？
	1.当对一个类进行扩展时，子类需要保留父类的功能声明，但是要定义子类该功能特有内容时，就需要使用覆盖.
*/

class ExtendsTest
{
	public static void main(String[] args) {
		NewPhone p = new NewPhone();
		p.show();
	}
	
}

class Phone
{
	void call()
	{
		System.out.println("take a call!");
	}
	void show()
	{
		System.out.println("number");
	}
}

class NewPhone extends Phone
{
	void show()
	{
		System.out.println("name");
		System.out.println("picture");
		super.show();
	}
}

