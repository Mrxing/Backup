/*************************************************************************
	> File Name: ArrayToolTest.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Tue 05 Nov 2013 10:07:23 AM CST
 ************************************************************************/

class ArrayToolTest
{
	public static void main(String[] args)
	{
		int[] arr = {7,2,8,3,45,1,56};
		int max = ArrayTool.getMax(arr);
		System.out.println("max="+max);
		String s1 = ArrayTool.arraytoString(arr);
		System.out.println("before sort:"+s1);
		ArrayTool.selectSort(arr);
		String s2 = ArrayTool.arraytoString(arr);
		System.out.println("after sort:"+s2);
	}
}
