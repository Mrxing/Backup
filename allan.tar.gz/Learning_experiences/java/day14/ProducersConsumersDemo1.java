import java.util.concurrent.locks.*;

class Resources1
{
	private String name;
	private int count = 1;
	private boolean flag = false;

	Lock lock = new ReentrantLock();
	Condition Pros_con = lock.newCondition();
	Condition Cons_con = lock.newCondition();

	public void set(String name)
	{
		lock.lock();
		try{
			while(flag)
				try{Pros_con.await();}catch(InterruptedException e){}
				this.name = name + count;
				System.out.println(Thread.currentThread().getName()+"....Producers...."+ this.name);
				count++;
				flag = true;
				Cons_con.signal();
		}
		finally
		{
			lock.unlock();
		}
	}
	public void	out()
	{
		lock.lock();
		try{
			while(!flag)
				try{Cons_con.await();}catch(InterruptedException e){}
				System.out.println(Thread.currentThread().getName()+"....Consumers........"+ this.name);
				flag = false;
				Pros_con.signal();
		}
		finally
		{
			lock.unlock();
		}
	}
}

class Producers1 implements Runnable
{
	private Resources1 r;
	Producers1(Resources1 r)
	{
		this.r = r;
	}

	public void run()
	{
		while(true)
			r.set("烤鸭");
	}
}

class Consumers1 implements Runnable
{
	private Resources1 r;
	Consumers1(Resources1 r)
	{
		this.r = r;
	}

	public void run()
	{
		while(true)
			r.out();
	}
}

class ProducersConsmersDemo1
{
	public static void main(String[] args) {
		Resources1 r = new Resources1();

		Producers1 ps1 = new Producers1(r);
		Consumers1 cs1 = new Consumers1(r);

		Thread t0 = new Thread(ps1);
		Thread t1 = new Thread(ps1);
		Thread t2 = new Thread(cs1);
		Thread t3 = new Thread(cs1);

		t0.start();
		t1.start();
		t2.start();
		t3.start();
	}
}