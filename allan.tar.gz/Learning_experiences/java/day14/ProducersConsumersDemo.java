/*
	多生产，多消费
*/

class Resources
{
	private String name;
	private int count = 1;
	private boolean flag = false;

	public synchronized void set(String name)
	{
		while(flag)
			try{this.wait();}catch(InterruptedException e){}
		this.name = name + count;
		System.out.println(Thread.currentThread().getName()+"...Producers..."+ this.name);
		count++;
		flag = true;
		notifyAll();//唤醒全部
	}

	public synchronized void out()
	{
		while(!flag)
			try{this.wait();}catch(InterruptedException e){}
		System.out.println(Thread.currentThread().getName()+"...Consumers......"+ this.name);
		flag = false;
		notifyAll();
	}
}

class Producers implements Runnable
{
	private Resources r;
	Producers(Resources r)
	{
		this.r = r;
	}

	public void run()
	{
		while(true)
		{
			r.set("烤鸭");
		}
	}
}	

class Consumers implements Runnable
{
	private Resources r;
	Consumers(Resources r)
	{
		this.r = r;
	}

	public void run()
	{
		while(true)
		{
			r.out();
		}
	}
}

class ProducersConsumersDemo
{
	public static void main(String[] args) {
		Resources r = new Resources();

		Producers ps = new Producers(r);
		Consumers cs = new Consumers(r);

		Thread t0 = new Thread(ps);
		Thread t1 = new Thread(ps);
		Thread t2 = new Thread(cs);
		Thread t3 = new Thread(cs);

		t0.start();
		t1.start();
		t2.start();
		t3.start();
	}
}