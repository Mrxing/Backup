/*************************************************************************
	> File Name: ForForTest2.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Tue 29 Oct 2013 02:39:56 PM CST
 ************************************************************************/

/*
	需求：打印下面图形
		* * * * *
		 * * * * 
		  * * * 
		   * * 
		    *
*/

class ForForTest2
{
	public static void main(String[] args)
	{
		for(int x=1;x<=5;x++)
		{
			for(int y=1; y<x;y++)
			{
				System.out.print(" ");
			}
			for(int z=x; z<=5;z++)
			{
				System.out.print("* ");
			}
			System.out.println();
		}
	}
}
