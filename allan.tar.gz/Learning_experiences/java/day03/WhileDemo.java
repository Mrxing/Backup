/*************************************************************************
	> File Name: WhileDemo.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Tue 29 Oct 2013 09:34:01 AM CST
 ************************************************************************/
/*
	需求：1～100之间6的倍数出现的次数。

 */
 //计数器思想
class WhileDemo
{
	public static void main(String[] args)
	{
		int count = 0;
		int i = 1;
		while(i <= 100)
		{
			if(i % 6 == 0)
			{
				count++;
			}
			i++;
		}
		System.out.println("count="+count);
	}
}

