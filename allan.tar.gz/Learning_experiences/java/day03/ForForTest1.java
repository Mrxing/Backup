/*************************************************************************
	> File Name: ForForTest1.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Tue 29 Oct 2013 10:35:52 AM CST
 ************************************************************************/

/*
	需求：在终端打印如下图形：
		*****
		****
		***
		**
		*
*/

class ForForTest1
{
	public static void main(String[] args)
	{
	/*
		int z = 5;
		for(int x = 0; x < 5; x++)
		{
			for(int y = 1; y <= z; y++)
			{
				System.out.print("*");
			}
			System.out.println();
			z--;
		}
	*/
		for(int x =1; x <=5; x++)
		{
			for(int y=x; y <= 5; y++)
			{
				System.out.print("*");
			}
			System.out.println();
		}

		System.out.println("-------------------");
		/*
			*
			**
			***
			****
			*****
		*/
		for(int x = 1; x <= 5; x++)
		{
			for(int y = 1; y <= x; y++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("-------------------");
		/*
			54321
			5432
			543
			54
			5
		*/
		for(int x = 5; x > 0; x--)
		{
			for(int y = x; y > 0; y--)
			{
				System.out.print(y);
			}
			System.out.println();
		}

		System.out.println("-------------------");
		/*
			1
			12
			123
			1234
			12345
		*/

		for(int x = 1; x <=5; x++)
		{
			for(int y = 1; y <= x; y++)
			{
				System.out.print(y);
			}
			System.out.println();
		}

		System.out.println("-------------------");
		/*
			1
			22
			333
			4444
			55555
		*/
		for(int x = 1; x <= 5; x++)
		{
			for(int y = 1; y <= x; y++)
			{
				System.out.print(x);
			}
			System.out.println();
		}
	}
}






