/*************************************************************************
	> File Name: ForTest.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Tue 29 Oct 2013 10:00:16 AM CST
 ************************************************************************/
/*
	用For完成累加（1～100）。
*/

class ForTest
{
	public static void main(String[] args)
	{
		int sum = 0;
		int mul = 1;
		for( int i = 1; i <= 10; i++)
		{
			sum += i;
			mul *= i;
		}
		System.out.println("sum="+sum);
		System.out.println("mul="+mul);
	}
}
