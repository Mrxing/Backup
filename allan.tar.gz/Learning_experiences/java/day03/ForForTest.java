/*************************************************************************
	> File Name: ForForTest.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Tue 29 Oct 2013 10:23:57 AM CST
 ************************************************************************/
/*
	需求：打印下面图形到终端
	*****
	*****
	*****
	*****
*/

class ForForTest
{
	public static void main(String[] args)
	{
		for(int x = 0; x < 4; x++)
		{
			for(int y = 0; y < 5; y++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}
}




