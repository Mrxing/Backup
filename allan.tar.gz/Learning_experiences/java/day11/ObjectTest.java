/*
	Object类相关方法的应用
	equals()  hashCode()   toString()
	一般都会进行重写操作
*/

class Person
{
	private String name;
	private int age;
	Person(int age)
	{
		this.age = age;
	}
	public void show()
	{
		System.out.println("I am a Person");
	}

	public boolean equals(Object obj)
	{
		if (!(obj instanceof Person)) {
			return false;
		}
		Person p = (Person)obj;
		return this.age == p.age;
	}

	public int hashcode()
	{
		return this.age;
	}

	public String toString()
	{
		// return getClass().getName() + "$" + Integer.toHexString(hashcode());
		// return "Person :" + Integer.toHexString(age); 
		return "Person :" + age; 
	}
}

class ObjectTest
{
	public static void main(String[] args) {
		Person p1 = new Person(20);
		Person p2 = new Person(60);
		//equals
		// Demo d = new Demo();
		System.out.println(p1 == p2);
		System.out.println(p1.equals(p2));
		// System.out.println(p1.equals(d));

		//hashcode
		System.out.println(p1);
		System.out.println(p1.hashcode());

		//toString
		System.out.println(p2.toString());

	}
}

class Demo
{

}