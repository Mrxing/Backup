/*
	异常的声明处理
*/

class FushuException extends Exception
{
	FushuException()
	{}
	FushuException(String msg)
	{
		super(msg);
	}
}

class Demo
{
	public void method(int[] arr, int index) throws FushuException
	{
		
		if (arr == null) {
			throw new NullPointerException("数组不能为空");
		}
		if (index >= arr.length) {
			throw new ArrayIndexOutOfBoundsException("数组引用越界: " + index);
		}
		if (index < 0) {
			throw new FushuException("角标不能为负数: " + index);
		}
		System.out.println(arr[index]);
	}
}

class ExceptionDemo
{
	public static void main(String[] args) throws FushuException{

		int[] arr = new int[3];
		Demo d = new Demo();
		d.method(null,30);
	}
}