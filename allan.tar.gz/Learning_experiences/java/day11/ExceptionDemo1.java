/*
	异常的捕获处理
*/


class FushuException extends Exception
{
	FushuException()
	{}
	FushuException(String msg)
	{
		super(msg);
	}
}

class Demo
{
	public int method(int[] arr, int index) throws FushuException,NullPointerException
	{
		
		if (arr == null) {
			throw new NullPointerException("数组为空，非法");
		}
		// if (index >= arr.length) {
		// 	throw new ArrayIndexOutOfBoundsException("数组引用越界: " + index);
		// }
		if (index < 0) {
			throw new FushuException("角标不能为负数: " + index);
		}
		return arr[index];
	}
}

class ExceptionDemo1
{
	public static void main(String[] args) {

		int[] arr = new int[3];
		Demo d = new Demo();
		try{
			int num = d.method(null,-2);
			System.out.println("num" + num);
		}
		catch(NullPointerException e)
		{
			System.out.println(e.toString());
			// System.out.println("数组为空，非法");
		}
		catch(FushuException e)
		{
			System.out.println(e.toString());
			// System.out.println("数组角标为负数了，请更正！");
		}
		finally
		{
			System.out.println("over");
		}

	}
}