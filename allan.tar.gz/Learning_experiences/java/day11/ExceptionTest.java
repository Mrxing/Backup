/*
	需求：某公司程序员编程

	对象：程序员，电脑
	异常：1.蓝屏
		 处理：程序员重启电脑，继续编程
		 2. 电脑坏了，无法开机
		 处理：异常程序员无法处理，不处理或者交给调用者（公司）去送修
*/

class LanPingException extends Exception
{
	LanPingException(String msg)
	{
		super(msg);
	}
}
class BreakException extends Exception
{
	BreakException(String msg)
	{
		super(msg);
	}
}
class RepairException extends Exception
{
	RepairException(String msg)
	{
		super(msg);
	}
}

class Computer
{
	private int state = 0;
	public void run() throws LanPingException,BreakException
	{
		System.out.println("Computer running");
		if (state == 1) {
			throw new LanPingException("Lanping");
		}
		if (state == 2) {
			throw new BreakException("Computer Breaked");
		}
	}
	public	void reset()
	{
		System.out.println("Computer reset");
	}
}

class Programmer
{
	private String name;
	private Computer comp;
	public void Coding() throws RepairException
	{
		comp = new Computer();
		try{
			comp.run();
			System.out.println("Programmer Coding");			
		}
		catch(LanPingException e)
		{
			System.out.println(e.toString());
			comp.reset();
			System.out.println("Programmer Coding");
		}
		catch(BreakException e)
		{
			throw new RepairException("Computer is breaked,Take it to Repair");
		}
	}
}

class ExceptionTest
{
	public static void main(String[] args) {
		Programmer p = new Programmer();
		try{
			p.Coding();
		}
		catch(RepairException r)
		{
			System.out.println(r.toString());
			System.out.println("Computer is Repairing");
		}
	}
}











