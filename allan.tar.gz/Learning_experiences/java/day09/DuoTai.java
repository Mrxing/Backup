
/*
	多态：就是一个对象对应着不同类型

	好处：提高了代码的扩展性，前期定义的代码可以使用后期的内容

	弊端：前期内容无法使用后期特有的功能

	前提：1.必须有关系，继承，实现
		 2.要有覆盖

	转型：向上转型，自动类型提升，可以限制特有功能的访问
		 向下转型，为了使用子类中的特有功能
*/

abstract class Animal
{
	abstract void eat();
}

class Cat extends Animal
{
	void eat()
	{
		System.out.println("Cat eat mouse");
	}
	void catchMouse()
	{
		System.out.println("catchMouse");
	}
}

class Dog extends Animal
{
	void eat()
	{
		System.out.println("Dog eat bone");
	}
	void watchHome()
	{
		System.out.println("Dog watchHome");
	}
}

class DuoTai
{
	public static void main(String[] args) {
		Animal c = new Cat(); //提高了代码的扩展性
		Animal d = new Dog();

		method(c);			 //无法访问子类的特有功能
		method(d);

		// Cat c1 = (Cat)c;
		// c1.catchMouse();	//向下转型，可以访问子类的特有功能
	}

	public static void method(Animal a)
	{
		a.eat();
		if (a instanceof Cat) {
			Cat c = (Cat)a;
			c.catchMouse();
		}
		else if (a instanceof Dog) {
			Dog d = (Dog)a;
			d.watchHome();
		}
	}
}
