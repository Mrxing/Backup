class Fu
{
	int num = 4;
	void show()
	{
		System.out.println("Fu show");
	}
	static void method()
	{
		System.out.println("Fu static method");
	}
}
class Zi extends Fu
{
	int num = 4;
	void show()
	{
	System.out.println("Zi show");
	}

	static void method()
	{
		System.out.println("Zi static method");
	}
}

class DuoTai2
{
	public static void main(String[] args) {
		Fu f = new Zi();
		Zi z = new Zi();
		System.out.println(f.num); //成员变量，调用时不需要依赖对象，编译运行时看左边
		System.out.println(z.num);

		f.method();
		z.method();               //静态函数，可以被类直接调用，所有调用时不需要依赖对象，编译运行时看左边

		Fu	e = new Fu();
		f.show();
		z.show();				//成员函数，调用依赖于对象，编译是看左边是否有对应方法，执行时看右边
		e.show();

	}
}