/*
	需求：某一公司有若干雇员，程序员有名字，工号，薪水，工作内容
	项目经理除了有名字，工号，薪水，工作内容外还有奖金,利用编程
	思想对该公司雇员进行数据建模.

	思路：1.公司有程序员和项目经理两种雇员，可以采用类的方式构建
		 2.虽然他们有一些共同点，但不存在继承关系，将利用向上提取继承

	分析得到：程序员
				属性：名字，工号，薪水
				行为：工作
			项目经理
				属性：名字，工号，薪水，奖金
				行为：工作
*/

//构建雇员
abstract class Employee
{
	private  String name;
	private  String id;
	private  double pay;
	Employee(String name,String id,double pay)
	{
		this.name = name;
		this.id = id;
		this.pay = pay;
	}
	public String getName()
	{
		return name;
	}
	public String getId()
	{
		return id;
	}
	public double getPay()
	{
		return pay;
	}
	public abstract void work();
}

//构建程序员
class Programmer extends Employee
{
	Programmer(String name,String id,double pay)
	{
		super(name,id,pay);
	}
	public void work()
	{
		System.out.println(getName() + "--" + getId() + "--" + getPay());
		System.out.println("coding....");
	}
}

//构建项目经理
class Manager extends Employee
{
	private  int bonus;
	Manager(String name,String id,double pay,int bonus)
	{
		super(name,id,pay);
		this.bonus = bonus;
	}
	public int getBonus()
	{
		return bonus;
	}
	public void work()
	{
		System.out.println(getName() + "--" + getId() + "--" + getPay() + "--" + getBonus());
		System.out.println("Manage....");
	}
}

class AbstractTest
{
	public static void main(String[] args) {
		Programmer p = new Programmer("zhangsan","k1101",3000.0);
		p.work();
		Manager m = new Manager("lisi","k1100",5000.0,1000);
		m.work();
	}
}



