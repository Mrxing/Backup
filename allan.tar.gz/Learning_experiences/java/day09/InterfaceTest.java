/*
	1.接口是对外暴露的规则
	2.接口是程序的功能的扩展
	3.接口的出现降低了耦合性

*/

interface USB
{
	public abstract void open();
	public abstract void close();
}



class BookPc
{
	public static void main(String[] args) {
		useUSB(null);
		useUSB(new UPan());
		useUSB(new UsbMouse());
	}
	public static void useUSB(USB u)
	{
		if (u != null) {
			u.open();
			u.close();
		}
		
	}
}

//出现功能扩展，有USB规则实现的设备出现

class UPan implements USB
{
	public void open()
	{
		System.out.println("UPan open");
	}
	public void close()
	{
		System.out.println("UPan close");
	}
}

class UsbMouse implements USB
{
	public void open()
	{
		System.out.println("UsbMouse open");
	}
	public void close()
	{
		System.out.println("UsbMouse close");
	}
}


