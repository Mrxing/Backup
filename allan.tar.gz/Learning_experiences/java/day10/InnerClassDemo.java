/*
	内部类访问特点：
	1.内部类可以直接访问外部类中的成员
	2.外部类要访问内部类，必须要建立内部类的对象
*/

class Outer
{
	private static int num = 33;
	static class Inner
	{
		void show()
		{
			System.out.println("show run ..."+ num);
		}
		static void function()
		{
			System.out.println("function run ....."+ num);
		}
	}
	public void method()
	{
		System.out.println("method run..." + num);
	}
}

class InnerClassDemo
{
	public static void main(String[] args) {
		Outer out = new Outer();
		out.method();                 //1.外部类访问外部成员

		// Outer.Inner in = new Outer().new Inner(); //2.直接访问外部类中的内部类中的成员
		// in.show();

		// Outer.Inner in = new Outer.Inner(); //3.如果内部类是静态的，相当于一个外部类
		// in.show();

		Outer.Inner.function(); //4.如果内部类是静态的，成员是静态的

	}
}