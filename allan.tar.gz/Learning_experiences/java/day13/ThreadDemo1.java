/*
	线程的创建方式二：实现Runnable接口

	步骤： 1 实现Runnable接口
		  2 覆盖接口中的run方法，将线程任务代码封装到run方法中
		  3 创建Thread线程对象,并将Runnable接口的子类对象作为Thread类的构造函数的参数进行传递。
		  	为什么？
		  	因为线程的任务都封装在Runnable接口子类对象的run方法中，所有要在线程对象创建时就必须明确要运行的任务
		  4 调用线程对象的start方法开启线程
*/

class Person
{
	private String name;
	private int age;
	Person(String name, int age)
	{
		this.name = name;
		this.age = age;
	}

	public String getName()
	{
		return name;
	}

	public void show()
	{
		System.out.println("I am a people");
	}
}

class Student extends Person implements Runnable
{
	Student(String name, int age)
	{
		super(name,age);
	}
	public void run()
	{
		show();
	}
	public void show()
	{
		for (int x = 0; x < 10; x++) {
			System.out.println("I am a student:"+getName()+"\tI studying\t"+getName()+" count:\t"+ x+"...");
		}
		
	}
}

class ThreadDemo1
{
	public static void main(String[] args) {
		// Student s1 = new Student("zhang",19);
		// Student s2 = new Student("song",20);
		Runnable s1 = new Student("zhang",19);
		Runnable s2 = new Student("song",20);

		Thread t1 = new Thread(s1);
		Thread t2 = new Thread(s2);

		t1.start();
		t2.start();

	}
}