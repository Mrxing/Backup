

/*
	需求： 窗口售票
*/

class Tickets implements Runnable
{
	private int num = 10000;

	Object obj = new Object();
	public void run()
	{
		sale();
	}
	public void sale()
	{
		while (true) {
			synchronized(obj){
				if(num > 0){
					try{
						Thread.sleep(10);
					}catch(InterruptedException e){

					}
					System.out.println("Ticket number is: "+ num--+"-----"+Thread.currentThread().getName());
				}
			}
		}
	}
}

class Bank
{
	private int sum;
	//同步函数
	public synchronized void add(int num)
	{
		sum = sum + num;
		try{
			Thread.sleep(10);
		}catch(InterruptedException e){

		}
		System.out.println("sum is :"+sum);
	}
}
class Cus implements Runnable
{
	Bank b = new Bank();
	public void run()
	{
		for (int x = 0; x < 3; x++) {
			b.add(100);
		}
			
	}
}

class TicketDemo
{
	public static void main(String[] args) {
		// Tickets t = new Tickets();

		Cus c = new Cus();
		Thread t1 = new Thread(c);
		Thread t2 = new Thread(c);
		// Thread t3 = new Thread(t);


		t1.start();
		t2.start();
		// t3.start();
	}
}