/*************************************************************************
	> File Name: ArrayDemo.java
	> Author: Allan Xing
	> Mail: Allan_Xing@wistron.com 
	> Created Time: Thu 31 Oct 2013 08:26:21 AM CST
 ************************************************************************/

/*
	需求：实现数组的遍历
*/

class ArrayDemo
{
	public static void main(String[] args)
	{
		int[] arr = {2,23,44,56,43,12,25,88};

		ArrTraverse(arr);
	}

	/*
		遍历数组
	*/

	public static void ArrTraverse(int[] arr)
	{
		System.out.print("[ ");
		for(int x = 0; x < arr.length; x++)
		{
			if(x != arr.length - 1)
			{
				System.out.print(arr[x]+", ");
			}else
				System.out.print(arr[x] + " ]");
		}
		System.out.println();
	}
}
