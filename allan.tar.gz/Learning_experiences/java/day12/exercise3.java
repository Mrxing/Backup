


interface Test
{
	void func();
}
class exercise3
{
	public static void main(String[] args)
	{
		//补足代码；（匿名内部类）调用show方法
		//show方法是非静态的，不能直接调用，采用对象调用
		new exercise3().show(new Test(){
			public void func()
			{
				System.out.println("func run");
			}
		});
		
	}
	void show(Test t)
	{
		t.func();
	}
}