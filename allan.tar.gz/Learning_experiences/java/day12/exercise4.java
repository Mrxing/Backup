/*
	建立一个图形接口，声明一个面积函数。圆形和矩形都实现这个接口，并得出两个图形的面积。
	注：体现面向对象的特征，对数值进行判断。用异常处理。不合法的数值要出现“这个数值是非法的”提示，不再进行运算
*/

interface Areable
{
	double getArea();
}

class NoValue extends RuntimeException
{
	NoValue()
	{

	}
	NoValue(String msg)
	{
		super(msg);
	}
}

class Rectangle implements Areable
{
	private int length;
	private int width;
	Rectangle(int length, int width)
	{
		this.length = length;
		this.width = width;
	}
	public double getArea()
	{
		if (length < 0 || width < 0) {
			throw new NoValue("illlegal value input");
		}
		return length * width;
	}
}

class Circle implements Areable
{
	private double radius;
	private static final double PI = 3.14;
	Circle(double radius )
	{
		this.radius = radius;
	}
	public double getArea()
	{
		if (radius < 0) {
			throw new NoValue("illlegal value input");
		}
		return radius * radius * PI;
	}
}


class exercise4
{
	public static void main(String[] args) {
		Rectangle r = new Rectangle(-3,4);
		double area = r.getArea();
		System.out.println("Rectagle area: " + area);
	}
}