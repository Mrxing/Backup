
/*
	线程创建的步骤：
	1.将类继承于Thread类
	2.覆盖Tread类的run()方法
	3.创建线程子类
	4.运行线程start()
*/

class Lovers extends Thread
{
	private String name;
	Lovers(String name)
	{
		this.name = name;
	}
	public void run()
	{
		show();
	}
	public void show()
	{
		for (int x = 0; x < 10; x++) {
			System.out.println(name + "say: I love you!"+"...threadname="+getName()+"  threadId=="+getId());
		}
	}
}
class ThreadDemo
{
	public static void main(String[] args) {
		Lovers l1 = new Lovers("xing");
		Lovers l2 = new Lovers("song");
		// l1.show();
		// l2.show();
		l1.start();
		l2.start();

		System.out.println("over: threadname="+Thread.currentThread().getName());

	}
}