
class Demo
{
	public static void func()
	{
		try
		{
			throw new Exception();
			// System.out.println("A"); //该条件无法被执行，废话！该条件无法被执行，废话！编译失败
		}
		catch(Exception e)
		{
			System.out.println("B");
		}
	}
	public static void main(String[] args) {
		try
		{
			func();
		}
		catch(Exception e)
		{
			System.out.println("C");
		}
		System.out.println("D");
	}
}





