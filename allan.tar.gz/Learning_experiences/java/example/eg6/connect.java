package connect;
public class connect{
	public static void main(String[] args){
		String cmd="ping";
		String ipprefix="10.42.97."
		int begin=10;
		int end=200;
		Process p=null;
	}
}
