/*
 * 字符流
 */
package xing.io;

import java.io.*;

public class IOexample2{
	public static void main(String[] args){
		try{
			//实例化一个File类文件
			File f = new File("./aaa.txt");
			File fo = new File("./bbb.txt");
		//new了一个字符输入流
		FileReader fr = new FileReader(f);		
		//new了一个高级流，为字符加上了缓冲器
		BufferedReader br = new BufferedReader(fr);
		//new了一个字符输出流，true表示以追加的方式写入，否则新内容会被覆盖旧的
		FileWriter fw = new FileWriter(fo,true);
		//new了一个使格式化输入变的简单对象，true表示加上自动刷新缓存的功能
		PrintWriter pw = new PrintWriter(fw,true);

		//先取得第一行
		String temp = br.readLine();

		//判断是否取得为空
		while(temp!=null){
			pw.println(temp);	//先输出一行在bbb文件
			temp=br.readLine(); //再取下一行
			}
		}
		catch(IOException ie){
			System.out.println(ie.getMessage());
			ie.printStackTrace();
		}
	}
}
