/*
 * 字节流
 */
package xing.io;

import java.io.*;

public class IOexample{
	public static void main(String[] args){
		try{
			//实例化一个File类文件
			File f = new File("./aaa.txt");
			File fo = new File("./bbb.txt");

			//把对象当作参数实例化字节输入流
			FileInputStream fis = new FileInputStream(f);
			FileOutputStream fos = new FileOutputStream(fo);
			int size = fis.available();  //返回流中字符的个数

		for(int i = 0; i < size; i++){
			//调用read()方法读取第一个字节，方法返回第一个字节的ASC码
		//	System.out.print((char)fis.read());
			char temp = (char)fis.read();//从aaa文件读出字符
			fos.write(temp);			//往bbb文件里写
			}
		}
		catch(IOException ie){
			System.out.println(ie.getMessage());
			ie.printStackTrace();
		}
	}
}
