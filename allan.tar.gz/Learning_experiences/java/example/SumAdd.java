/*
	编程求:1+(1+2)+(1+2+3)+. . .+(1+2+3+. . .+100)
*/

class SumAdd
{
	public static void main(String[] args) {
		int sum = 0;
		int tmp = 0;
		for (int i = 1; i <= 1111; i++) {
			for (int j = 1; j <= i; j++) {
				tmp = tmp + j;
			}
			sum = sum + tmp;
		}
			System.out.println(tmp);
	}
}