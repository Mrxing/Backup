
/*
	需求：列出1000以内被5整除的数，每行列出3个
*/
class DividBy5
{
	public static void main(String[] args) {
		
		int i = 0;
		int j = 0;
		while(i < 1000)
		{
			if (i % 5 == 0) {
				System.out.print(i + "\t");
				j++;
				if (j % 3 == 0) {
					System.out.println();
					j = 0;
				}
			}
			i++;
		}
		System.out.println();
	}
}