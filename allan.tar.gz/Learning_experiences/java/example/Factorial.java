
/*
	实现：1！+2！+3！+...15!
	1! + 3! + 5! + .....
*/

class Factorial {
	public static void main(String[] args) {
		int sum = 0;
		for (int i = 1; i <= 5 ; i = i + 2) {
			int tmp = 1;
			for (int j = 1; j <= i; j++) {
				tmp = tmp * j; //tmp *= j;
			}
			sum += tmp; //sum = sum + tmp;
		}
			System.out.println(sum);
	}
}