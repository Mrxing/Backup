package xing.qq;

import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
public class Server{
	static Hashtable ht = new Hashtable();
	public static void main(String[] args){
		try{
			ServerSocket ss = new ServerSocket(8887);
			while(true){
				System.out.println("服务器正在8887端口监听...");
				Socket s = ss.accept();

				service sv = new service();
				sv.s = s;
				sv.ht = ht;
				sv.start();
			}
		}
		catch(Excception e){
			e.printStackTrace();
		}
	}
}
class service extends Thread{
	public Socket s;
	public Hashtable ht;
	public void run(){
		try{
			//(3)
			//接收客户端发来的用户名和密码
			InputStreamReader isr = new InputStreamReader(s.getInputStream());
			BufferedReader br = new BufferedReader(isr);

			System.out.println(br.readLine());
			String uandp = br.readLine();

			//(4)
			//拆分用户名密码
			String u = uandp.split(";")[0];
			String p = uandp.split(";")[1];

			//(6)
			//发送结果到客户端
			OutputStreamWriter osw = new OutputStreamWriter(s.getOutputStream());
			PrintWriter pw = new PrintWriter(osw,true);
			//(5)
			//验证
			if(u.equals("Allan")&&p.equals("12345")){
				if(true){
					pw.println("ok");
				}
			}
			//发送自身用户名给所有的已有用户
			Enumeration em = ht.elements();

			while(em.hasMoreElements()){
				Socket tmps = (Socket)em.nextElement();
				OutputStreamWriter tosw = new OutputStreamWriter(tmps.getOutputStream());
				PrintWriter tpw = new PrintWriter(tosw,true);
				tpw.println("username" + u);
			}
			//将已有用户名发给自己
			em = ht.Keys();
			while(em.hasMoreElements()){
				pw.println("username" + (String)em.nextElement());
			}
			//向Hashtable中添加用户名和对应的Socket
			ht.put(u,s);

			//接收用户信息
			String mess = "";
			while(!mess.equals("{end}")){
				mess = br.readLine();
				//转发
				String user = mess.split(";")[0];
				//给所有的人
				if(user.equals("all")){
					em = ht.elements();
					while(em.hasMoreElements()){
						Socket tmps = (Socket)em.nextElement();
						OutputStreamWriter tosw = new OutputStreamWriter(tmps.getOutputStream());
						printWriter tpw = new PrintWriter(tosw,true);
						tpw.println("mess}"+u+"对所有人说"+mess.sqlit(";")[1]);
					}
					}
					else{
						Socket tmps = (Socket)ht.get(user);
						OutputStreamWriter tosw = new OutputStreamWriter(tmps.getOutputStream());
						printWriter tpw = new PrintWriter(tosw,true);
						tpw.println("mess}"+u+"对"+mess.split(";")[0]+"说:"+mess.split(";")[1]);
					}
					System.out.println(mess);
			}
		}else{
			pw.println("err");
		}
	}catch(Exception e){
		e.printStackTrace();
		}
}
}
