package xing;

import java.awt.*;
import javax.swing.*;

public class Example21 extends JFrame{
	public Example21(){
		this.setSize(300,200);
		this.setLocation(150,250);
		Container con = this.getContentPane();
		JPanel p1 = new JPanel(); //声明并创建面板1
		JTextField t1 = new JTextField("            t1");
		JTextField t2 = new JTextField("            t2");
		JTextField t3 = new JTextField("t3");
		JTextField t4 = new JTextField("t1");
		JTextField t5 = new JTextField("            t5");
		
		p1.setLayout(new BorderLayout()); //设置为边框布局
		p1.add(t1,BorderLayout.NORTH);
		p1.add(t2,BorderLayout.SOUTH);
		p1.add(t3,BorderLayout.EAST);
		p1.add(t4,BorderLayout.WEST);
		p1.add(t5,BorderLayout.CENTER);
		con.add(p1);
	}

	public static void main(String[] args){
		Example21 ex = new Example21();
		ex.setVisible(true);
	}
}
