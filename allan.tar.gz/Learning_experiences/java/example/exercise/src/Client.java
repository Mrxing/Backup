package xing.qq;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.util.EventListener;
import java.awt.event.ActionEvent;
import xing.qq.Main;

public class Client extends JFrame implements ActionListener{
	JTextField tusername;
	JTextField tpassword;

	public Client(String title){
		super(title);
		this.setSize(300,200);
		this.setLocation(150,250);
		Container con=this.getContentPane();
		con.setLayout(new GridLayout(2,1));
		JPanel p1=new JPanel();
		JPanel p2=new JPanel();

		con.add(p1);
		con.add(p2);

		JLabel l1=new JLabel("用户名:");
		JLabel l2=new JLabel("密码   :");
		tusername=new JTextField(20);
		tpassword=new JTextField(20);

		JButton bOk=new JButton("Ok");
		JButton bCancel=new JButton("Cancel");
		p1.add(l1);
		p1.add(tusername);
		p1.add(l2);
		p1.add(tpassword);
		p2.add(bOk);
		p2.add(bCancel);

		bOk.addActionListener(this);
		bCancel.addActionListener(this);
	}

	public static void main(String[] args){
		Client c = new Client("登录窗口");
		c.setVisible(true);
	}
	public void actionPerformed(ActionEvent e){
		System.out.println(e.getActionCommand());//取得并且打印按钮的值
		String uid =tusername.getText();//取得输入的用户名
		String pwd = tpassword.getText();//取得输入的密码
		if(e.getActionCommand().equals("Ok"))
		{
			if(uid.equals("Allan")&&pwd.equals("12345"))
			{
				Main wm = new Main(uid);
				wm.setVisible(true);
				this.setVisible(false);
			}
		}
		else if(e.getActionCommand().equals("Cancel"))
		{
			System.exit(0);
		}
	}
}
