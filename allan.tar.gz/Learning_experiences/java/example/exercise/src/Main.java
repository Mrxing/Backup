package xing.qq;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.util.EventListener;
import java.awt.event.ActionEvent;
import java.io.*;

public class Main extends JFrame implements ActionListener{
	JTextField tsend;		//在外部声明文本框，用来写留言
	JComboBox clist;		//声明下拉列表框，用来罗列在线用户
	JTextArea ta;			//声明大型文本区，用来显示聊天记录
	File f = new File("./chat_history.txt");//声明一个文件对象

	public Main(String title){
		super(title);		//访问父类JFrame的构造函数，为窗体实现标题
		this.setSize(400,300);
		this.setLocation(150,250);
		Container con = this.getContentPane();
		con.setLayout(new BorderLayout());

		JPanel pp = new JPanel();

		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();

		ta = new JTextArea();
		ta.setEditable(false);//设置只读属性

		pp.setLayout(new GridLayout(2,1));
		pp.add(p1);
		pp.add(p2);
		con.add(pp,BorderLayout.SOUTH);
		con.add(ta,BorderLayout.CENTER);

		JLabel l1 = new JLabel("留言:");
		JLabel l2 = new JLabel("To:");
		tsend = new JTextField(30);
		clist = new JComboBox();
		JButton bSend = new JButton("发送");

		p1.add(l1);
		p1.add(tsend);
		p2.add(l2);
		p2.add(clist);
		p2.add(bSend);
		clist.addItem("所有人");
		bSend.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e){
		String str = tsend.getText();//接收输入留言框的字符串
		String me = this.getTitle();

		String others = clist.getSelectedItem().toString();
		if(e.getActionCommand().equals("发送"))
		{
			tsend.setText("");//清空留言框
			//设置聊天记录文本区的内容
			ta.setText(ta.getText()+me+"对"+others+"说:"+str+"\n");
		}
		try{
			//使用字符流写（追加和自动刷新)
		//	FileOutputStream fos = new FileOutputStream(f,true);
			FileWriter fw = new FileWriter(f,true);
			PrintWriter pw = new PrintWriter(fw,true);
			//把留言写到文件中去
			pw.println(me+":"+str);
		}
		catch(IOException ie){
			System.out.println(ie.getMessage());
		}
	}
	public static void main(String[] args)
	{
		Main m = new Main("聊天窗口");
		m.setVisible(true);
	}
}
