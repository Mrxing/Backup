package xing;

//如果想创建并运行一个窗体，就必须让编写的类继承JFrame类，在此之前就要导入
//java.aawt.*和javax.swing.*

import java.awt.*;
import javax.swing.*;

public class Example1 extends JFrame{
	Example1(){				//窗体的构造函数
		this.setSize(300,200);	//设置窗体的大小，300为宽，200为高
		this.setLocation(150,250);//设置窗体出现在屏幕的位置
		Container con = this.getContentPane();//窗体获得容器
	}
	public static void main(String[] args){
		Example1 ex=new Example1();//实例化窗体
		ex.setVisible(true);		//调用对象的show()方法
		}
}
