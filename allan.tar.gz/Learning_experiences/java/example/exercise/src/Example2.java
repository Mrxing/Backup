package xing;

import java.awt.*;
import javax.swing.*;

public class Example2 extends JFrame{
	public Example2(){
		this.setSize(300,200);
		this.setLocation(150,250);
		Container con = this.getContentPane();
		con.setLayout(new GridLayout(2,1)); //布局设置为网格，（2，1）表示两行一列
		JPanel p1 = new JPanel(); //声明并创建面板1
		JPanel p2 = new JPanel(); //声明并创建面板2
		con.add(p1);				//面板1添加到容器中
		con.add(p2);				//面板2添加到容器中

		JLabel l1 = new JLabel("请输入文字:");//添加一个标签
		JTextField text = new JTextField(10); //声明并创建一个文本框,设置最大输入字数
		JButton button = new JButton("ok");		//声明并创建一个按钮

		p1.add(l1);
		p1.add(text);		//面板添加文本框
		p2.add(button);		//面板添加按钮


	}

	public static void main(String[] args){
		Example2 ex = new Example2();
		ex.setVisible(true);
	}
}
