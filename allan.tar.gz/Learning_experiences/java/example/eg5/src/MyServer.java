package cn.server;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
public class MyServer extends JFrame implements ActionListener
{
	//定义一些界面需要用的组件
	JTextArea jta = null;
	JScrollPane jsp = null;
	JTextField jtf = null;
	JButton jb  = null;
	JPanel jp = null;

	//发送消息到套接口
	PrintWriter pw = null;


	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		MyServer ms = new MyServer();
	}


	public MyServer()
	{
		//初始化中部的
		jta = new JTextArea();
		jsp = new JScrollPane(jta);
		jsp.setAutoscrolls(true);
		//初始化南部的
		jp = new JPanel();
		jtf = new JTextField(10);
		jb = new JButton("发送");
		jb.addActionListener(this);
		jp.add(jtf);
		jp.add(jb);

		//设置一下布局
		this.setLayout(new BorderLayout());


		//添加组件
		this.add(jsp, BorderLayout.CENTER);
		this.add(jp, BorderLayout.SOUTH);

		//设置大小等
		this.setSize(300, 240);
		this.setTitle("服务器");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);

		//网络开始
		try {
			//开套接口
			ServerSocket ss = new ServerSocket(9988);
			//等待连接
			System.out.println("等待连接...");
			Socket s = ss.accept();
			System.out.println("连接成功!");

			InputStreamReader isr = new InputStreamReader(s.getInputStream());
			BufferedReader br = new BufferedReader( isr );

			pw = new PrintWriter( s.getOutputStream(), true );
			//接收信息
			while( true )
			{
				String receive_from_client = br.readLine();
				jta.append("客户端： "+"\r\n"+receive_from_client+"\r\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}

	//接收消息
	@Override
		public void actionPerformed(ActionEvent e) 
		{
			// TODO Auto-generated method stub
			if(e.getSource() == jb)
			{
				String send_to_client = jtf.getText();
				jta.append("服务器： "+"\r\n" + send_to_client + "\r\n");
				pw.println( send_to_client );
				jtf.setText("");
			}
		}

}
