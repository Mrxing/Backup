package xing.socket.server;

import java.net.*;
import java.io.*;

public class ServerSocketDemo{
	public static void main(String[] args){
		try{
			//创建ServerSockket
			ServerSocket ss = new ServerSocket(8880);

			System.out.println("服务器在8880端口监听...");

			//设立Socket 监听
			Socket so = ss.accept();

			//在套接字的输入流上建立字符转换流
			InputStreamReader s_iso = new InputStreamReader(so.getInputStream());
			//字符输入流读取字符串
			BufferedReader s_br = new BufferedReader(s_iso);

			//调用readLine()读取
			String str = s_br.readLine();
			System.out.println(str);
		}
		catch(Exception e){}
	}
}
