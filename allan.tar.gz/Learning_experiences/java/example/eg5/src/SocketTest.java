package xing.socket.client;

import java.net.*;
import java.io.*;

public class SocketTest{
	public static void main(String[] args){
		//由于操作socket会可能引发IOException和UnknowHostException,所以必须捕获
		try{
			//在本机的8000端口设立一个socket
			Socket s = new Socket("127.0.0.1",8000);
			//Socket对象获得与套接字关联的输出流，在输出流上创建字符转换流
			OutputStreamWriter osw = new OutputStreamWriter(s.getOutputStream());

			//创建字符输出流
			PrintWriter pw = new PrintWriter(osw,true);

			//往字符流里输入字符串，这时字符会被转换为字节，通过Socket接通
			pw.println("Happy New Year @!!");
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
