package cn.client;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
public class MyClient extends JFrame implements ActionListener
{
	//定义一些界面需要用的组件
	JTextArea jta = null;
	JScrollPane jsp = null;
	JTextField jtf = null;
	JButton jb  = null;
	JPanel jp = null;

	//定义一个往套接口里面写数据的类
	PrintWriter pw = null;

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		MyClient mc = new MyClient();
	}


	public MyClient()
	{
		//初始化中部的
		jta = new JTextArea();
		jsp = new JScrollPane(jta);
		jsp.setAutoscrolls(true);
		//初始化南部的
		jp = new JPanel();
		jtf = new JTextField(10);
		jb = new JButton("发送");
		jb.addActionListener(this);

		jp.add(jtf);
		jp.add(jb);

		//设置一下布局
		this.setLayout(new BorderLayout());


		//添加组件
		this.add(jsp, BorderLayout.CENTER);
		this.add(jp, BorderLayout.SOUTH);

		//设置大小等
		this.setSize(300, 240);
		this.setTitle("客户端");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);

		//网络开始
		try {
			//连接服务器
			Socket s = new Socket("localhost", 9988);

			//发送信息在监听那
			pw = new PrintWriter(s.getOutputStream(), true);

			InputStreamReader isr = new InputStreamReader(s.getInputStream());
			BufferedReader br = new BufferedReader( isr );
			//接收消息
			while( true )
			{
				String receive_from_server = br.readLine();
				jta.append("服务器：" + "\r\n" + receive_from_server+"\r\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}


	//发送消息
	@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if( e.getSource() == jb)
			{
				String send_to_server = jtf.getText();
				jta.append("客户端： "+"\r\n"+send_to_server+"\r\n");
				pw.println(send_to_server);
				jtf.setText("");
			}
		}

}
