package xing.net;

import java.net.*;

public class InetAddressTest{
	public static void main(String[] args){
		try{
			InetAddress add = InetAddress.getLocalHost();
			System.out.println();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
