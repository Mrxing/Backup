package frame;

import java.awt.Button;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CalFrame extends JFrame implements ActionListener {

	private static final long serialVersionUID = 4960918806632123930L;
	private JPanel mainPanel = null;
	private JTextField out = null;
	private Button key0 = null;
	private Button key1 = null;
	private Button key2 = null;
	private Button key3 = null;
	private Button key4 = null;
	private Button key5 = null;
	private Button key6 = null;
	private Button key7 = null;
	private Button key8 = null;
	private Button key9 = null;
	private Button key10 = null;
	private Button key11 = null;
	private Button key12 = null;
	private Button key13 = null;
	private Button key14 = null;
	private Button key15 = null;
	private JButton clear = null;

	private ArrayList<Double> numberList = new ArrayList<Double>();
	private ArrayList<String> operatorList = new ArrayList<String>();

	private double result = 0.0;

	public ArrayList<Double> getNumberList() {
		return numberList;
	}

	public void setNumberList(ArrayList<Double> numberList) {
		this.numberList = numberList;
	}

	public ArrayList<String> getOperatorList() {
		return operatorList;
	}

	public void setOperatorList(ArrayList<String> operatorList) {
		this.operatorList = operatorList;
	}

	public CalFrame() {
		super();
		initialize();

		this.addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent e) {
				System.exit(0);
				}
				});
	}

	private void initialize() {
		this.setSize(new Dimension(294, 265));
		this.setTitle("计算器");
		this.setContentPane(getJContentPane());
		this.setVisible(true);
	}

	private JPanel getJContentPane() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setLayout(null);
			mainPanel.add(getResult(), null);
			mainPanel.add(getKey0(), null);
			mainPanel.add(getKey1(), null);
			mainPanel.add(getKey2(), null);
			mainPanel.add(getKey3(), null);
			mainPanel.add(getKey4(), null);
			mainPanel.add(getKey5(), null);
			mainPanel.add(getKey6(), null);
			mainPanel.add(getKey7(), null);
			mainPanel.add(getKey8(), null);
			mainPanel.add(getKey9(), null);
			mainPanel.add(getKey10(), null);
			mainPanel.add(getKey11(), null);
			mainPanel.add(getKey12(), null);
			mainPanel.add(getKey13(), null);
			mainPanel.add(getKey14(), null);
			mainPanel.add(getKey15(), null);
			mainPanel.add(getClear(), null);
		}
		return mainPanel;
	}

	private JTextField getResult() {
		if (out == null) {
			out = new JTextField("");
			out.setBounds(new Rectangle(0, 0, 208, 50));
		}
		return out;
	}

	private Button getKey0() {
		if (key0 == null) {
			key0 = new Button();
			key0.setBounds(new Rectangle(0, 50, 70, 45));
			key0.setLabel("1");
			key0.addActionListener(this);
		}
		return key0;
	}

	private Button getKey1() {
		if (key1 == null) {
			key1 = new Button();
			key1.setBounds(new Rectangle(70, 50, 70, 45));
			key1.setLabel("2");
			key1.addActionListener(this);
		}
		return key1;
	}

	private Button getKey2() {
		if (key2 == null) {
			key2 = new Button();
			key2.setBounds(new Rectangle(140, 50, 70, 45));
			key2.setLabel("3");
			key2.addActionListener(this);
		}
		return key2;
	}

	private Button getKey3() {
		if (key3 == null) {
			key3 = new Button();
			key3.setBounds(new Rectangle(210, 50, 70, 45));
			key3.setLabel("+");
			key3.addActionListener(this);
		}
		return key3;
	}

	private Button getKey4() {
		if (key4 == null) {
			key4 = new Button();
			key4.setBounds(new Rectangle(0, 95, 70, 45));
			key4.setLabel("4");
			key4.addActionListener(this);
		}
		return key4;
	}

	private Button getKey5() {
		if (key5 == null) {
			key5 = new Button();
			key5.setBounds(new Rectangle(70, 95, 70, 45));
			key5.setLabel("5");
			key5.addActionListener(this);
		}
		return key5;
	}

	private Button getKey6() {
		if (key6 == null) {
			key6 = new Button();
			key6.setBounds(new Rectangle(140, 95, 70, 45));
			key6.setLabel("6");
			key6.addActionListener(this);
		}
		return key6;
	}

	private Button getKey7() {
		if (key7 == null) {
			key7 = new Button();
			key7.setBounds(new Rectangle(210, 95, 70, 45));
			key7.setLabel("-");
			key7.addActionListener(this);
		}
		return key7;
	}

	private Button getKey8() {
		if (key8 == null) {
			key8 = new Button();
			key8.setBounds(new Rectangle(0, 140, 70, 45));
			key8.setLabel("7");
			key8.addActionListener(this);
		}
		return key8;
	}

	private Button getKey9() {
		if (key9 == null) {
			key9 = new Button();
			key9.setBounds(new Rectangle(70, 140, 70, 45));
			key9.setLabel("8");
			key9.addActionListener(this);
		}
		return key9;
	}

	private Button getKey10() {
		if (key10 == null) {
			key10 = new Button();
			key10.setBounds(new Rectangle(140, 140, 70, 45));
			key10.setLabel("9");
			key10.addActionListener(this);
		}
		return key10;
	}

	private Button getKey11() {
		if (key11 == null) {
			key11 = new Button();
			key11.setBounds(new Rectangle(210, 140, 70, 45));
			key11.setLabel("*");
			key11.addActionListener(this);
		}
		return key11;
	}

	private Button getKey12() {
		if (key12 == null) {
			key12 = new Button();
			key12.setBounds(new Rectangle(0, 185, 70, 45));
			key12.setLabel("0");
			key12.addActionListener(this);
		}
		return key12;
	}

	private Button getKey13() {
		if (key13 == null) {
			key13 = new Button();
			key13.setBounds(new Rectangle(210, 185, 70, 45));
			key13.setLabel("/");
			key13.addActionListener(this);
		}
		return key13;
	}

	private Button getKey14() {
		if (key14 == null) {
			key14 = new Button();
			key14.setBounds(new Rectangle(70, 185, 70, 45));
			key14.setLabel(".");
			key14.addActionListener(this);
		}
		return key14;
	}

	private Button getKey15() {
		if (key15 == null) {
			key15 = new Button();
			key15.setBounds(new Rectangle(140, 185, 70, 45));
			key15.setLabel("=");
			key15.addActionListener(this);
		}
		return key15;
	}

	private JButton getClear() {
		if (clear == null) {
			clear = new JButton();
			clear.setBounds(new Rectangle(207, 1, 72, 47));
			clear.setText("CM");
			clear.addActionListener(this);
		}
		return clear;
	}

	@Override
		public void actionPerformed(ActionEvent e) {
			Object currKey = e.getSource();

			if (currKey == key0) {
				out.setText(out.getText() + "1");
			} else if (currKey == key1) {
				out.setText(out.getText() + "2");
			} else if (currKey == key2) {
				out.setText(out.getText() + "3");
			} else if (currKey == key4) {
				out.setText(out.getText() + "4");
			} else if (currKey == key5) {
				out.setText(out.getText() + "5");
			} else if (currKey == key6) {
				out.setText(out.getText() + "6");
			} else if (currKey == key8) {
				out.setText(out.getText() + "7");
			} else if (currKey == key9) {
				out.setText(out.getText() + "8");
			} else if (currKey == key10) {
				out.setText(out.getText() + "9");
			} else if (currKey == key12) {
				out.setText(out.getText() + "0");
			} else if (currKey == key14) {
				out.setText(out.getText() + ".");
			}

			if (currKey == key3) {
				numberList.add(Double.parseDouble(out.getText()));
				operatorList.add("+");

				out.setText("");
			} else if (currKey == key7) {
				numberList.add(Double.parseDouble(out.getText()));
				operatorList.add("-");

				out.setText("");

			} else if (currKey == key11) {
				numberList.add(Double.parseDouble(out.getText()));
				operatorList.add("*");

				out.setText("");

			} else if (currKey == key13) {
				numberList.add(Double.parseDouble(out.getText()));
				operatorList.add("/");

				out.setText("");
			}

			if (currKey == key15) {
				try {
					numberList.add(Double.parseDouble(out.getText()));
				} catch (NumberFormatException ne) {
					ne.printStackTrace();

					numberList = new ArrayList<Double>();
					operatorList = new ArrayList<String>();
					result = 0.0;
					out.setText("");
				}
				result = numberList.get(0);

				for (int i = 1; i <= operatorList.size(); i++) {
					if (operatorList.get(i - 1).equalsIgnoreCase("+")) {
						result = result + numberList.get(i);
					}
					if (operatorList.get(i - 1).equalsIgnoreCase("-")) {
						result = result - numberList.get(i);
					}
					if (operatorList.get(i - 1).equalsIgnoreCase("*")) {
						result = result * numberList.get(i);
					}
					if (operatorList.get(i - 1).equalsIgnoreCase("/")) {
						if (numberList.get(i) != 0.0) {
							result = result / numberList.get(i);
						} else {
							System.out.println("Error Input");
							result = 0.0;
						}
					}
				}
				out.setText(result + "");
				numberList = new ArrayList<Double>();
				operatorList = new ArrayList<String>();
			}

			if (currKey == clear) {
				numberList = new ArrayList<Double>();
				operatorList = new ArrayList<String>();
				result = 0.0;
				out.setText("");
			}
		}
}

