package shy.luo.broadcounter;

public interface ICounterService {
    public void startCounter(int initVal);
    public void stopCounter();
}
