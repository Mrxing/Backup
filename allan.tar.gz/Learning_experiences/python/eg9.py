#-*-coding:utf-8-*
#序列成员资格实例
#检测数据中用户名和密码是否匹配
database = [
		["william","1234"],
		["ares","2345"],
		["zhou","3456"],
		["bruse","4567"],
		["allan","8888"]
		]
username = raw_input("User name: ")
pin = raw_input("PIN code: ")
if [username,pin] in database: print "Access granted"
else: print "illegal user!!!!!"
