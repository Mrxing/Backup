二、列表和元组 (数据结构)
最基本到数据结构是序列，序列中到每个元素被分配一个序号--即元素位置，也成为索引

python 包含6个内建序列：列表、元组、字符串、Unicode字符串、buffer对象和xrange对象

列表和元组的主要区别在于列表可以修改，元组不能

所有序列类型都可以进行某些特定到操作，如：索引、分片、加、乘以及检查某个元素是否属于序列的成员

索引：访问单个元素
endings = ["st","nd","rd"] + 17 * ["th"] + ["st","nd","rd"] + 7 * ["th"] + ["st"]
    注：一个月最多有31天，如果按英文表示的话，对应的日期就是
    1st, 2nd, 3rd,
    4th, ... , 20th, #共有17个，所以是17*['th']
    21st, 22nd, 23rd,
    24th, ... , 30th, #共有7个，所以是7*['th']
    31st
    
分片：访问一定范围内的元素
>>> numbers = [1,2,3,4,5,6,7,8,9,10]
>>> numbers[3,6]
[4,5,6]
>>> numbers[0,1]
[1]
分片操作到实现是提供两个索引作为边界，第一个索引到元素包含在分片内的，而第二个则不包含在分片内
>>> number[-3:]
[8,9,10]
>>> number[:3]
[1,2,3]

中文注释文件头加入：#-*-coding:utf-8-*
序列可以相加、相乘，相加必须是同种类型

序列的乘法实例eg8.py

in 运算符：检查一个值是否在序列中
>>> permissons = "rw"
>>> "r" in permissions
True
>>> "x" in permissions
False
资格检查实例eg9.py

list 函数：
>>> list("hello")
['h','e','l','l','o']
>>> word = ['h','e','l','l','o']
>>> ''.join(word)  #将列表中的字符组合在一起
'world'

列表的基本操作： 
1、改变列表：元素赋值
不能为不存在的元素赋值
2、删除元素
3、分片赋值
>>> name = list('perl')
>>> name
['p','e','r','l']
>>> name[2:] = list('ar')
>>> name
['p','e','a','r']

分片赋值可以在不需要替换任何元素的情况下插入新的元素
>>> numbers = [1,5]
>>> numbers[1:1] = [2,3,4]
>>> numbers
[1,2,3,4,5]
同样在不需要替换任何元素的情况下删除元素
>>> numbers = [1,2,3,4,5,6]
>>> numbers[2:4] = []
>>> numbers
[1,2,6]

列表方法：
1、append 追加
2、count  计数
3、extend 扩展
>>> a = [1,2,3]         相加   >>> a = [1,2,3]
>>> b = [4,5,6]                >>> b = [4,5,6]
>>> a.extend(b)                >>> a+b
>>> a                          >>> a
[1,2,3,4,5,6]                  [1,2,3]
4、insert 插入制定位置
5、index 找出某个元素的位置
6、pop 移除列表中的一个元素（默认最后一个）此方法是唯一个既能修改列表又返回元素值的列表方法
7、remove 移除列表中某个值的第一个匹配项
8、reverse 将列表中的元素反向存放 如果需要对一个序列进行反向迭代，那么可以用reversed函数，该函数不返回一个列表，而是返回一个迭代器对象，可以采用list函数转换为列表显示
>>> a = [1,2,3]
>>> list(reversed(a))
[3,2,1]
9、sort 
b = [2,3,5,6,1,7]
>>> b.sort().reverse()   错
>>> sorted(b).reverse()  对   list(reversed(sorted(b)))

元组：不可变序列

tuple 函数： 功能与list 函数基本一样，是以一个序列作为参数并把它转换为元组

元组特性： a. 元组可以在映射中当作键使用----而列表不行
          b. 元组作为很多内建函数和方法的返回值存在，也就是说必须对元组进行处理
“处理”元组大多数情况下就是把它们当作列表进行操作

字符串：不可变的
字符串格式化
字符串转换： d, 带符号的十进制
            o, 不带符号的八进制
            u, 不带符号的十进制
            x, 不带符号的十六进制（小写）
            X, 不带符号的十六进制（大写）
            C， 单字符
            r, 字符串（使用repr转换任意Python对象）
            s, 字符串（使用str转换任意Python对象）
字段宽度和精度
字段宽度就是转换后的值保留的最小字符个数；精度（对于数字来说）则是结果中应该包含的小数位数。
>>> '%.5s' % 'Guido van Rossum'
'Guido'
可以使用* 作为字段或者精度，此时数值会从元组参数中读出
>>> '%.*s' % (5,'Guido van Rossum')
'Guido'

符号，对齐和0填充
字符串格式化实例eg10.py

字符串常量：
    string.digits: 包含数字 0-9 的字符串
    string.letters: 包含所有字母（大写或者小写）的字符串
    string.lowercase: 包含所有小写字母的字符串
    string.printable: 包含所有可打印字符的字符串
    string.punctuation: 包含所有标点的字符串
    string.uppercase: 包含所有大写字母的字符串
字符串方法：
1. find 可以在一个较长的字符串中查找子字符串。它返回字串的位置的最左端索引。没找到返回 -1
2. join 它是split方法的逆方法，用来在队列中添加元素
>>> dirs = '','usr','src','env'
>>> '/'.join(dirs)
' /usr/src/env'
3. lower 返回字符串的小写字母版
>>> 'Summer is comming'.lower()
'summer is comming'
4. replace方法返回某字符串的所有匹配项均被替换之后得到的字符串
>>> 'Thsi si just a test'.replace('si','is')
'This is just a test'
5. split join的逆方法
6. strip 方法返回去除两侧空格的字符串,也可以指定要去除的字符
>>> '   internet is fun   '.strip()
'internet is fun'
>>> '*** SPAM * for * everyone!!! ***'.strip(' *!')
'SPAM * for * everyone'
7. translate 方法和replace方法一样，可以替换字符串中的某些部分，但是不同的是translate方法只处理单个字符。优点：可以同时进行多个替换
translate的第二个参数是用来制定需要删除的字符
>>> 'This is an incredible test.'.translate(table,' ')
Thisisanincredibletest.

字典

映射：通过名字引用值的数据结构；字典是python中唯一内建的映射类型。
1. 创建字典
phonebooks = {'william':'5743','ares':'5749','zhou':'4747'}
2. 字典函数dict
>>> items = [('name','william'),('age',24)]
>>> d = dict(items)
>>> d
{'name':'william','age':24}
dict函数可以直接创建字典
>>> d = dict(name='william',age=24)
>>> d
{'age': 24, 'name': 'william'}

3. 字典的基本操作
字典实例，通讯簿eg11.py

4. 字典方法
1) clear: 清除字典中的所有项

eg1:                        vs        eg2:
>>> x = {}                            >>> x = {}
>>> y = x                             >>> y = x
>>> x [key] = 'values'                >>> x[key] = 'values'
>>> y                                 >>> y
{'key':'values'}                      {'key':'values'}
>>> x = {}                            >>> x.clear()
>>> y                                 >>> y
{'key':'values'}                      {}
2) copy 返回具有相同键值的新字典 如果修改了复制字典那么原字典也会改变。为了不影响原字典，采用deepcopy的方法即可（from copy import deepcopy)
>>> from copy import deepcopy
>>> d = {}
>>> d['name'] = ['william','ares']
>>> c = d.copy()
>>> dc = deepcopy(d)
>>> d['name'].append('zhou')
>>> c
{'name': ['william', 'ares', 'zhou']}
>>> dc
{'name': ['william', 'ares']}
3) fromkeys 使用给定的键建立新的字典，每个键默认对应的值为None
>>> {}.fromkeys(['name','age'])
{'age': None, 'name': None}

>>> dict.fromkeys(['name','age'])
{'age': None, 'name': None}
如果不想使用 None 作为默认值，也可以自定义
>>> dict.fromkeys(['name','age'],'(unknown)')
{'age':'(unkonwn)','name':'(unkonwn)'}
4) get 更宽松的访问字典的方法，如果试图访问字典中不存在的项时会出错,但是用get 则不会
>>> d = {}
>>> print d['name'] #error

>>> print d.get('name') #right











