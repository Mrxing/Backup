from Tkinter import *
root = Tk()
w = Label(root, text="hello, world!")
w.pack()
root.mainloop()

