#-*-coding:utf-8-*

#使用人名作为键值的字典
people = {
		'william':{
			'phone': '5743',
			'addr': 'zhong hua yuan'
			},
		'ares':{
			'phone':'5749',
			'addr':'weichuangsushe'
			},
		'zhou':{
			'phone':'5747',
			'addr':'si ji hua cheng'
			}
		}
#针对电话号码的地址使用的描述性标签
labels = {
		'phone': 'phone number',
		'addr': 'address'
		}
name = raw_input('Name: ')
#查找电话号码还是地址？使用正确的键
request = raw_input('Phone number (p) or address (a)? ')
if request == 'p': key = 'phone'
if request == 'a': key = 'addr'

if name in people: print "%s's %s is %s." % (name, labels[key],people[name][key])
