#-*-coding:utf-8-*
#序列的乘法实例
# 以正确的宽度在居中的“盒子”内打印一个句子

sentence = raw_input("Sentence: ")
#sentence = "this is text sentence"
screen_width = 80
text_width = len(sentence)
box_width = text_width + 6
left_margin = (screen_width - text_width) // 2

print
print " " * left_margin + "+"	+ "-" * (box_width - 4) + "+"
print " " * left_margin + "| "	+ " " * text_width		+ " |"
print " " * left_margin + "| "	+		sentence		+ " |"
print " " * left_margin + "| "	+ " " * text_width		+ " |"
print " " * left_margin + "+"	+ "-" * (box_width - 4) + "+"
print
