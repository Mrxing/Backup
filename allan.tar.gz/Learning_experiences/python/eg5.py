class person:
	school = 'bit'
	def __init__(self):
		self.name = 'taomen'
		self.id = 201305
	def say_id(self):
		print "%s's id is %d" %(self.name,self.id)

me = person()
me.say_id()
print me.school
