my_turple=(1,2,3)
my_list=[]
for i in my_turple:
	my_list.append(i)
print my_list
