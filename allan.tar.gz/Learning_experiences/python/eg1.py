inputed_num = 0
while 1:
	inputed_num = input("input a number betwween 1 and 10\n")
	if inputed_num >= 10:
		pass
	elif inputed_num < 1:
		pass
	else:
		break
print "hehe, don't follow, won't out"
