def test_func(list_be_passed):
	list_be_passed[0] = 'towin'
my_list=['taomen']
print my_list
test_func(my_list)
print my_list
