There are java exercise for self-learning.
