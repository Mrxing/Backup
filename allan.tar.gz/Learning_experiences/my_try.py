i = 0
n = 0
while i <= 10:
	n = n + i
	i = i + 1
print n
