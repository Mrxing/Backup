#!/bin/bash
PWD=`pwd`
PROJECT_NAME="TC76"
PROJECT_FILE=$PROJECT_NAME

function get_p()
{
ssh 10.42.100.20 gerrit ls-projects |grep $PROJECT_NAME > $PROJECT_FILE
}


function set_p()
{
#get the total line numbers
LINE=`sed -n '$=' $PROJECT_FILE`
echo "LINE=$LINE"

echo $PROJECT_FILE
for i in `seq 1 $LINE`;do
	#get the content of every lines
	STR=`sed -n "${i}p" $PROJECT_FILE`

	ssh -p 29418 Allan_Xing@10.42.100.20 gerrit set-project-parent --parent whq-replication $STR
	echo "[$i] set $STR done,continue......"
	echo " "
done
}

#get_p
set_p
