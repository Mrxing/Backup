#!/bin/bash

PWD=`pwd`
PROJ_LIST=$PWD/proj_list1
LOCAL_DIR=$PWD/git_proj1

if [ ! -d $LOCAL_DIR ];then
    mkdir $LOCAL_DIR
else
    rm -rf $LOCAL_DIR/*
fi

#get the total line numbers
LINE=`sed -n '$=' $PROJ_LIST`
echo "LINE=$LINE"

echo $FILE
for i in `seq 1 $LINE`;do
	#get the content of every lines
	STR=`sed -n "${i}p" $PROJ_LIST`
    git clone --mirror ssh://nts01.wistron.com/${STR}.git $LOCAL_DIR/${STR}.git
    echo -e "[$i]mirror $STR successfully...\n"
done	
    scp -r $LOCAL_DIR robot@10.42.100.20:~
    echo -e "scp ok...\n"
