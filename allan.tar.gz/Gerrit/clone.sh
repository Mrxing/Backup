#!/bin/bash
PWD=`pwd`
FILE=$PWD/file1


#get the total line numbers
LINE=`sed -n '$=' $FILE`
echo "LINE=$LINE"

echo $FILE
for i in `seq 1 $LINE`;do
	#get the content of every lines
	STR=`sed -n "${i}p" $FILE`

    git clone --mirror ssh://nts01.wistron.com/$STR 
	echo "[$i] set $STR done,continue......"
	echo " "
done	
