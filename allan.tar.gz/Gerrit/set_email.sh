#!/bin/bash

function useage()
{
ssh 10.42.100.20 gerrit gsql<<EOF
select * from account_external_ids;
\q
EOF
	echo -e "\033[0;31;1m useage: $0 username account_id\033[0m"
	echo ""
}

if test -z $1;then
	useage
else
ssh 10.42.100.20 gerrit gsql<<EOF
update account_external_ids set email_address = "$1@wistron.com" where account_id = $2;
\q
EOF
fi

