#!/bin/bash

# for gerrit Administrator set user email
#
PWD=`pwd`
# http password file
USER_FILE=./htpasswords
USER=$PWD/user.txt

cat $USER_FILE |awk  -F ':'  '{print $1}' > $USER

#get the total line numbers
LINE=`sed -n '$=' $USER`
echo "LINE=$LINE"

function set_full_name()
{
echo $FILE
for i in `seq 1 $LINE`;do
	#get the content of every lines
	STR=`sed -n "${i}p" $USER`

	ssh -p 29418 Allan_Xing@10.42.97.6 gerrit set-account --full-name ${STR}/WKS/Wistron $STR
	echo "[$i] set $STR full name  done,continue......"
	echo " "
done	
}

function set_email()
{
echo $FILE
for i in `seq 1 $LINE`;do
	#get the content of every lines
	STR=`sed -n "${i}p" $USER`

	ssh -p 29418 Allan_Xing@10.42.97.6 gerrit set-account --add-email ${STR}@wistron.com $STR
	echo "[$i] set $STR email done,continue......"
	echo " "
done	

}

#set_full_name
set_email
