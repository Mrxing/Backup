Linux driver training material - exercise 08
by guangwei@Sep18'12

Targets:
1. Build a driver and dump all of the GPIO status;

Test Enviroment:
Test on real android device(Bohai, t-lite or others);

Time Required:
5 days.

Purpose:
1. Read below gpio.txt and learn what's GPIO and how to operate.
Documentation/gpio.txt
2. Learn how to read HW schematic;
3. Learn how to read SOC spec;



