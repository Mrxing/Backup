linux drivers training

Course   #1	Linux Developing introduce
Training #1	Building and Running Modules
Training #2	Char Drivers
Training #3	Misc Drivers
Training #4	ioctl
Training #5	Concurrency and Race Conditions
Training #6	Time, Delays
Training #7	Building Kernel image for goldfish(emulator)
Training #8	Building Android application
Training #9	Use NDK to build JNI shared library

Notes:
For "Course#01 Linux Developing introduce",
Please click "read" button on below link, and enjoy the training 
(the link only works for Wistron internal network),
http://elearnwksrd.wistron.com.cn/xms/data/246/content/0278FCF482B568A7196F/text/index.html
