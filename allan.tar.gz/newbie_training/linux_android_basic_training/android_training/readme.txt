Android Training Content

Course   #01	Android Developing introduce
Training #01	Setup Android SDK Build environments
Training #02	Build your First Android application and debug it.
Training #03	Be familiar with Layout & View & Widge
Training #04	Build your own application
Training #05	Custom View
Training #06	Study Intent and Bundle.
Training #07	Android编程综合训练
Training #08	Study “Service”
Training #09	Study "BroadcastReceiver"
Training #10	Study data store  technology (Preferences, Files, Databases, Network) and Content Provider
Training #11	Use NDK to build JNI shared library


Notes:
For "Course#01 Android Developing introduce",
Please click "read" button on below link, and enjoy the training 
(the link only works for Wistron internal network),
http://elearnwksrd.wistron.com.cn/xms/data/247/content/F209617A239A8D1327D6/text/index.html

