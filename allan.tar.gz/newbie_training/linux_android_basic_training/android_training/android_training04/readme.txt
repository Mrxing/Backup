AndroidTraining#4
By Guangwei@Nov01’10

Targets:
Build your own simple android projects, with the common views and widgets.

Time Required:
1 day.

Task List:
Choose your favorite topic, design first, and implement your thoughts. 

Refer books/websites/Sample codes:
1. “Hello, Views” Tutorials on SDK help document
\android-sdk-xxxs\docs\resources\tutorials\views\index.html
2. “ApiDemos” Sample codes
\android-sdk-windows\samples\android-8\ApiDemos
3. 《Android系统原理及开发原理要点详解》, Chap14.2 “各种UI元素的使用”
