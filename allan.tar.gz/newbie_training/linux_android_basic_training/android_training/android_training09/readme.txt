AndroidTraining#9
By Guangwei@Nov10’10

Targets:
Learn how to use the “BroadcastReceiver” in android。.

Time Required:
2 days.

Task List:
1. Study the SDK API demo codes in the “App->Alarm”.
Refer code: com/example/android/apis/app/AlarmController.java
			com/example/android/apis/app/OneShotAlarm.java
			com/example/android/apis/app/RepeatAlarm.java
2. Study how to receive the system status (such as WiFi, Bluetooth, Time change), you may refer the codes “MyStatusBar”!
3. Build a utility, to monitor system status.

Refer books/websites/Sample codes:
1. SDK sample code
2. “MyStatusBar”.
