AndroidTraining#6
By Guangwei@Nov01’10

Targets:
Study Intent and Bundle.
Learn how to launch another new Activity and transfer information between them.

Time Required:
1 day.

Task List:
1. Build an application to call another Activity.
2. Build an application to send (get) information to (from) another Activity.

Refer books/websites/Sample codes:
1. 《Google Android SDK开发范例大全》(第二版)，
- chap3.9(调用另一个Activity), 
- chap3.10(不同Activity之间的数据传递), 
- chap3.11(返回数据到前一个Activity).
