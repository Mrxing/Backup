AndroidTraining#1
By Guangwei@Oct26’10

Purpose:
Setup Android SDK Build environments in Ubuntu or WinXp!

Time Required:
1/2 day.

Task List:
1. Install JDK.
Notes: 
In Ubuntu, we must install JDK1.5 (not 1.6), or it cause build android source errors. (sudo apt-get install sun-java5-jdk)
In WinXp, you may install JDK1.6. (\\10.42.92.17\sw_rd$\Projects\Android\jdk\jdk-6u13-windows-i586-p.exe)
2. Get SDK from server, and un-zip it,
\\10.42.92.17\sw_rd$\Projects\Android\sdk\android-sdk\android-sdk-update\android-sdk-linux_86-2.2_r2.zip (For Ubuntu)
\\10.42.92.17\sw_rd$\Projects\Android\sdk\android-sdk\android-sdk-update\android-sdk-windows-2.2_r2.zip (For WinXp)
3. Get Eclipse from server, and un-zip it,
\\10.42.92.17\sw_rd$\Projects\Android\eclipse\eclipse3.5\eclipse-java-galileo-SR1-linux-gtk.tar.gz (Fro Ubuntu)
\\10.42.92.17\sw_rd$\Projects\Android\eclipse\eclipse3.5\eclipse-java-galileo-SR1-win32.zip (For WinXp)
4. Install ADT.
Before install ADT, please read “Installing and Updating ADT.doc” first. You may follow this SOP to do it. 
And you can find ADT on the server as below,
\\10.42.92.17\sw_rd$\Projects\Android\ADT\ADT-0.9.6.zip
