AndroidTraining#7
By Guangwei@Nov05’10

Targets:
Android编程综合训练。.

Time Required:
1+6 hours.

Task List:
1. 1小时内写出程序的功能，列出所使用的组件(view/widget)、程序的逻辑图、开发难点与重点。整理成文档，使用email发出。
2. 使用6个小时的时间，完成程序各部分的功能。并提交程序及源码。
3. 开发内容随机抽取。

Refer books/websites/Sample codes:
1. SDK sample code
2. 《Google Android SDK开发范例大全》(第二版)
3. 《Google Android 开发入门指南》(第二版)
4. 《Android应用开发揭秘》
5. 《Android系统原理及开发要点详解》
