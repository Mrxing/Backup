AndroidTraining#5
By Guangwei@Nov01’10

Targets:
Build a custom view and test it.

Time Required:
2 days.

Task List:
1. Merge the “PvButton” to your project, and test it.
Please refer “PvButtonDocumentsRel1.1.doc”.
2. Study the 《Android应用开发揭秘》, Chap5 “Android游戏开发”, and build your own custom view.

Refer books/websites/Sample codes:
1. “PvButton” Sample codes and documents.
2. 《Android应用开发揭秘》, Chap5 “Android游戏开发”
