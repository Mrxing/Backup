AndroidTraining#2
By Guangwei@Oct26’10

Purpose:
1. Create your first Android application and debug it!
2. Learn how to debug an Android application and use “log” to dump information.
3. Learn basic structure of an Android project (resource files, layout files, etc.)

Time Required:
1/2 day.

Task List:
Please refer the SDK help document, and complete below training,
1. Create an AVD
2. Create the Project
3. Construct the UI
4. Run the Code
5. Upgrade the UI to an XML Layout
6. Debug Your Project

Refer books/websites:
1. “Hello world” Tutorials on SDK help document
\android-sdk-xxx\docs\resources\tutorials\hello-world.html 

