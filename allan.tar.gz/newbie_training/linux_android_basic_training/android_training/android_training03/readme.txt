AndroidTraining#3
By Guangwei@Oct28’10

Targets:
Be familiar with Layout & View & Widget!

Time Required:
2 days.

Task List:
Please refer the SDK help document, and complete below training,
1. Learn the layout, such as Linear Layout / Relative Layout / Table Layout.
2. Learn the basic views, such as Text View / Button / List View / Image View / Progress Bar…
3. Learn the basic Widget, such as Date Picker / Time Picker..

Refer books/websites/Sample codes:
1. “Hello, Views” Tutorials on SDK help document
\android-sdk-xxxs\docs\resources\tutorials\views\index.html
2. “ApiDemos” Sample codes
\android-sdk-windows\samples\android-8\ApiDemos
