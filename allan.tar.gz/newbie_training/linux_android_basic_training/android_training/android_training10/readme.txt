AndroidTraining#10
By Guangwei@Nov11’10

Targets:
Learn the data store technology (Preferences, Files, Databases, Network) and Content Provider.

Time Required:
2 days.

Task List:
1. Study 2 out of 4 data store technology (Preferences, Files, Databases, Network).
2. Learn what Content Provider is and how to create and use.
3. Use the above technology to improve your music player.

Refer books/websites/Sample codes:
1. 《Android 应用开发揭秘》，Chap6 “Android数据存储”！
