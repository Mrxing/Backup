AndroidTraining#8
By Guangwei@Nov08’10

Targets:
Learn how to use the “Service” in android.

Time Required:
2 days.

Task List:
1. Study the SDK API demo codes in the “App->Service”.
2. Build a simple music player, use activity to handle user input, use service to handle play/pause/stop function!

Extension study:
AIDL: Android Interface Description Language.

Refer books/websites/Sample codes:
1. SDK sample code
2. 《Android系统原理及开发要点详解》, chap14.1.5 “使用服务”。
