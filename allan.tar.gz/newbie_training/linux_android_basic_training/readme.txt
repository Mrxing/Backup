There are 2 parts for new bie, 
- linux drivers training
- Android Training 

linux drivers training
Course   #1	Linux Developing introduce
Training #1	Building and Running Modules
Training #2	Char Drivers
Training #3	Misc Drivers
Training #4	ioctl
Training #5	Concurrency and Race Conditions
Training #6	Time, Delays
Training #7	Building Kernel image for goldfish(emulator)
Training #8	Building Android application
Training #9	Use NDK to build JNI shared library


Android Training 
Course   #01	Android Developing introduce
Training #01	Setup Android SDK Build environments
Training #02	Build your First Android application and debug it.
Training #03	Be familiar with Layout & View & Widge
Training #04	Build your own application
Training #05	Custom View
Training #06	Study Intent and Bundle.
Training #07	Android编程综合训练
Training #08	Study “Service”
Training #09	Study "BroadcastReceiver"
Training #10	Study data store  technology (Preferences, Files, Databases, Network) and Content Provider
Training #11	Use NDK to build JNI shared library
