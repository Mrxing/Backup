package game;
//download by http://www.codefans.net
import behavior.*;
import mid.*;
public class Creature {
	public final static byte WAIT=0;
	public final static byte RUN=1;
	public final static byte JUMP=2;
	public final static byte FALL=3;
	public final static byte ATTACK=4;
	public final static byte SPECIAL=5;
	public final static byte HURT=6;
	public final static byte FALLBACK=7;
	public final static byte DIE=8;
	
	public final static byte invincible=1<<1;
	public final static byte active=1<<2;
	public final static byte attacking=1<<3;
	public final static byte spelling=1<<4;
	
	public final static byte cantUP=1<<3;
	public final static byte OnGround=1<<2;
	public final static byte cantLeft=1<<1;
	public final static byte cantRight=1<<0;
	
	public final static int MaxSpeed=1000;
	public Creature next=null;
	public Creature(){
		for(int i=0;i<3;i++){
			sk[i]=new Skill();
		}
		normal();
		active();
		getAction();
	}
	public boolean objLive=false;
	public byte property=0;
	public int sysid=0;
	public byte side=0;//��Ӫ 1�Ѻ÷� 2���˷� 
	public int type=0;
	public int x=0;
	public int y=0;
	public byte width=0;
	public byte height=0;
	public byte direction=1;
	public byte step=0;
	public int speed_x=0;
	public int speed_y=0;
	public int count_x=0;
	public int count_y=0;
	public int JumpSpeed=0;
	public int ActionSpeed=0;
	public byte movestate=0;//00000��0��0��0��
	public long mapid=0;
	public byte fall=0;
	public int hp=0;
	public int damage=0;
	public byte action=0;
	public byte CurrentAction=-1;
	public int countAction=0;
	public byte actiontype=0;//0=���� 1=һ�Σ�
	public long actions[]=null;
	public byte farme=0;
	public byte AI=0;
	public Crebehavior ai=null;
	public long getMapID(){
		return mapid;
	}
	public static int ckeckSpeed(int i){
		if(i>MaxSpeed){
			return MaxSpeed;
		}
		return i;
	}
	//�޵�
	public void invincible(){
		property|=invincible;
	}
	public void normal(){
		if(ifInvincible()){
			property^=invincible;
		}
	}
	public boolean ifInvincible(){
		if((property&invincible)!=0){
			return true;
		}
		return false;
	}
	//���
	public void active(){
		property|=active;
	}
	public void freeze(){
		if(ifActive()){
			property^=active;
		}
	}
	public boolean ifActive(){
		if((property&active)!=0){
			return true;
		}
		return false;
	}
	public void turnback(){
		direction=0;
	}
	public void turnfront(){
		direction=1;
	}
	protected void getAction(){
		if(CurrentAction!=(action*10+direction+direction)){
			CurrentAction=(byte)(action*10+direction+direction);
			actions=WorldCanvas.findAction(500000+type*1000+direction*100+action).farme;
			farme=0;
		}
	}
	protected void doAction(){
		mapid=actions[farme];
		countAction+=WorldCanvas.getdelay();
		if(countAction>=100){
			++farme;
			countAction=0;
		}
		if(farme>=actions.length){
			if(actiontype==0){
				farme=0;
			}
			else{
				if(action==FALLBACK){
					action=DIE;
					actiontype=1;
				}
				else if(action==DIE){
					die();
				}
				else if(action!=DIE){
					action=WAIT;
				}
				actiontype=0;
				farme=0;
			}
		}
	}
	protected void perpareSpell(int i){
		
	}
	protected void castSpell(){ 
		
	}
	protected void move(int min,int max){
		if(speed_y!=0){
			count_y+=WorldCanvas.getdelay();
			if(count_y>=(MaxSpeed-speed_y)){
				y+=(fall+fall-1)*(step+1);
				count_y=0;
			}
		}
		if(speed_x!=0){
			count_x+=WorldCanvas.getdelay();
			if(count_x>=(MaxSpeed-speed_x)){
				if(direction==0&&x-step>min&&ifCanLeft()){
					x+=(direction+direction-1)*step;
				}
				else if(direction==1&&x+step<max&&ifCanRight()){
					x+=(direction+direction-1)*step;
				}
				count_x=0;
			}
		}
	}
	protected void checkLife(){
		if(hp<=0){
			actiontype=1;
			fallback_Action();
		}
		
	}
	public void lifeCycle(int min,int max){
		checkSkill();
		checkLife();
		getAction();
		doAction();
		move(min,max);
		
	}
	public void increaseFallSpeed(int i){
		if(fall==1){
			fall_Action();
			speed_y+=i;
			if(speed_y<980){
				speed_y=980;
			}
			if(speed_y>MaxSpeed){
				speed_y=MaxSpeed;
			}
		}
		else{
			speed_y-=i;
			if(speed_y<=980){
				speed_y=980;
				fall_Action();
			}
		}
	}
	public void jump(){
		//����:�ڹ��������⣬���£�����,ʱ�� �� ����
		if((action==RUN||action==WAIT)&&ifOnGround()){
			fall=0;
			action=JUMP;
			speed_y=JumpSpeed;
		}
	}
	protected void fall_Action(){
		//������������������ʱ�� �ı� ����
		fall=1;
		if(action!=DIE&&action!=FALLBACK&&action!=ATTACK&&action!=HURT){
			action=FALL;
		}
	}
	public void moveback(){
//		����:�ڹ��������⣬���£�����,����ʱ�� �� �����
		if((action!=DIE&&action!=FALLBACK&&action!=ATTACK&&action!=HURT)){
			turnback();
			speed_x=ActionSpeed;
			if(action!=JUMP&&action!=FALL){
				action=RUN;
			}
		}
	}
	public void movefront(){
//		����:�ڹ��������⣬���£�����,����ʱ�� �� ��ǰ��
		if((action!=DIE&&action!=FALLBACK&&action!=ATTACK&&action!=HURT)){
			turnfront();
			speed_x=ActionSpeed;
			if(action!=JUMP&&action!=FALL){
				action=RUN;
			}
		}
	}
	public void fallback_Action(){
//		����:����, ����
		if(action!=DIE){
			action=FALLBACK;
		}
	}
	public void stopMove(){
		if(speed_x!=0&&ifOnGround()){
			speed_x=0;
		}
		if(action==RUN){
			action=WAIT;
		}
	}
	public boolean Attack_Action(){
		if(action!=DIE&&action!=FALLBACK){
			actiontype=1;
			action=ATTACK;
			return true;
		}
		return false;
	}
	public void stopFall(){
		speed_y=0;
		if(action==FALL){
			action=WAIT;
		}
		
	}
	//movestate
	public void OnGround(){
		movestate|=OnGround;
	}
	public boolean ifOnGround(){ 
		if((movestate&OnGround)!=0){
			return true;
		}
		else{
			return false;
		}
	}
	public void LeaveGround(){
		if(ifOnGround()){
			movestate^=OnGround;
		}
	}
	public void CantLeft(){
		movestate|=cantLeft;
	}
	public boolean ifCanLeft(){
		if((movestate&cantLeft)!=0){
			return false;
		}
		return true;
	}
	public void CanLeft(){
		if(!ifCanLeft()){
			movestate^=cantLeft;
		}
	}
	public void CantRight(){
		movestate|=cantRight;
	}
	public boolean ifCanRight(){
		if((movestate&cantRight)!=0){
			return false;
		}
		return true;
	}
	public void CanRight(){
		if(!ifCanRight()){
			movestate^=cantRight;
		}
	}
	public void hurt(int i){
		if(hp>0){
			hp+=i;
			WorldCanvas.damSet(this,i);
			action=HURT;
			actiontype=1;
		}
		stopMove();
	}
	public void die(){
		ai=null;
		sk=null;
		objLive=false;
	}
	public void UseSkill(int i){
		sk[i].useSkill(this);
	}
	public Skill sk[]=new Skill[3];
	public void checkSkill(){
		for(int i=0;i<3;++i){
			if(sk[i]!=null){
				sk[i].run();
			}
		}
	}
}
