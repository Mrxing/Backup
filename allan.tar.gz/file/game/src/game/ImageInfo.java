package game;
//download by http://www.codefans.net
import tool.*;
public class ImageInfo implements AVLbuff{
	long id=0;
	public int xmod=0;
	public int ymod=0;
	public int width=0;
	public int height=0;
	public int centermod=0;
	public ImageInfo(long _id,int _xmod,int _ymod,int _width,int _height,int _centermod){
		id=_id;
		xmod=_xmod;
		ymod=_ymod;
		width=_width;
		height=_height;
		centermod=_centermod;
	}
	public long getAVLnum(){
		return id;
	}
}
