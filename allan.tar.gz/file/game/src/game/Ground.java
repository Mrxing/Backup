package game;

import behavior.*;
import mid.WorldCanvas;
import tool.*;
public class Ground {
	public static int MaxSpeed=1000;
	public final static byte active=1<<2;
	public Ground(){
		active();
	}
	public long mapid=0;
	public byte objstate=0;
	public boolean objLive=false;
	public int sysid=0;
	public Ground next=null;
	public int x=0;
	public int y=0;
	public int speed_x=0;
	public int speed_y=0;
	public byte fall=0;
	public byte direction=0;
	public byte step=2;
	public int count_y=0;
	public int count_x=0;
	public int width=0;
	public int height=0;
	public int type=0;
	public int AI=0;
	public Grobehavior ai=null;
	
	protected void move(){
		if(speed_y!=0){
			count_y+=WorldCanvas.getdelay();
			if(count_y>=(MaxSpeed-speed_y)){
				y+=(fall+fall-1)*step;
				moveTheCre(x/WorldCanvas.groundspace,5,0,(fall+fall-1)*step);
				count_y=0;
			}
		}
		if(speed_x!=0){
			count_x+=WorldCanvas.getdelay();
			if(count_x>=(MaxSpeed-speed_x)){
				x+=(direction+direction-1)*step;
				moveTheCre(x/WorldCanvas.groundspace,5,(direction+direction-1)*step,0);
				count_x=0;
			}
		}
	}
	public void moveup(){
		fall=0;
		speed_y=970;
	}
	public void movedown(){
		fall=1;
		speed_y=970;
	}
	public void moveback(){
			direction=0;
			speed_x=970;
	}
	public void movefront(){
			direction=1;
			speed_x=970;
	}
	public void stopmove(){
		speed_x=0;
	}
	public void moveTheCre(int i,int n,int mx,int my){
		int s=i-(n-1)/2;
		int num=s+n;
		Creature ptr=null;
		for(;s<num;s++){
			if(0<=s&&s<WorldCanvas.groundtotal/WorldCanvas.groundspace){
				ptr=WorldCanvas.Creatures[s];
				while(ptr!=null){
					if(Geometry.checkCut(ptr.x-ptr.width/2,ptr.x+ptr.width/2,x-width/2,x+width/2)&&ptr.y+ptr.height>=y&&ptr.y<y){
						ptr.x+=mx;
						ptr.y+=my;
					}
					ptr=ptr.next;
				}
			}
		}
	}
	public void setMapID(){
		mapid=200000+type*1000;
	}
	//�
	public void active(){
		objstate|=active;
	}
	public void freeze(){
		if(ifactive()){
			objstate^=active;
		}
	}
	public boolean ifactive(){
		if((objstate&active)==active){
			return true;
		}
		return false;
	}
	public void lifeCycle(){
		move();
	}
}
