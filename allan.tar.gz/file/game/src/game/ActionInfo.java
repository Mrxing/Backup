package game;
//download by http://www.codefans.net
import tool.*;
public class ActionInfo implements AVLbuff{
	protected long id=0;
	public long farme[]=null;
	public ActionInfo(long _id,long[] _farme){
		id=_id;
		farme=_farme;
	}
	public long getAVLnum(){
		return id;
	}
}
