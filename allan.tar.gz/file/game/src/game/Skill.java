package game;
//download by http://www.codefans.net
import mid.*;
public class Skill {
	public int id;//000���� 100ħ�� 200��Ʒ
	public int cool;
	public int count;
	byte state;//0׼����,1׼����
	public void useSkill(Creature cre){
		if(state==0){
			state=1;
			int i=id/100;
			int n=id%100;
			switch(i){
			case 0: cre.Attack_Action();WorldCanvas.createDamage(n,cre,200);break;
			case 1: break;
			case 2: break;
			}
		}
	}
	public void run(){
		if(state==1){
			count+=WorldCanvas.getdelay();
			if(count>=cool){
				count=0;
				state=0;
			}
		}
	}
	
}
