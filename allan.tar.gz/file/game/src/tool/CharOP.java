package tool;

public abstract class CharOP {
	public static byte sign=1;
	public static boolean equal(char[] a,char[] b){
		if(a.length!=b.length){
			return false;
		}
		for(int i=0;i<a.length;++i){
			if(a[i]!=b[i]){
				return false;
			}
		}
		return true;
	}
	public static void copy(char[] a,char[] b){
		if(a==null){
			a=new char[b.length];
		}
		if(a.length!=b.length){
			a=null;
			a=new char[b.length];
		}
		for(int i=0;i<a.length;++i){
			a[i]=b[i];
		}
	}
	
	protected static char record[]=new char[20];
	protected static int rcount=0;
	public static void record(char rec){
		if(rec=='-'){
			sign=-1;
			return;
		}
		if(rcount<20){
			record[rcount++]=rec;
		}
	}
	public static void clear(){
		rcount=0;
		sign=1;
	}
	public static boolean ifrecordis(final String str){
		if(rcount!=str.length()){
			return false;
		}
		for(int i=0;i<rcount;++i){
			if(record[i]!=str.charAt(i)){
				return false;
			}
		}
		return true;
	}
	public static char[] getChars(){
		char temp[]=new char[rcount];
		for(int i=0;i<rcount;++i){
			temp[i]=record[i];
		}
		rcount=0;
		sign=1;
		return temp;
	}
	
	public static int getInt(){
		int num=0;
		int s=sign;
		for(int i=0;i<rcount;++i){
			num+=(record[i]-48)*MathFP.toInt(MathFP.pow(MathFP.toFP(10),MathFP.toFP(rcount-i-1)));
		}
		rcount=0;
		sign=1;
		return num*s;
	}
	public static long getIong(){
		long num=0;
		int s=sign;
		for(int i=0;i<rcount;++i){
			num+=(record[i]-48)*MathFP.toInt(MathFP.pow(MathFP.toFP(10),MathFP.toFP(rcount-i-1)));
		}
		rcount=0;
		sign=1;
		return num*s;
	}
	public static char readUnicode(byte b1,byte b2){
		char temp=0;
		temp= (char)((b2 & 0xff)|((b1 << 8)&0xff00)); 
		return temp;
	}
	
}
