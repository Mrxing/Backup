package tool;

public abstract class Geometry {
	public static boolean checkCut(int xb1,int xe1,int xb2,int xe2){
		if(xe1<=xe2&&xb2<=xe1){
			return true;
		}
		else if(xe1>xe2&&xb1<=xe2){
			return true;
		}
		else{
			return false;
		}
	}
}
