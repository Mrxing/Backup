package tool;

public interface AVLbuff {
	public long getAVLnum();
}
