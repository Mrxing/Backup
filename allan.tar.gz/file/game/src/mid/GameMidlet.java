package mid;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;
public class GameMidlet extends MIDlet implements CommandListener{
	public final static byte STOP=0;
	public final static byte RUN=1;
	public final static byte END=2;
	public static byte ProgramState=STOP;
	
	Command lsb=null;
	Command rsb=null;
	Display GMDis=null;
	WorldCanvas WC=null;
	Thread world=null;
	
	public GameMidlet() {
		super();
		
	}
	protected void startApp() throws MIDletStateChangeException {
		
		if(ProgramState==STOP){
			WC=new WorldCanvas(this);
			WC.setCommandListener(this);
			rsb=new Command("",Command.SCREEN,1);
			lsb=new Command("",Command.EXIT,2);
			WC.addCommand(lsb);
			WC.addCommand(rsb);
			GMDis=Display.getDisplay(this);
			GMDis.setCurrent(WC);
			world=new Thread(WC);
			world.start();
		}
		else if(ProgramState==RUN){
			
		}

	}
	public void commandAction(Command command,Displayable displayable){
		if(command==lsb){
			WC.set_Key(WorldCanvas.LSB_G);
		}
		else if(command==rsb){
			WC.set_Key(WorldCanvas.RSB_G);
		}
	}
	protected void pauseApp() {
	}

	
	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
		

	}

}
