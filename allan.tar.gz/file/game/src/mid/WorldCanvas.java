package mid;

import tool.*;
import behavior.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.Random;
import javax.microedition.lcdui.*;

import damage.*;
import game.*;
public class WorldCanvas extends Canvas implements Runnable{
	protected GameMidlet Gmid=null;
	public WorldCanvas(GameMidlet _mid){
		Gmid=_mid;
		perpare_Engine();
	}
	protected void perpare_Engine(){
		perpare_Key();
		perpare_Res();
		perpare_Ren();
	}
	protected void paint(Graphics g){
		flushGraphics(g);
	}
	protected void keyPressed(int arg){
		Press_Key(getGameAction(arg));
	}
	protected void keyReleased(int arg){
		Release_Key(getGameAction(arg));
	}
	protected void showNotify(){
		if(GameMidlet.ProgramState==GameMidlet.STOP){
			GameMidlet.ProgramState=GameMidlet.RUN;
		}
		else if(GameMidlet.ProgramState==GameMidlet.RUN){
			pressed_Button(7,0);
		}
	}
	protected void hideNotify(){
		pressed_Button(6,0);
	}
	public void run(){
		run_Engine();
		System.gc();
		Gmid.notifyDestroyed();
	}
	//Engine
	protected int State_Engine=S_Setting;
	protected void run_Engine(){
		while(State_Engine!=S_Stop){
			probegin=System.currentTimeMillis();
			clear_Ren();
			perform_Button();
			answer_Engine();
			perform_Engine();
			proend=System.currentTimeMillis();
			usedtime=(int)(proend-probegin);
			if(usedtime<delay){
				try {
					Thread.sleep(delay-usedtime);
				} catch (InterruptedException e) {
				}
			}
		}
	}
	
	protected void perform_Engine(){
		perform_Key();
		switch(State_Engine){
		case S_Setting:
			perform_EngineSetting();
			break;
		case S_Game:
			control_Game();
			perform_Game();
			break;
		case S_Cushion:
			break;
		}
		useRandom();
		clockRun();
		repaint_Ren();
	}
	protected final static int S_Stop=0;
	protected final static int S_Game=3;
	protected final static int S_Setting=4;
	protected final static int S_Cushion=7;
//TODO request
	protected static int request[]=new int[20];
	protected static int setquest=0;
	public static void request(int type,int r){
		request[setquest++]=type;
		request[setquest++]=r;
	}
	protected void M_Engine(int i){//1
		switch(i){
		case 1://�򿪿���
			enableControl=true;
			break;
		case 2://�رտ���
			enableControl=false;
			break;
		case 3://�˳���Ϸ
			State_Engine=S_Stop;
			break;
		case 4://������Ϸ
			State_Engine=S_Game;
			break;
		case 5:
			
			break;
		case 6:
			break;
		}
	}
	protected void M_Key(int i){//2
		switch(i){
		case 1://����
			KeyModule=SIGNLE;
			break;
		case 2://����
			KeyModule=MULT;
			break;
		case 3:
	
			break;
		case 4:
	
			break;
		}
	}
	protected void M_Resourse(int i){//3
		switch(i){
		case 1://��ȡLOGOͼ
			loadImage_Logo();
			break;
		case 2://�ͷ�LOGOͼ
			release_Logo();
			break;
		case 3://��ȡMENUͼ
			loadImage_Menu();
			break;
		case 4://�ͷ�MENUͼ
			release_Menu();
			break;
		case 5://�ͷ���Ϸ��Դ
			releaseGameRes();
			break;
		case 6:
			
			break;
		case 7:
			
			break;
		case 8:
			
			break;
		case 9:
			
			break;
		case 10:
		
			break;
		}
		
	}
	protected void M_Render(int i){//4
		switch(i){
		case 1:
			
			break;
		case 2:
			
			break;
		case 3:
	
		}
	}
	protected void M_Sound(int i){//5
		switch(i){
		case 1://�ر�����
			enable_Sound=false;
			break;
		case 2://������
			enable_Sound=true;
		case 3:
	
			break;
		case 4:
	
			break;
		}
	}
	protected void M_Game(int i){//6
		switch(i){
		case 1://������Ϸ����
			State_Game=MineMenu_Game;
			break;
		case 2://��ȡ��Ϸ
			perpare_Load();
			break;
		case 3://��ʼ��Ϸ
			init_Game();
			break;
		case 4://�ͷ���Ϸ����
			release_Game();
			break;
		case 5://pause
			Pause();
			break;
		case 6://�ָ�
			resume();
			break;
		case 7://ϵͳ�˵�
			GSenter();
			break;
		case 8://ϵͳ�˵�����Ϸ
			GSresume();
			break;
		}
	}
	
	
	protected void answer_Engine(){
		for(int i=0;i<setquest-1;i+=2){
			switch(request[i]){
			case 1://Engine
				M_Engine(request[i+1]);
				break;
			case 2://Key
				M_Key(request[i+1]);
				break;
			case 3://Resourse
				M_Resourse(request[i+1]);
				break;
			case 4://Render
				M_Sound(request[i+1]);
				break;
			case 5://Sound
				M_Render(request[i+1]);
				break;
			case 6://Game
				M_Game(request[i+1]);
				break;
			}
		}
		setquest=0;	
	}


//	TODO SysButton

	protected int id_Button;
	protected int wt_Button;
	protected int ct_Button;
	public void pressed_Button(int i,int w){
		if(id_Button==0){
			id_Button=i;
			wt_Button=w;
		}
	}
	protected void perform_Button(){
		if(id_Button!=0){
			ct_Button+=getdelay();
			if(ct_Button>=wt_Button){
				switch(id_Button){
				case 1://�ر�������ʼ��Ϸ
					request(5,2);
					request(3,1);
					request(3,1);
					request(1,4);
					break;
				case 2://��������ʼ��Ϸ
					request(5,1);
					request(3,1);
					request(3,1);
					request(1,4);
					break;
				case 3://����LOGO
					request(3,2);
					request(3,3);
					request(6,1);
					break;
				case 4://LOAD��Ϸ
					request(6,2);
					request(3,4);
					break;
				case 5://������Ϸ
					request(2,2);
					request(6,3);
					System.gc();
					break;
				case 6://ϵͳ��ͣ
					request(1,2);
					request(2,1);
					request(6,5);
					break;
				case 7://ϵͳ�ָ�
					request(1,1);
					break;
				case 8://��ͣ�������Ϸ
					request(6,6);
					break;
				case 9://�˳���Ϸ
					request(1,3);
					break;
				case 10://����ϵͳ�˵�
					request(6,7);
					request(2,1);
					break;
				case 11://ϵͳ�˵�������Ϸ
					request(6,8);
					request(2,2);
					break;
				case 12://���¿�ʼ
					request(6,4);
					request(6,2);
					break;
				case 13://���ز˵�
					request(6,4);
					request(3,5);
					request(3,3);
					request(2,1);
					request(6,1);
				}
				id_Button=0;
				wt_Button=0;
				ct_Button=0;
			}
		}
	}
	
//	TODO Time&FPS&Random
	public static int getdelay(){
		return delay+4;
	}
	protected static int fps=40;
	protected static int delay=(1000/fps);
	protected long probegin;
	protected long proend;
	protected int usedtime;
	
	protected static int hour;
	protected static int min;
	protected static int sec;
	protected static int mill;
	protected void clockRun(){
		mill+=getdelay();
		if(mill>=1000){
			mill-=1000;
			sec+=1;
			if(sec>=60){
				sec-=60;
				min+=1;
				if(min>=60){
					min-=60;
					hour+=1;
					if(hour>=60){
						hour=0;
					}
				}
			}
		}
	}
	//random
	protected static Random rn=new Random();
	protected static int rnum=0;//0--100
	protected static int rbuff=0;
	protected static int rRange=100;
	protected void useRandom(){
		rn.nextInt();    
	}
	public static int getRandom(){
		rbuff=rnum;
		rn.nextInt();
		rnum=(rn.nextInt()>>>1)%rRange;
		return rbuff;
	}
	//TODO Font
	protected Font BF=Font.getFont(Font.FACE_SYSTEM,Font.STYLE_PLAIN,Font.SIZE_LARGE);
	protected Font MF=Font.getFont(Font.FACE_SYSTEM,Font.STYLE_PLAIN,Font.SIZE_MEDIUM);
	protected Font SF=Font.getFont(Font.FACE_SYSTEM,Font.STYLE_PLAIN,Font.SIZE_SMALL);
	protected void Font_big(Graphics gra,int r,int g,int b){
		gra.setFont(BF);
		gra.setColor(r,g,b);
	}
	protected void Font_small(Graphics gra,int r,int g,int b){
		gra.setFont(SF);
		gra.setColor(r,g,b);
	}
	protected void Font_middle(Graphics gra,int r,int g,int b){
		gra.setFont(MF);
		gra.setColor(r,g,b);
	}
	
	//TODO key
	
	public final static int UP_G=1<<0;
	public final static int DOWN_G=1<<1;
	public final static int LEFT_G=1<<2;
	public final static int RIGHT_G=1<<3;
	public final static int FIRE_G=1<<4;
	public final static int JUMP_G=1<<5;
	public final static int SPELL_G=1<<6;
	public final static int LSB_G=1<<7;
	public final static int RSB_G=1<<8;
	
	protected static int keyTotal=4;
	protected static int[] keys;
	protected static int keyNum;
	protected static int keyset;
	protected static int keyget;
	
	protected static byte buffup;
	protected static byte buffdown;
	protected static byte buffleft;
	protected static byte buffright;
	protected static byte bufffire;
	protected static byte buffjump;
	protected static byte buffspell;
	protected static int key;
	
	protected static int KeyModule;
	
	protected final static int SIGNLE=0;
	protected final static int MULT=1;
	public static int get_Key(){
		if(keyNum!=0){
			key=keys[keyget];
			keys[keyget]=0;
			--keyNum;
			++keyget;
			if(keyget>=4){
				keyget=0;
			}
			return key;
		}
		return 0;
	}
	protected void set_Key(int i){
		keys[keyset]|=i;
		++keyNum;
		++keyset;
		if(keyset>=4){
			keyset=0;
		}
	}
	public boolean keyIs(int _key,int mark){
		if((_key&mark)!=0){
			return true;
		}
		return false;
	}
	
	protected void Press_Key(int _key){
		if(KeyModule==SIGNLE){
			switch(_key){
			case KUP:    set_Key(UP_G);break;
			case KDOWN:  set_Key(DOWN_G);break;
			case KLEFT:  set_Key(LEFT_G);break;
			case KRIGHT: set_Key(RIGHT_G);break;
			case KFIRE:  set_Key(FIRE_G);break;
			case KJUMP:  set_Key(JUMP_G);break;
			case KSPELL: set_Key(SPELL_G);break;
			default:break;
			}
		}
		else if(KeyModule==MULT){
			switch(_key){
			case KUP:    buffup|=UP_G;break;
			case KDOWN:  buffdown|=DOWN_G;break;
			case KLEFT:  buffleft|=LEFT_G;break;
			case KRIGHT: buffright|=RIGHT_G;break;
			case KFIRE:  bufffire|=FIRE_G;break;
			case KJUMP:  buffjump|=JUMP_G;break;
			case KSPELL: buffspell|=SPELL_G;break;
			default:break;
			}
		}
		
	}
	protected static void Release_Key(int _key){
		if(KeyModule==SIGNLE){
			switch(_key){
			case KUP:    buffup=0;break;
			case KDOWN:  buffdown=0;break;
			case KLEFT:  buffleft=0;break;
			case KRIGHT: buffright=0;break;
			case KFIRE:  bufffire=0;break;
			case KJUMP:  buffjump=0;break;
			case KSPELL: buffspell=0;break;
			default:break;
			}
		}
		else if(KeyModule==MULT){
			switch(_key){
			case KUP:    buffup=0;break;
			case KDOWN:  buffdown=0;break;
			case KLEFT:  buffleft=0;break;
			case KRIGHT: buffright=0;break;
			case KFIRE:  bufffire=0;break;
			case KJUMP:  buffjump=0;break;
			case KSPELL: buffspell=0;break;
			default:break;
			}
		}
		
	}
	
	protected void save_Key(){
		if(KeyModule==SIGNLE){
			
		}
		else if(KeyModule==MULT){
			if(keyNum<keyTotal&&((buffup!=0)||(buffdown!=0)||(buffleft!=0)||(buffright!=0)||(bufffire!=0)||(buffjump!=0)||(buffspell!=0))){
				keys[keyset]|=buffup;
				keys[keyset]|=buffdown;
				keys[keyset]|=buffleft;
				keys[keyset]|=buffright;
				keys[keyset]|=bufffire;
				keys[keyset]|=buffjump;
				keys[keyset]|=buffspell;
				++keyNum;
				++keyset;
				if(keyset>=4){
					keyset=0;
				}
			}
		}
	}
	
	protected void perpare_Key(){
		keys=new int[keyTotal];
	}
	protected void perform_Key(){
		save_Key();
	}
	protected final static int KUP=Canvas.UP;
	protected final static int KDOWN=Canvas.DOWN;
	protected final static int KLEFT=Canvas.LEFT;
	protected final static int KRIGHT=Canvas.RIGHT;
	protected final static int KFIRE=Canvas.FIRE;
	protected final static int KJUMP=Canvas.GAME_A;
	protected final static int KSPELL=Canvas.GAME_B;
	

//TODO Res
	protected static String pngpath="/pic/";
	protected static Image logo1;
	protected static Image logo2;
	protected static Image menu;
	protected static Image background;
	protected void loadImage_Logo(){
		if(logo1==null||logo2==null){
			try {
				logo1=Image.createImage(pngpath+"Logo"+".png");
				logo2=Image.createImage(pngpath+"Mbox"+".png");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	protected void release_Logo(){
		logo1=null;
		logo2=null;
	}
	protected void loadImage_Menu(){
		try {
			menu=Image.createImage(pngpath+"menu"+".png");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	protected void release_Menu(){
		menu=null;
	}
	
	//gameres
	public static int CreatureImages=1;
	public static int GroundImages=1<<1;
	public static int Actions=1<<2;
	protected int resstate=0;
	protected static AVLTree GameRes;
	protected Image itemp;
	protected ImageInfo iitemp;
	
	protected int getType(long l){
		return (int)l/100000;
	}
	protected static ImageInfo findImageInfo(long id){
		ImageInfo temp=(ImageInfo)GameRes.find(id);
		if(temp!=null){
			return temp;
		}
		else{
			return null;
		}
	}
	public static ActionInfo findAction(long id){
		ActionInfo temp=(ActionInfo)GameRes.find(id);
		if(temp!=null){
			return temp;
		}
		else{
			return (ActionInfo)GameRes.find(id-(id%10));
		}
	}
	protected Image creature=null;
	protected void LoadCreatureImage(){
			if((resstate&CreatureImages)!=0){
				return;
			}
			else{
				resstate|=CreatureImages;
			}
			try {
				creature=Image.createImage(pngpath+"creature"+".png");
			} catch (IOException e) {
				e.printStackTrace();
			}
			int imagex=creature.getWidth();
			int imagey=creature.getHeight();
			long id=0;
			int xmod=0;
			int ymod=0;
			int width=0;
			int height=0;
			int centermod=0;
			byte Btemp[]=readFile(respath,"creimginfo");
			char cha=0;
			int scount=0;
			boolean key=false;
			for(int i=0;i<Btemp.length-1;i+=2){
				cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
				if(cha==32){
					scount++;
					key=true;
				}
				else if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
					scount++;
					i+=2;
					key=true;
				}
				else if(cha==35){
					break;
				}
				if(key==true){
					switch(scount){
					case 1:
						id=CharOP.getIong();
						break;
					case 2:
						xmod=CharOP.getInt();
						break;
					case 3:
						ymod=CharOP.getInt();
						break;
					case 4:
						width=CharOP.getInt();
						break;
					case 5:
						height=CharOP.getInt();
						break;
					case 6:
						centermod=CharOP.getInt();
						scount=0;
						GameRes.insert(new ImageInfo(id,xmod,ymod,width,height,centermod-xmod));
						GameRes.insert(new ImageInfo(id-100,imagex-xmod-width,ymod+imagey/2,width,height,imagex-centermod-(imagex-xmod-width)));
						break;
					}
					key=false;
				}
				else{
					CharOP.record(cha);
				}
			}
		
	}
	protected Image ground=null;
	protected Image effect=null;
	protected void LoadGroundImage(){
			if((resstate&GroundImages)!=0){
				return;
			}
			else{
				resstate|=GroundImages;
			}
			try {
				effect=Image.createImage(pngpath+"effect"+".png");
				ground=Image.createImage(pngpath+"ground"+".png");
			} catch (IOException e) {
				e.printStackTrace();
			}
			long id=0;
			int xmod=0;
			int ymod=0;
			int width=0;
			int height=0;
			int centermod=0;
			byte Btemp[]=readFile(respath,"groeffimginfo");
			char cha=0;
			int scount=0;
			boolean key=false;
			for(int i=0;i<Btemp.length-1;i+=2){
				cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
				if(cha==32){
					scount++;
					key=true;
				}
				else if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
					scount++;
					i+=2;
					key=true;
				}
				else if(cha==35){
					break;
				}
				if(key==true){
					switch(scount){
					case 1:
						id=CharOP.getIong();
						break;
					case 2:
						xmod=CharOP.getInt();
						break;
					case 3:
						ymod=CharOP.getInt();
						break;
					case 4:
						width=CharOP.getInt();
						break;
					case 5:
						height=CharOP.getInt();
						break;
					case 6:
						centermod=CharOP.getInt();
						scount=0;
						GameRes.insert(new ImageInfo(id,xmod,ymod,width,height,centermod-xmod));
						break;
					}
					key=false;
				}
				else{
					CharOP.record(cha);
				}
			}
		
	}
	protected void LoadGameAction(){
			if((resstate&Actions)!=0){
				return;
			}
			else{
				resstate|=Actions;
			}
			byte Btemp[]=readFile(respath,"action");
			char cha=0;
			int scount=-1;
			int ifend=0;
			long temp[]=new long[10];
			boolean key=false;
			for(int i=0;i<Btemp.length-1;i+=2){
				cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
				if(cha==32){
					scount++;
					key=true;
				}
				else if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
					scount++;
					ifend=1;
					i+=2;
					key=true;
				}
				else if(cha==35){
					break;
				}
				if(key==true){
					switch(ifend){
					case 0:
						temp[scount]=CharOP.getIong();
						break;
					case 1:
						temp[scount]=CharOP.getIong();
						long action1[]=new long[scount];
						long action2[]=new long[scount];
						for(int n=0;n<scount;++n){
							action1[n]=temp[n+1];
							action2[n]=temp[n+1]-100;
						}
						GameRes.insert(new ActionInfo(temp[0],action1));
						GameRes.insert(new ActionInfo(temp[0]-100,action2));
						scount=-1;
						ifend=0;
						break;
					}
					key=false;
				}
				else{
					CharOP.record(cha);
				}
			}
	}
	protected void releaseGameRes(){
		ground=null;
		creature=null;
		GameRes.clear();
		resstate=0;
		System.gc();
	}
	protected static int wordnum=20;
	protected static String syswords[]=null;
	protected void loadwords(){
		if(syswords==null){
			syswords=new String[wordnum];
			byte temp[]=readFile(respath,"string");
			char cha=0;
			int scount=0;
			int ncount=0;
			boolean key=false;
			for(int i=0;i<temp.length-1;i+=2){
				cha=CharOP.readUnicode(temp[i],temp[i+1]);
				if(cha==32){
					scount++;
					key=true;
				}
				else if(i<temp.length-1&&cha==13&&CharOP.readUnicode(temp[i+2],temp[i+3])==10){
					scount++;
					i+=2;
					key=true;
				}
				else if(cha==35){
					return;
				}
				if(key==true){
					switch(scount){
					case 1:
						CharOP.getInt();
						break;
					case 2:
						syswords[ncount]=new String(CharOP.getChars());
						scount=0;
						ncount++;
						if(ncount>=wordnum){
							System.out.println("words out of bouns");
							return;
						}
						break;
					}
					key=false;
				}
				else{
					CharOP.record(cha);
				}
			}
		}
	}
	
	public static String getString(int id){
		if(id<wordnum){
			return syswords[id];
		}
		else{
			return "";
		}
	}
	protected void perpare_Res(){
		loadwords();
		GameRes=new AVLTree();
	}
	
	protected InputStream is;
	protected final String respath="/resourse/"; 
	protected final String mappath="/map/";
	protected final String objectpath="/object/";
	protected byte buff[];
	public final byte[] readFile(String path,final String sname){
		if(buff==null){
			buff=new byte[2048];
		}
		is=getClass().getResourceAsStream(path+sname+".txt");
		try {
			is.read(buff);
			is.close();
			is=null;
			System.gc();
		} catch (IOException e) {
			e.printStackTrace();
		}
		for(int i=2;i<buff.length;){
			if(buff[i]==0&&buff[i+1]==0){
				buff[i-2]=buff[i];
				buff[i-1]=buff[i+1];
				break;
			}
			buff[i-2]=buff[i];
			buff[i-1]=buff[i+1];
			i+=2;
		}
		return buff;
	}
	
	//TODO Sound
	boolean enable_Sound=false;
//	public void perpare_Sound(){
//		
//	}
	//TODO Render
	protected Canvas can=null;
	protected static Image ImageBuff=null;
	protected Graphics GIB=null;
	
	protected void clear_Ren(){
		GIB.setClip(0,0,ImageBuffWidth,ImageBuffHeight);
		GIB.setColor(R,G,B);
		GIB.fillRect(0,0,ImageBuffWidth,ImageBuffHeight);
	}
	protected void refashionImageBuff(){
		if(ImageBuff==null){
			ImageBuff=Image.createImage(ImageBuffWidth,ImageBuffHeight);
			GIB=ImageBuff.getGraphics();
			GIB.setColor(this.R,this.G,this.B);
			GIB.fillRect(0,0,ImageBuffWidth,ImageBuffHeight);
		}
	}
	protected static void flushGraphics(Graphics g){
		g.setClip(0,0,ImageBuffWidth,ImageBuffHeight);
		g.drawImage(ImageBuff,0,0,0);
	}
	protected void perpare_Ren(){
		can=this;
		refashionImageBuff();
	}
	protected void repaint_Ren(){
		can.repaint();
		can.serviceRepaints();
	}
	int drawx=0;
	int drawy=0;
	//protected void 
	protected void drawgame(long mapid,int x,int y){
		int type=getType(mapid);
		switch(type){
		case 1:
			itemp=creature;
			break;
		case 2:
			itemp=ground;
			break;
		case 3:
			itemp=effect;
			break;
		default:
			return;
		}
		iitemp=findImageInfo(mapid);
		if(iitemp==null){
			System.out.println(mapid+" "+"not"+" "+"found");
			return;
		}
		drawx=x-screenx-iitemp.centermod;
		drawy=y-screeny-iitemp.height;
		GIB.setClip(drawx,drawy,iitemp.width,iitemp.height);
		GIB.drawImage(itemp,drawx-iitemp.xmod,drawy-iitemp.ymod,0);
		itemp=null;
	}
	protected void drawsys(long mapid,int x,int y){
		int type=getType(mapid);
		switch(type){
		case 1:
			itemp=creature;
			break;
		case 2:
			itemp=ground;
			break;
		case 3:
			itemp=effect;
			break;
		default:
			return;
		}
		iitemp=findImageInfo(mapid);
		if(iitemp==null){
			System.out.println(mapid+" "+"not"+" "+"found");
			return;
		}
		drawx=x-iitemp.centermod;
		drawy=y-iitemp.height;
		GIB.setClip(drawx,drawy,iitemp.width,iitemp.height);
		GIB.drawImage(itemp,drawx-iitemp.xmod,drawy-iitemp.ymod,0);
		itemp=null;
	}
	//����
	protected static int ImageBuffWidth=176;
	protected static int ImageBuffHeight=208;
	protected int R=222;
	protected int G=222;
	protected int B=214;
	//TODO EngineSetting
	protected void perform_EngineSetting(){
		control_EngineSetting();
		draw_EngineSetting();
	}
	protected void draw_EngineSetting(){
		GIB.setColor(160,160,147);
		GIB.fillRect(36,73,100,26);
		Font_big(GIB,222,222,214);
		GIB.drawString(getString(0),45,76,0);
		Font_middle(GIB,160,160,147);
		GIB.drawString(getString(1),4,188,0);
		GIB.drawString(getString(2),146,188,0);
	
	}
	protected void control_EngineSetting(){
		int i=get_Key();
		if(enableControl){
			if(keyIs(i,LSB_G)){
				pressed_Button(1,0);
			}
			else if(keyIs(i,RSB_G)){
				pressed_Button(2,0);
			}
		}
		
	}
	//TODO game
	protected int Level=0;//0-2
	protected static byte State_Game=0;
	protected final byte Logo_Game=0;
	protected final byte MineMenu_Game=1;
	protected final byte Load_Game=2;
	protected final byte Start_Game=3;
	protected final byte Pause_Game=4;
	protected final byte List_Game=5;
	protected final byte System_Game=6;
	protected boolean enableControl=true;
	protected int recordtime=0;
	protected void init_Game(){
		State_Game=Start_Game;
		Level=0;
	}
	protected void release_Game(){
		release_Object();
	}
	protected void control_Game(){
		int i=get_Key();
		if(enableControl){
			switch(State_Game){
			case Logo_Game:
				control_Logo(i);
				break;
			case MineMenu_Game:
				control_MineMenu(i);
				break;
			case Load_Game:
				control_LoadGame(i);
				break;
			case Start_Game:
				control_player(i);
				break;
			case Pause_Game:
				Pause_Control(i);
				break;
			case List_Game:
				break;
			case System_Game:
				GScontrol(i);
				break;
			}
		}
	}
	protected void perform_Game(){
		switch(State_Game){
		case Logo_Game:
			perform_Logo();
			break;
		case MineMenu_Game:
			perform_MineMenu();
			break;
		case Load_Game:
			LoadGame();
			break;
		case Start_Game:
			perform_background();
			perform_Object();
			damageProcess();
			showDam();
			perform_player();
			break;
		case Pause_Game:
			Pause_Show();
			break;
		case List_Game:
			break;
		case System_Game:
			GSshow();
			break;
		}
	}
	//TODO gamesys
	protected byte gsnum=0;
	protected byte gsbegin=0;
	protected byte gsend=3;
	
	protected void GSenter(){
		if(player.hp<=0){
			gsbegin=1;
			gsnum=1;
		}
		else{
			gsbegin=0;
			gsnum=0;
		}
		State_Game=System_Game;
	}
	protected void GSresume(){
		State_Game=Start_Game;
	}
	protected void GSshow(){
		switch(gsnum){
		case 0:GIB.setColor(138,138,138);GIB.fillRect(61,128,50,12);break;
		case 1:GIB.setColor(138,138,138);GIB.fillRect(61,142,50,12);break;
		case 2:GIB.setColor(138,138,138);GIB.fillRect(61,156,50,12);break;
		case 3:GIB.setColor(138,138,138);GIB.fillRect(61,170,50,12);break;
		}
		Font_middle(GIB,82,82,82);
		GIB.drawString(getString(10),63,126,0);
		Font_middle(GIB,82,82,82);
		GIB.drawString(getString(11),63,140,0);
		Font_middle(GIB,82,82,82);
		GIB.drawString(getString(5),63,154,0);
		Font_middle(GIB,82,82,82);
		GIB.drawString(getString(13),63,168,0);
	}
	
	protected void GScontrol(int i){
		if(keyIs(i,UP_G)){
			gsnum--;
			if(gsnum<gsbegin){
				gsnum=gsbegin;
			}
		}
		if(keyIs(i,DOWN_G)){
			gsnum++;
			if(gsnum>gsend){
				gsnum=gsend;
			}	
		}
		if(keyIs(i,FIRE_G)){
			switch(gsnum){
			case 0:pressed_Button(11,0);break;
			case 1:pressed_Button(12,0);break;
			case 2:break;
			case 3:pressed_Button(13,0);break;
			}
		}
	}
	//TODO pause
	protected byte scopy=0;
	protected byte cp=0;
	public void Pause(){
		if(State_Engine!=S_Game){
			return;
		}
		scopy=State_Game;
		cp=0;
		State_Game=Pause_Game;
	}
	public void resume(){
		if(State_Engine!=S_Game){
			return;
		}
		if(scopy==Start_Game){
			KeyModule=MULT;
		}
		State_Game=scopy;
		scopy=0;
	}
	public void Pause_Show(){
		GIB.setClip(0,0,176,208);
		GIB.setColor(160,160,147);
		GIB.fillRect(0,0,176,208);
		GIB.setColor(222,222,222);
		GIB.fillRect(40,43,95,113);
		switch(cp){
		case 0:GIB.setColor(80,80,80);GIB.fillRect(49,80,10,10);GIB.fillRect(118,80,10,10);break;
		case 1:GIB.setColor(80,80,80);GIB.fillRect(49,116,10,10);GIB.fillRect(118,116,10,10);break;
		}
		Font_big(GIB,80,80,80);
		GIB.drawString(getString(10),61,75,0);
		Font_big(GIB,80,80,80);
		GIB.drawString(getString(6),61,111,0);
	}
	public void Pause_Control(int i){
		if(keyIs(i,UP_G)){
			cp--;
			if(cp<0){
				cp=0;
			}
		}
		if(keyIs(i,DOWN_G)){
			cp++;
			if(cp>1){
				cp=1;
			}
		}	
		if(keyIs(i,FIRE_G)){
			switch(cp){
			case 0:
				pressed_Button(8,0);
				break;
			case 1:
				pressed_Button(9,0);
				break;
			}
		}
	}
	//TODO LogoGame
	protected int wait_Logo=0;
	protected int last_Logo;
	protected int num_Logo;
	protected void perform_Logo(){
		last_Logo+=getdelay();
		if(last_Logo>=wait_Logo){
			num_Logo++;
			last_Logo=0;
		}
		switch(num_Logo){
		case 0:
			GIB.drawImage(logo1,0,0,0);
			break;
		case 1:
			GIB.drawImage(logo2,0,0,0);
			break;
		case 2:
			
			break;
		case 3:
			pressed_Button(3,0);
			break;
		}
	}
	protected void control_Logo(int i){
		
	}
	//TODO MineMenu
	public int totalbutton=3;
	public int selectedbutton=0;
	protected void perform_MineMenu(){
		GIB.setColor(128,128,128);
		GIB.fillRect(0,0,176,208);
		//GIB.drawImage(menu,0,40,0);
		Font_big(GIB,227,227,227);
		GIB.drawString(getString(12),57,23,0);
		switch(selectedbutton){
		case 0:GIB.setColor(192,192,192);GIB.fillRect(55,131,6,6);GIB.fillRect(108,131,6,6);break;
		case 1:GIB.setColor(80,80,80);GIB.fillRect(55,145,6,6);GIB.fillRect(108,145,6,6);break;
		case 2:GIB.setColor(192,192,192);GIB.fillRect(55,159,6,6);GIB.fillRect(108,159,6,6);break;
		case 3:GIB.setColor(80,80,80);GIB.fillRect(55,173,6,6);GIB.fillRect(108,173,6,6);break;
		}
		Font_middle(GIB,227,227,227);
		GIB.drawString(getString(3),63,126,0);
		Font_middle(GIB,227,227,227);
		GIB.drawString(getString(4),63,140,0);
		Font_middle(GIB,227,227,227);
		GIB.drawString(getString(5),63,154,0);
		Font_middle(GIB,227,227,227);
		GIB.drawString(getString(6),63,168,0);
	}
	protected void control_MineMenu(int i){
		if(keyIs(i,UP_G)){
			--selectedbutton;
			if(selectedbutton<0){
				selectedbutton=0;
			}
		}
		else if(keyIs(i,DOWN_G)){
			++selectedbutton;
			if(selectedbutton>totalbutton){
				selectedbutton=totalbutton;
			}
		}
		else if(keyIs(i,FIRE_G)){
			switch(selectedbutton){
			case 0:
				pressed_Button(4,0);
				break;
			case 1:
				
				break;
			case 2:
				
				break;
			case 3:
				pressed_Button(9,0);
				break;
			}
		}
	}
	
	
// TODO Load
	protected char storys[]=null;
	protected String caption="";
	protected byte storynum=100;
	protected void perpare_Load(){
		State_Game=Load_Game;
		step_Load=0;
		if(storys==null){
			storys=new char[storynum];
		}
		else{
			for(int i=0;i<storynum;++i){
				storys[i]=0;
			}
		}
	}
	protected int step_Load=0;
	protected void LoadStory(int num){
		int i=0;
		int count=0;
		int step=0;
		boolean key=false;
		boolean door=true;
		char cha=0;
		byte temp[]=readFile(respath,"story");
		CharOP.clear();
		while(door){
			cha=CharOP.readUnicode(temp[i],temp[i+1]);
			if(key){
				switch(step){
				case 0:
					if(cha==13&&CharOP.readUnicode(temp[i+2],temp[i+3])==10){
						int test=CharOP.getInt();
						if(test==num){
							i+=22;
							step=1;
						}
						else{
							CharOP.clear();
							key=false;
						}
					}
					else{
						CharOP.record(cha);
					}
					break;
				case 1:
					if(cha==13&&CharOP.readUnicode(temp[i+2],temp[i+3])==10){
						caption=new String(CharOP.getChars());
						settitle(caption);
						i+=18;
						step=2;
					}
					else{
						CharOP.record(cha);
					}
					break;
				case 2:
					if(cha==13&&CharOP.readUnicode(temp[i+2],temp[i+3])==10){
						i+=2;
					}
					else if(cha=='['){
						door=false;
						key=false;
					}
					else{
						if(count<storynum){
							storys[count++]=cha;
						}
						else{
							door=false;
							key=false;
						}
					}
					break;
				}
			}
			if(cha=='='){
				key=true;
				step=0;
			}
			else if(cha=='#'){
				door=false;
				key=false;
			}
			i+=2;
		}
	}
	protected void PrintWord(Graphics g,final char cha[],int sx,int sy,int length,int wspace,int hspace){
		int i=0;
		int col=0;
		int row=0;
		int x=0;
		int y=0;
		while(i<cha.length&&cha[i]!=0){
			x=sx+row*wspace;
			y=sy+col*hspace;
			g.drawChar(cha[i],x,y,0);
			row++;
			if(row>=length){
				row=0;
				col++;
			}
			i++;
		}
	}
	protected void LoadGame(){
		GIB.setClip(0,0,screen_width,screen_height);
		GIB.setColor(160,160,147);
		GIB.fillRect(0,0,176,208);
		if(step_Load>9){
			Font_middle(GIB,222,222,222);
			GIB.drawString(getString(9),54,170,0);
		}
		GIB.setColor(222,222,222);
		GIB.fillRect(38,15,100,20);
		GIB.fillRect(20,45,134,120);
		Font_big(GIB,60,60,60);
		GIB.drawString(caption,38,15,0);
		Font_middle(GIB,60,60,60);
		PrintWord(GIB,storys,25,46,10,12,12);
		GIB.setColor(255,255,255);
		GIB.fillRect(32,185,110,6);
		GIB.setColor(109,173,231);
		GIB.setClip(32,185,(step_Load*110)/10,6);
		GIB.fillRect(32,185,110,10);
		Loading();
	}
	protected void control_LoadGame(int i){
		if(step_Load>9&&i!=0){
			pressed_Button(5,0);
		}
	}
	protected void Loading(){
		switch(step_Load){
		case 0:
			LoadStory(Level);
			prepare_background();
			break;
		case 1:
			LoadCreatureImage();
			break;
		case 2:
			LoadGroundImage();
			break;
		case 3:
			LoadGameAction();
			break;
		case 4:
			perpare_Damages();
			break;
		case 5:
			LoadMap();
			break;
		case 6:
//			prepare_AI();
			break;
		case 7:
			perpare_player();
			break;
		case 8:
//			perpare_Judge();
			break;
		case 9:
			perpare_Screen();
			break;
		}
		if(step_Load<=9){
			++step_Load;
		}
	}
//  TODO Player
	protected String title=null;
	protected int ttime=4000;
	protected int tcount=0;
	protected int back_Block=20;
	protected int front_Block=2620;
	protected Creature aim=null;
	protected Creature player=null;
	public int player_x=0;
	public int player_y=0;
	public int player_step=0;
	public int totalhp=0;
	protected void perpare_player(){
		setCreToPlayer(findCreature(0));
	}
	public void setCreToPlayer(Creature cre){
		if(cre!=null){
			player=cre;
			player_x=player.x;
			player_y=player.y;
			player_step=player.step;
			totalhp=cre.hp;
		}
	}
	protected void gameface(){
		if(tcount<ttime){
			GIB.setClip(0,0,176,208);
			GIB.setColor(222,222,222);
			GIB.fillRect(38,55,100,20);
			Font_big(GIB,62,62,62);
			GIB.drawString(title,40,56,0);
			tcount+=getdelay();
		}
		drawsys(300000,10,18);
		GIB.setClip(0,0,176,208);
		GIB.setColor(222,222,222);
		GIB.fillRect(22,6,60,8);
		GIB.fillRect(0,180,176,28);
		if(player!=null){
			int set=player.hp*10/totalhp;
			if(set>7){
				GIB.setColor(0,255,0);
			}
			else if(3<=set&&set<=7){
				GIB.setColor(255,255,0);
			}
			else if(set<3){
				GIB.setColor(255,0,0);	
			}
			GIB.fillRect(22,6,player.hp*60/totalhp,8);
		}
	}
	protected void perform_player(){
		gameface();
		if(player!=null&&player.hp>0){
			player_x=player.x;
			player_y=player.y;
			player_step=player.step;
		}
		else{
			pressed_Button(10,0);
		}
	}
	protected void control_player(int i){
		if(keyIs(i,RSB_G)){
			pressed_Button(10,0);
		}
		if(player!=null&&player.hp>0){
			if(keyIs(i,UP_G)){
				player.jump();
			}
			if(keyIs(i,DOWN_G)){
				
			}	
			if(keyIs(i,LEFT_G)){
				player.moveback();
			}
			else if(keyIs(i,RIGHT_G)){
				player.movefront();
			}
			else{
				player.stopMove();
			}
			if(keyIs(i,FIRE_G)){
				player.UseSkill(1);
			}
			if(keyIs(i,JUMP_G)){
				
			}
		}
		
	}
//  TODO Object
	public static int aispace=200;
	public int aicount=aispace;
	public static int groundspace=88;
	public static int groundtotal=2640;
	public static Ground Grounds[]=new Ground[groundtotal/groundspace];
	public static Creature Creatures[]=new Creature[groundtotal/groundspace];
	protected void release_Object(){
		for(int i=0;i<groundtotal/groundspace;++i){
			Grounds[i]=null;
			Creatures[i]=null;
		}
	}
	protected Creature findCreature(int id){
		Creature ptr=null;
		for(int i=0;i<groundtotal/groundspace;++i){
			ptr=Creatures[i];
			while(ptr!=null){
				if(ptr.sysid==id){
					return ptr;
				}
				ptr=ptr.next;
			}
		}
		System.out.println("Creature not found");
		return null;
	}
	//BUG
	protected void perform_Object(){
		int i=player.x/groundspace;
		checkObject(i,5);
		objLife(i,5);
		objAI(i,5);
		drawObject(i,5);
		
	}
	
	protected void objAI(int i,int n){
		aicount+=getdelay();
		if(aicount>=aispace){
			aicount=0;
			int s=i-(n-1)/2;
			int num=s+n;
			for(;s<num;s++){
				if(0<=s&&s<groundtotal/groundspace){
					GroundAI(s);
					CreatureAI(s);
				}
			}
		}
	}
	protected void GroundAI(int num){
		Ground ptr=null;
		ptr=Grounds[num];
		while(ptr!=null){
			if(ptr.ai!=null){
				ptr.ai.run();
			}
			ptr=ptr.next;
		}
	}
	protected void CreatureAI(int num){
		Creature ptr=null;
		ptr=Creatures[num];
		while(ptr!=null){
			if(ptr.ai!=null){
				ptr.ai.run();
			}
			ptr=ptr.next;
		}
	}
	protected void checkObject(int i,int n){
		int s=i-(n-1)/2;
		int num=s+n;
		for(;s<num;s++){
			if(0<=s&&s<groundtotal/groundspace){
				checkSpaceGround(s);
				checkSpaceCreature(s);
			}
		}
	}
	protected void drawObject(int i,int n){
		int s=i-(n-1)/2;
		int num=s+n;
		for(;s<num;s++){
			if(0<=s&&s<groundtotal/groundspace){
				drawSpaceGround(s);
			}
			GIB.setColor(255,0,0);
			GIB.fillRect(s*groundspace-screenx,0,1,208);
		}
		s=i-(n-1)/2;
		num=s+n;
		for(;s<num;s++){
			if(0<=s&&s<groundtotal/groundspace){
				drawSpaceCreature(s);
			}
		}
	}
	public void objLife(int i,int n){
		int s=i-(n-1)/2;
		int num=s+n;
		for(;s<num;s++){
			if(0<=s&&s<groundtotal/groundspace){
				GroundLife(s);
				CreatureLife(s);
			}
		}
	}
	public void GroundLife(int num){
		Ground ptr=null;
		ptr=Grounds[num];
		while(ptr!=null){
			ptr.lifeCycle();
			ptr=ptr.next;
		}
	}
	public void CreatureLife(int num){
		Creature ptr=null;
		ptr=Creatures[num];
		while(ptr!=null){
			ptr.lifeCycle(back_Block,front_Block);
			ptr=ptr.next;
		}
	}
	protected void checkSpaceGround(int num){
		Ground ptr=null;
		ptr=Grounds[num];
		while(ptr!=null){
			if(ptr.objLive==false){
				ptr=removeGround(num,ptr);
			}
			else{
				int newnum=ptr.x/groundspace;
				if(newnum!=num){
					if(0<=newnum&&newnum<groundtotal/groundspace){
						Ground temp=ptr;
						ptr=removeGround(num,ptr);
						addGround(temp);
					}
					else{
						removeGround(num,ptr);
					}
				}
				else{
					ptr=ptr.next;
				}
			}
		}
	}
	Creature temp=null;
	protected void checkSpaceCreature(int num){
		Creature ptr=null;
		ptr=Creatures[num];
		while(ptr!=null){
			if(ptr.objLive==false){
				ptr=removeCreature(num,ptr);
			}
			else{
				int newnum=ptr.x/groundspace;
				if(newnum!=num){
					if(0<=newnum&&newnum<groundtotal/groundspace){
						temp=ptr;
						ptr=removeCreature(num,ptr);
						addCreature(temp);
						checkMoveState(temp,3);
					}
					else{
						ptr=removeCreature(num,ptr);
					}
				}
				else{
					checkMoveState(ptr,3);
					ptr=ptr.next;
				}
			
			}
		}
	}
	protected void checkMoveState(final Creature cre,int n){
		int s=cre.x/groundspace-(n-1)/2;
		int num=s+n;
		int y=0;
		Ground ptr=null;
		boolean GroundTouch=false;
		boolean leftTouch=false;
		boolean rightTouch=false;
		for(;s<num;s++){
			if(0<=s&&s<groundtotal/groundspace){
				ptr=Grounds[s];
				while(ptr!=null){
//					�ж���
					if((ptr.x-ptr.width/2)<cre.x-1&&cre.x-1<(ptr.x+ptr.width/2)||(ptr.x-ptr.width/2)<cre.x+1&&cre.x+1<(ptr.x+ptr.width/2)){
						y=ptr.y-ptr.height;
						if(cre.y>=y&&cre.y<=ptr.y){
							cre.y=y;
							GroundTouch=true;
							if(!cre.ifOnGround()){
								cre.OnGround();
								cre.stopFall();
								cre.stopMove();
							}
						}
					}
					int gty=ptr.y-ptr.height;
					int gby=ptr.y;
					int cty=cre.y-cre.height;
					int cby=cre.y;
					if((cty<gty&&gty<cby)||(cty<gby&&gby<cby)||(gty<cby&&cby<gby)||(gty<cty&&cty<gby)){
						//�ж���
						if((cre.x-cre.width/2)<ptr.x+ptr.width/2&&cre.x>ptr.x){
							cre.x=ptr.x+ptr.width/2+cre.width/2;
							leftTouch=true;
						}
						//�ж���
						if((cre.x+cre.width/2)>ptr.x-ptr.width/2&&cre.x<ptr.x){
							cre.x=ptr.x-ptr.width/2-cre.width/2;
							rightTouch=true;
						}
					}
					ptr=ptr.next;
				}
			}
		}
		if(!GroundTouch){
			cre.LeaveGround();
			cre.increaseFallSpeed(50);
		}
		if(leftTouch){
			cre.CantLeft();
		}
		else{
			cre.CanLeft();
		}
		if(rightTouch){
			cre.CantRight();
		}
		else{
			cre.CanRight();
		}
		if(cre.y>220){
			cre.hp=0;
		}
	}
	protected void drawSpaceGround(int num){
		Ground ptr=null;
		ptr=Grounds[num];
		while(ptr!=null){
			if(ptr.mapid!=0){
				drawgame(ptr.mapid,ptr.x,ptr.y);
				//TODO test
				//
				//
				//
				GIB.setClip(0,0,176,208);
				GIB.setColor(0,0,255);
				GIB.drawRect(ptr.x-ptr.width/2-screenx+1,ptr.y-ptr.height,ptr.width,ptr.height);
			}
			ptr=ptr.next;
		}
	}
	protected void drawSpaceCreature(int num){
		Creature ptr=null;
		ptr=Creatures[num];
		while(ptr!=null){
			if(ptr.mapid!=0){
				drawgame(ptr.getMapID(),ptr.x,ptr.y);
//				TODO test
				//
				//
				//
				GIB.setClip(0,0,176,208);
				GIB.setColor(0,0,255);
				GIB.drawRect(ptr.x-ptr.width/2-screenx+1,ptr.y-ptr.height,ptr.width,ptr.height);
			}
			ptr=ptr.next;
		}
	}
	//TODO LoadMap
	protected void LoadMap(){
		switch(Level){
		case 0:
			LoadMap("map0");
			break;
		case 1:
			LoadMap("map1");
			break;
		case 2:
			LoadMap("map2");
			break;
		}
	}

	protected Ground findGround(Ground gtemp[],int type){
		if(gtemp!=null){
			for(int i=0;i<gtemp.length;++i){
				if(gtemp[i].type==type){
					return gtemp[i];
				}
			}
			return gtemp[0];
		}
		else{
			System.out.println("none");
			return null;
		}
	}
	protected Creature findCreature(Creature gtemp[],int type){
		if(gtemp!=null){
			for(int i=0;i<gtemp.length;++i){
				if(gtemp[i].type==type){
					return gtemp[i];
				}
			}
			return gtemp[0];
		}
		else{
			return gtemp[0];
		}
	}
	protected Ground groundtemp[];
	protected Creature creaturetemp[];
	protected byte Btemp[];
	protected byte Ctemp[];
	protected byte map[];
	protected int i_load;
	protected void LoadMap(String name){
		Btemp=readFile(objectpath,"ground");
		LoadGroundObjInfo(Btemp);
		Ctemp=readFile(objectpath,"creature");
		LoadCreaturObjInfo(Ctemp);
		Btemp=null;
		Ctemp=null;
		i_load=0;
		map=readFile(mappath,name);
		LoadBackGround();
		LoadGround();
		LoadCreature();
		map=null;
	}
	protected void LoadBackGround(){
		CharOP.clear();
		char cha=0;
		boolean key=true;
		while(key){
			cha=CharOP.readUnicode(map[i_load],map[i_load+1]);
			if(cha=='['){
				CharOP.record(cha);
				while(true){
					i_load+=2;
					cha=CharOP.readUnicode(map[i_load],map[i_load+1]);
					CharOP.record(cha);
					if(CharOP.ifrecordis("[map]")){
						i_load+=4;
						key=false;
						break;
					}
				}
			}
			i_load+=2;
		}
		CharOP.clear();
		key=false;
		while(true){
			cha=CharOP.readUnicode(map[i_load],map[i_load+1]);
			if(i_load<map.length-1&&cha==13&&CharOP.readUnicode(map[i_load+2],map[i_load+3])==10){
				i_load+=2;
				key=true;
			}
			if(CharOP.ifrecordis("[end]")){
				i_load+=2;
				break;
			}
			if(key==true){
				try {
					background=Image.createImage(pngpath+new String(CharOP.getChars())+".png");
				} catch (IOException e) {
					e.printStackTrace();
				}
				key=false;
			}
			else{
				CharOP.record(cha);
			}
			i_load+=2;
		}
	}
	protected void LoadGround(){
		CharOP.clear();
		char cha=0;
		boolean key=true;
		while(key){
			cha=CharOP.readUnicode(map[i_load],map[i_load+1]);
			if(cha=='['){
				CharOP.record(cha);
				while(true){
					i_load+=2;
					cha=CharOP.readUnicode(map[i_load],map[i_load+1]);
					CharOP.record(cha);
					if(CharOP.ifrecordis("[ground]")){
						i_load+=4;
						key=false;
						break;
					}
				}
			}
			i_load+=2;
		}
		CharOP.clear();
		int step=-1;
		Ground temp=null;
		Ground module=null;
		key=false;
		while(true){
			cha=CharOP.readUnicode(map[i_load],map[i_load+1]);
			if(cha==32){
				step++;
				key=true;
			}
			if(i_load<map.length-1&&cha==13&&CharOP.readUnicode(map[i_load+2],map[i_load+3])==10){
				step++;
				i_load+=2;
				key=true;
			}
			if(CharOP.ifrecordis("[end]")){
				i_load+=2;
				break;
			}
			if(key==true){
				switch(step){
				case 0:
					temp=new Ground();
					temp.objLive=true;
					temp.sysid=CharOP.getInt();
					break;
				case 1:
					temp.type=CharOP.getInt();
					module=findGround(groundtemp,temp.type);
					temp.width=module.width;
					temp.height=module.height;
					break;
				case 2:
					temp.x=CharOP.getInt();
					break;
				case 3:
					temp.y=CharOP.getInt();
					break;
				case 4:
					temp.AI=CharOP.getInt();
					temp.ai=Grobehavior.CBehavior(temp,temp.AI);
					temp.setMapID();
					addGround(temp);
					step=-1;
					break;
				}
				key=false;
			}
			else{
				CharOP.record(cha);
			}
			i_load+=2;
		}
	}
	protected void LoadCreature(){
		CharOP.clear();
		char cha=0;
		boolean key=true;
		while(key){
			cha=CharOP.readUnicode(map[i_load],map[i_load+1]);
			if(cha=='['){
				CharOP.record(cha);
				while(true){
					i_load+=2;
					cha=CharOP.readUnicode(map[i_load],map[i_load+1]);
					CharOP.record(cha);
					if(CharOP.ifrecordis("[creature]")){
						i_load+=4;
						key=false;
						break;
					}
				}
			}
			i_load+=2;
		}
		CharOP.clear();
		int step=-1;
		Creature temp=null;
		Creature module=null;
		key=false;
		while(true){
			cha=CharOP.readUnicode(map[i_load],map[i_load+1]);
			if(cha==32){
				
				step++;
				key=true;
			}
			if(i_load<map.length-1&&cha==13&&CharOP.readUnicode(map[i_load+2],map[i_load+3])==10){
				step++;
				i_load+=2;
				key=true;
			}
			if(CharOP.ifrecordis("[end]")){
				i_load+=2;
				break;
			}
			if(key==true){
				switch(step){
				case 0:
					temp=new Creature();
					temp.objLive=true;
					temp.sysid=CharOP.getInt();
					break;
				case 1:
					temp.type=CharOP.getInt();
					module=findCreature(creaturetemp,temp.type);
					temp.width=module.width;
					temp.height=module.height;
					temp.step=module.step;
					temp.ActionSpeed=Creature.ckeckSpeed(module.ActionSpeed);
					temp.JumpSpeed=module.JumpSpeed;
					temp.hp=module.hp;
					temp.damage=module.damage;
					temp.sk[0].id=module.sk[0].id;
					temp.sk[0].cool=module.sk[0].cool;
					temp.sk[1].id=module.sk[1].id;
					temp.sk[1].cool=module.sk[1].cool;
					temp.sk[2].id=module.sk[2].id;
					temp.sk[2].cool=module.sk[2].cool;
					break;
				case 2:
					temp.x=CharOP.getInt();
					break;
				case 3:
					temp.y=CharOP.getInt();
					break;
				case 4:
					temp.AI=(byte)CharOP.getInt();
					temp.ai=Crebehavior.CBehavior(temp,temp.AI);
					break;
				case 5:
					temp.side=(byte)CharOP.getInt();
					if(0<temp.x&&temp.x<groundtotal){
						addCreature(temp);
					}
					else{
						System.out.println("out of screen");
					}
					step=-1;
					break;
				}
				key=false;
			}
			else{
				CharOP.record(cha);
			}
			i_load+=2;
		}
	}
	protected void LoadGroundObjInfo(final byte Btemp[]){
		int i=12;
		char cha=0;
		cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
		while(true){
			if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
				i+=4;
				break;
			}
			i+=2;
			CharOP.record(cha);
			cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
		}
		groundtemp=new Ground[CharOP.getInt()];
		int scount=-1;
		int count=0;
		boolean key=false;
		for(;i<Btemp.length-1;i+=2){
			cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
			if(cha==32){
				scount++;
				key=true;
			}
			else if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
				scount++;
				i+=2;
				key=true;
			}
			else if(cha==35){
				break;
			}
			if(key==true){
				switch(scount){
				case 0:
					groundtemp[count]=new Ground();
					groundtemp[count].type=CharOP.getInt();
					break;
				case 1:
					groundtemp[count].width=CharOP.getInt();
					break;
				case 2:
					groundtemp[count].height=CharOP.getInt();
					scount=-1;
					count++;
					break;
				}
				key=false;
			}
			else{
				CharOP.record(cha);
			}
		}
	}
	protected void LoadCreaturObjInfo(final byte Btemp[]){
		String Cname="[";
		String type="����";
		String width="��";
		String height="��";
		String step="����";
		String speed="�ƶ��ٶ�";
		String jumpspeed="���ٶ�";
		String life="����";
		String damage="�˺�";
		String skill1="����1";
		String skill2="����2";
		String skill3="����3";
		int st=0;
		int count=-1;
		boolean key=false;
		boolean minekey=true;
		int i=12;
		char cha=0;
		cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
		while(true){
			if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
				i+=4;
				break;
			}
			i+=2;
			CharOP.record(cha);
			cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
		}
		int num=CharOP.getInt();
		creaturetemp=new Creature[num];
		while(minekey){
			if(key==true){
				cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
				switch(st){
				case 1:
					if(cha==']'){
						creaturetemp[count]=new Creature();
						CharOP.getChars();
						i+=6;
						key=false;
					}
					break;
				case 2:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						creaturetemp[count].type=CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 3:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						creaturetemp[count].width=(byte)CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 4:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						creaturetemp[count].height=(byte)CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 5:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						creaturetemp[count].step=(byte)CharOP.getInt();
						
						i+=4;
						key=false;
					}
					break;
				case 6:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						creaturetemp[count].ActionSpeed=CharOP.getInt();
						
						i+=4;
						key=false;
					}
					break;
				case 7:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						creaturetemp[count].JumpSpeed=CharOP.getInt();
						i+=4;
						key=false;
					}	
					break;
				case 8:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						creaturetemp[count].hp=CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 9:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						creaturetemp[count].damage=CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 10:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						creaturetemp[count].sk[0].id=CharOP.getInt();
						creaturetemp[count].sk[0].cool=damageinfos[creaturetemp[count].sk[0].id].cooldown;
						i+=4;
						key=false;
					}
					break;
				case 11:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						creaturetemp[count].sk[1].id=CharOP.getInt();
						creaturetemp[count].sk[1].cool=damageinfos[creaturetemp[count].sk[1].id].cooldown;
						i+=4;
						key=false;
					}
					break;
				case 12:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						creaturetemp[count].sk[2].id=CharOP.getInt();
						creaturetemp[count].sk[2].cool=damageinfos[creaturetemp[count].sk[2].id].cooldown;
						i+=4;
						key=false;
					}
					break;
				}
				if(key==true){
					CharOP.record(cha);
					i+=2;
				}
			}
			else{
				cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
				if(cha=='#'){
					minekey=false;
					break;
				}
				if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
					i+=4;
					continue;
				}
				else{
					CharOP.record(cha);
				}
				i+=2;
			}
			if(CharOP.ifrecordis(Cname)){
					CharOP.clear();
					count++;
					st=1;
					key=true;
			}
			else if(CharOP.ifrecordis(type)){
				CharOP.clear();
				i+=2;
				st=2;
				key=true;
				
			}
			else if(CharOP.ifrecordis(width)){
				CharOP.clear();
				i+=2;
				st=3;
				key=true;
			}
			else if(CharOP.ifrecordis(height)){
				CharOP.clear();
				i+=2;
				st=4;
				key=true;
			}
			else if(CharOP.ifrecordis(step)){
				CharOP.clear();
				i+=2;
				st=5;
				key=true;
			}
			else if(CharOP.ifrecordis(speed)){
				CharOP.clear();
				i+=2;
				st=6;
				key=true;
			}
			else if(CharOP.ifrecordis(jumpspeed)){
				CharOP.clear();
				i+=2;
				st=7;
				key=true;
			}
			else if(CharOP.ifrecordis(life)){
				CharOP.clear();
				i+=2;
				st=8;
				key=true;
			}
			else if(CharOP.ifrecordis(damage)){
				CharOP.clear();
				i+=2;
				st=9;
				key=true;
			}
			else if(CharOP.ifrecordis(skill1)){
				CharOP.clear();
				i+=2;
				st=10;
				key=true;
			}
			else if(CharOP.ifrecordis(skill2)){
				CharOP.clear();
				i+=2;
				st=11;
				key=true;
			}
			else if(CharOP.ifrecordis(skill3)){
				CharOP.clear();
				i+=2;
				st=12;
				key=true;
			}
		}
	}
	protected Creature ctemp=null;
	protected Creature cparent=null;
	protected void addCreature(Creature ctu){
		int tilenum=ctu.x/groundspace;
		if(Creatures[tilenum]==null){
			Creatures[tilenum]=ctu;
		}
		else{
			ctemp=Creatures[tilenum];
			Creatures[tilenum]=ctu;
			ctu.next=ctemp;
		}
	}
	protected Creature removeCreature(int i,Creature ctu){
		if(Creatures[i]==ctu){
			Creatures[i]=Creatures[i].next;
			ctu.next=null;
			return null;
		}
		else{
			cparent=null;
			ctemp=null;
			cparent=Creatures[i];
			ctemp=cparent.next;
			while(ctemp!=ctu){
				cparent=ctemp;
				ctemp=cparent.next;
			}
			cparent.next=ctemp.next;
			ctemp.next=null;
			return cparent.next;
		}
	}
	Ground gtptr=null;
	Ground gpptr=null;
	protected void addGround(Ground grd){
		int tilenum=grd.x/groundspace;
		if(Grounds[tilenum]==null){
			Grounds[tilenum]=grd;
		}
		else{
			gtptr=Grounds[tilenum];
			Grounds[tilenum]=grd;
			grd.next=gtptr;
		}
	}
	protected Ground removeGround(int i,Ground grd){
		if(Grounds[i]==grd){
			Grounds[i]=Grounds[i].next;
			grd.next=null;
			return null;
		}
		else{
			gpptr=null;
			gtptr=null;
			gpptr=Grounds[i];
			gtptr=gpptr.next;
			while(gtptr!=grd){
				gpptr=gtptr;
				gtptr=gpptr.next;
			}
			gpptr.next=gtptr.next;
			gtptr.next=null;
			return gpptr.next;
		}
	}

//  TODO damage
	protected static DamageInfo damageinfos[]=null;
	protected static DamageInfo damages[]=null;
	protected static byte totalDnum=40;
	protected void perpare_Damages(){
		if(damages==null){
			damages=new DamageInfo[totalDnum];
			for(int i=0;i<totalDnum;++i){
				damages[i]=new DamageInfo();
			}
			for(int i=0;i<20;++i){
				damshow[i]=new StringBuffer();
			}
		}
		else{
			for(int i=0;i<totalDnum;++i){
				damages[i].release();
			}
			for(int i=0;i<20;++i){
				damshow[i].delete(0,10);
				timecount[i]=0;
			}
			return;
		}
		
		String Cname="[";
		String	range="Զ��";
		String	maps="ͼʾ";
		String	xmod="ƫ��X";
		String	ymod="ƫ��Y";
		String	width="��";
		String	height="��";
		String	speedx="�ٶ�X";
		String	speedy="�ٶ�Y";
		String	griv="����";
		String	area="��Χ";
		String  dammul="�˺�����";
		String	contime="����ʱ��";
		String	spatime="���ü��";
		String  cooldown="��ȴʱ��";
		int st=0;
		int count=-1;
		boolean key=false;
		boolean minekey=true;
		int i=12;
		char cha=0;
		Btemp=readFile(objectpath,"damageinfo");
		CharOP.clear();
		cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
		while(true){
			if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
				i+=4;
				break;
			}
			i+=2;
			CharOP.record(cha);
			cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
		}
		int num=CharOP.getInt();
		damageinfos=new DamageInfo[num];
		while(minekey){
			if(key==true){
				cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
				switch(st){
				case 1:
					if(cha==']'){
						damageinfos[count]=new DamageInfo();
						CharOP.getChars();
						i+=6;
						key=false;
					}
					break;
				case 2:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].range=(byte)CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 3:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].mapid=CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 4:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].xmod=(byte)CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 5:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].ymod=(byte)CharOP.getInt();
						
						i+=4;
						key=false;
					}
					break;
				case 6:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].width=(byte)CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 7:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].height=(byte)CharOP.getInt();
						i+=4;
						key=false;
					}	
					break;
				case 8:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].speed_x=CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 9:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].speed_y=CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 10:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].griv=(byte)CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 11:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].area=(byte)CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 12:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].dammul=(byte)CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 13:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].contime=CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 14:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].sptime=CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				case 15:
					if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
						damageinfos[count].cooldown=CharOP.getInt();
						i+=4;
						key=false;
					}
					break;
				}
				if(key==true){
					CharOP.record(cha);
					i+=2;
				}
			}
			else{
				cha=CharOP.readUnicode(Btemp[i],Btemp[i+1]);
				if(cha=='#'){
					minekey=false;
					break;
				}
				if(i<Btemp.length-1&&cha==13&&CharOP.readUnicode(Btemp[i+2],Btemp[i+3])==10){
					i+=4;
					continue;
				}
				else{
					CharOP.record(cha);
				}
				i+=2;
			}
			if(CharOP.ifrecordis(Cname)){
					CharOP.clear();
					count++;
					st=1;
					key=true;
			}
			else if(CharOP.ifrecordis(range)){
				CharOP.clear();
				i+=2;
				st=2;
				key=true;
				
			}
			else if(CharOP.ifrecordis(maps)){
				CharOP.clear();
				i+=2;
				st=3;
				key=true;
			}
			else if(CharOP.ifrecordis(xmod)){
				CharOP.clear();
				i+=2;
				st=4;
				key=true;
			}
			else if(CharOP.ifrecordis(ymod)){
				CharOP.clear();
				i+=2;
				st=5;
				key=true;
			}
			else if(CharOP.ifrecordis(width)){
				CharOP.clear();
				i+=2;
				st=6;
				key=true;
			}
			else if(CharOP.ifrecordis(height)){
				CharOP.clear();
				i+=2;
				st=7;
				key=true;
			}
			else if(CharOP.ifrecordis(speedx)){
				CharOP.clear();
				i+=2;
				st=8;
				key=true;
			}
			else if(CharOP.ifrecordis(speedy)){
				CharOP.clear();
				i+=2;
				st=9;
				key=true;
			}
			else if(CharOP.ifrecordis(griv)){
				CharOP.clear();
				i+=2;
				st=10;
				key=true;
			}
			else if(CharOP.ifrecordis(area)){
				CharOP.clear();
				i+=2;
				st=11;
				key=true;
			}
			else if(CharOP.ifrecordis(dammul)){
				CharOP.clear();
				i+=2;
				st=12;
				key=true;
			}
			else if(CharOP.ifrecordis(contime)){
				CharOP.clear();
				i+=2;
				st=13;
				key=true;
			}
			else if(CharOP.ifrecordis(spatime)){
				CharOP.clear();
				i+=2;
				st=14;
				key=true;
			}
			else if(CharOP.ifrecordis(cooldown)){
				CharOP.clear();
				i+=2;
				st=15;
				key=true;
			}
		}
		Btemp=null;
	}
	public static DamageInfo getFreeD(){
		for(int i=0;i<totalDnum;++i){
			if(damages[i].free){
				return damages[i];
			}
		}
		System.out.println("max damages");
		return null;
	}
	public static void Create(DamageInfo di,int i,Creature cre,int delay){
		if(di!=null&&i<damageinfos.length){
			di.setValue(damageinfos[i],cre,delay);
		}
	}
	public static void createDamage(int type,Creature cre,int delay){
		Create(getFreeD(),type,cre,delay);
	}
	public void damageProcess(){
		for(int i=0;i<totalDnum;++i){
			if(!damages[i].free){
				if(damages[i].x<screenx-20||damages[i].y>screenx+screen_width+20){
					damages[i].release();
					continue;
				}
				if(damages[i].griv==1){
					damages[i].increaseFallSpeed(50);
				}
				drawgame(damages[i].getMapID(),damages[i].x,damages[i].y);
				//TODO test
				//
				//
				//
				GIB.setClip(0,0,176,208);
				GIB.setColor(255,0,0);
				GIB.drawRect(damages[i].x-damages[i].width/2-screenx,damages[i].y-damages[i].height,damages[i].width,damages[i].height);
				damages[i].run(Grounds,Creatures);
			}
		}
	}
	public static int lasttime=500;
	public static StringBuffer damshow[]=new StringBuffer[20];
	public static int damx[]=new int [20];
	public static int damy[]=new int [20];
	public static int timecount[]=new int [20];
	
	public static void damSet(Creature cre,int dam){
		int n=0;
		int num=0;
		for(int i=0;i<20;++i){
			if(timecount[i]==0){
				n=i;
				damx[n]=cre.x-6;
				damy[n]=cre.y-cre.height-14;
				if(dam<0){
					timecount[n]=1;
					damshow[n].append('-');
				}
				else{
					timecount[n]=2;
					damshow[n].append('+');
				}
				dam=Math.abs(dam);
				num=dam/1000;
				dam-=num*1000;
				if(num!=0){
					damshow[n].append((char)(num+48));
				}
				num=dam/100;
				dam-=num*100;
				if(num!=0){
					damshow[n].append((char)(num+48));
				}
				num=dam/10;
				dam-=num*10;
				if(num!=0){
					damshow[n].append((char)(num+48));
				}
				num=dam;
				damshow[n].append((char)(num+48));
				break;
			}
		}
	}
	public void showDam(){
		GIB.setClip(0,0,176,208);
		for(int i=0;i<20;++i){
			if(timecount[i]==0){
				continue;
			}
			else if(timecount[i]==1){
				GIB.setColor(255,0,0);
			}
			else if(timecount[i]==2){
				GIB.setColor(0,255,0);
			}
			else if(timecount[i]>lasttime){
				timecount[i]=0;
				damx[i]=0;
				damy[i]=0;
				damshow[i].delete(0,10);
				continue;
			}
			GIB.drawString(damshow[i].toString(),damx[i]-screenx,damy[i]+screeny,0);
			timecount[i]+=getdelay();
			damy[i]-=1;
		}
	}
	
//	TODO screen
	protected int screenx;
	protected int screeny;	
	protected int screen_width=176;
	protected int screen_height=208;
	protected void perpare_Screen(){
		screenx=player_x-screen_width/2;
		if(screenx<back_Block){
			screenx=back_Block;
		}
		if(screenx+screen_width>front_Block){
			screenx=front_Block-screen_width;
		}
	}
//	TODO background 
	
	protected int mapid[]={3,4,5};
	protected int back_1x;
	protected int back_2x=176;
	protected int back_speed=1;
	protected void prepare_background(){
		back_1x=0;
		back_2x=176;
	}
	protected void settitle(final String str){
		title=new String(str);
		tcount=0;
	}
	protected void perform_background(){
		
		if((player_x>=screenx+screen_width/2+10)&&(screenx+screen_width+back_speed<front_Block)){
			back_moveright();
		}
		if((player_x<=screenx+screen_width/2-10)&&(screenx-back_speed>back_Block)){
			back_moveleft();
		}
		GIB.setClip(0,0,176,208);
		GIB.drawImage(background,back_1x,20,0);
		GIB.drawImage(background,back_2x,20,0);
	}
	protected void back_moveleft(){
		back_1x+=back_speed;
		back_2x+=back_speed;
		screenx-=player_step;
		if(back_1x>=screen_width){
			back_1x=back_1x-2*screen_width;
		}
		if(back_2x>=screen_width){
			back_2x=back_2x-2*screen_width;
		}
	}
	protected void back_moveright(){
		back_1x-=back_speed;
		back_2x-=back_speed;
		screenx+=player_step;
		if(back_1x<=-screen_width){
			back_1x=2*screen_width+back_1x;
		}
		if(back_2x<=-screen_width){
			back_2x=2*screen_width+back_2x;
		}
	}
}
