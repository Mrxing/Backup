package behavior;
//download by http://www.codefans.net
import game.*;
import mid.*;
public abstract class Crebehavior {
	public byte type=0;
	public static Crebehavior CBehavior(Creature cre,int i){
		switch(i){
		case 0:return null;
		case 1:return new Patrol(cre);
		case 2:return new Cannon(cre);
		case 3:return new jump(cre);
		default:System.out.println("cre behavior not math");return null;
		}
	}
	public void run(){
	}
	
}
class Patrol extends Crebehavior{
	protected int leftx=0;
	protected int rightx=0;
	protected int move=60; 
	byte i=0;
	Creature cre=null;
	public Patrol(Creature _cre){
		cre=_cre;
		type=1;
		leftx=cre.x;
		rightx=cre.x+30;
	}
	public void run(){
		if(cre.x<=leftx){
			i=0;
		}
		if(cre.x>=rightx){
			i=1;
		}
		switch(i){
		case 0:cre.movefront();break;
		case 1:cre.moveback();break;
		default:break;
		}
		cre.UseSkill(0);
	}
}

class Cannon extends Crebehavior{
	Creature cre=null;
	int time=800;
	int count=0;
	public Cannon(Creature _cre){
		cre=_cre;
	}
	public void run(){
		count+=WorldCanvas.getdelay()+WorldCanvas.aispace;
		if(count>=time){
			count=0;
			cre.turnback();
			cre.UseSkill(0);
		}
	}
}

class jump extends Crebehavior{
	protected int leftx=0;
	protected int rightx=0;
	protected int move=60; 
	byte i=0;
	Creature cre=null;
	public jump(Creature _cre){
		cre=_cre;
		type=1;
		leftx=cre.x;
		rightx=cre.x+30;
	}
	public void run(){
		if(cre.x<=leftx){
			i=0;
		}
		if(cre.x>=rightx){
			i=1;
		}
		switch(i){
		case 0:cre.movefront();break;
		case 1:cre.moveback();break;
		default:break;
		}
		cre.jump();
		cre.UseSkill(0);
	}
}