package behavior;
//download by http://www.codefans.net
import game.*;
public abstract class Grobehavior {
	protected int type=1;
	public static Grobehavior CBehavior(Ground gro,int i){
		switch(i){
		case 0:return null;
		case 1:return new MoveLR(gro);
		case 2:return new MoveUD(gro);
		case 3:return new MoveRound(gro);
		default:System.out.println("behavior not math");return null;
		}
	}
	public void run(){
		
	}
	public int getType(){
		return type;
	}
	
}
class MoveLR extends Grobehavior{
	protected int leftx;
	protected int rightx;
	Ground gro;
	public MoveLR(Ground _gro){
		gro=_gro;
		type=1;
		leftx=gro.x;
		rightx=gro.x+60;
		gro.moveback();
	}
	public void run(){
		if(gro.x<=leftx){
			gro.movefront();
		}
		if(gro.x>=rightx){
			gro.moveback();
		}
	}
}
class MoveUD extends Grobehavior{
	protected int upy;
	protected int downy;
	Ground gro;
	public MoveUD(Ground _gro){
		gro=_gro;
		type=2;
		downy=gro.y;
		upy=gro.y-30;
		gro.movedown();
	}
	public void run(){
		if(gro.y>=downy){
			gro.moveup();
		}
		if(gro.y<=upy){
			gro.movedown();
		}
	}
}
class MoveRound extends Grobehavior{
	protected int leftx;
	protected int rightx;
	protected int upy;
	protected int downy;
	Ground gro;
	public MoveRound(Ground _gro){
		gro=_gro;
		type=3;
		downy=gro.y+20;
		upy=gro.y-20;
		gro.moveup();
		leftx=gro.x;
		rightx=gro.x+40;
		gro.moveback();
	}
	public void run(){
		if(gro.x<=leftx){
			gro.movefront();
		}
		if(gro.x>=rightx){
			gro.moveback();
		}
		if(gro.y>=downy){
			gro.moveup();
		}
		if(gro.y<=upy){
			gro.movedown();
		}
	}
}