package damage;
//download by http://www.codefans.net
import game.*;
import mid.*;
import tool.*;
public class DamageInfo {
	public final static int MaxSpeed=1000; 
	public boolean free=true;
	public int del=0;
	public int delcount=0;
	public byte direct;
	public byte fall;
	public byte range;//0 �̶��� 1 ���е�
	public int mapid;
	public byte xmod;
	public byte ymod;
	public byte width;
	public byte height;
	public int speed_x;
	public int speed_y;
	public int contspeed_x;
	public int contspeed_y;
	public int cooldown;
	public byte griv;//0��������,1������
	public byte area;//0=���壺1=��Χ;
	public int sptime;
	public int sptcount;
	public int contime=-2;//millisecond:0 ����:-2�ر�;
	public int concount;
	public byte dammul=1;
	public int x=0;
	public int y=0;
	public byte step=4;
	public Creature attacker=null;
	public void run(Ground gro[],Creature cre[]){
		if(delcount<del){
			delcount+=WorldCanvas.getdelay();
			return;
		}
		if(contime==-2){
			release();
		}
		else{
			if(range==0){
				sptcount+=WorldCanvas.getdelay();
				concount+=WorldCanvas.getdelay();
				if(sptcount>=sptime){
					sptcount=0;
					 DE();
				}
				if(concount>=contime){
					concount=0;
					contime=-2;
				}
			}
			else if(range==1){
				move();
				int s=x/WorldCanvas.groundspace-(5-1)/2;
				int num=s+5;
				Creature cptr=null;
				Ground gptr=null;
				for(;s<num;s++){
					if(0<=s&&s<WorldCanvas.groundtotal/WorldCanvas.groundspace){
						cptr=WorldCanvas.Creatures[s];
						gptr=WorldCanvas.Grounds[s];
						while(cptr!=null){
							if(cptr.side!=attacker.side&&Geometry.checkCut(cptr.x-cptr.width/2,cptr.x+cptr.width/2,x-width/2,x+width/2)&&Geometry.checkCut(cptr.y-cptr.height,cptr.y,y-height,y)){
								DE();
								contime=-2;
								return;
							}
							cptr=cptr.next;	
						}
						while(gptr!=null){
							if(Geometry.checkCut(gptr.x-gptr.width/2,gptr.x+gptr.width/2,x-width/2,x+width/2)&&Geometry.checkCut(gptr.y-gptr.height,gptr.y,y-height,y)){
								DE();
								contime=-2;
								return;
							}
							gptr=gptr.next;
						}
					}
				}
			}
		}
	}
	public void DE(){
		int num=x/WorldCanvas.groundspace;
		Creature ptr;
		for(int i=num-1;i<=num+1;++i){
			if(i>=0&&i<WorldCanvas.groundtotal/WorldCanvas.groundspace){
				ptr=WorldCanvas.Creatures[i];
				while(ptr!=null){
					boolean bx= Geometry.checkCut(ptr.x-ptr.width/2,ptr.x+ptr.width/2,x-width/2,x+width/2);
					boolean by= Geometry.checkCut(ptr.y-ptr.height,ptr.y,y-height,y);
					if((ptr.side!=attacker.side)&&bx&&by){
						ptr.direction=(byte)Math.abs(attacker.direction-1);
						ptr.hurt(-attacker.damage*dammul);
						if(area==0){
							return;
						}
					}
					ptr=ptr.next;
				}
			}
		}
	}
	protected void move(){
		if(speed_y!=0){
			contspeed_y+=WorldCanvas.getdelay();
			if(contspeed_y>=(MaxSpeed-speed_y)){
				y+=(fall+fall-1)*step;
				contspeed_y=0;
			}
		}
		if(speed_x!=0){
			contspeed_x+=WorldCanvas.getdelay();
			if(contspeed_x>=(MaxSpeed-speed_x)){
				x+=(direct+direct-1)*step;
				contspeed_x=0;
			}
		}
	}
	public void increaseFallSpeed(int i){
		if(fall==1){
			speed_y+=i;
			if(speed_y<930){
				speed_y=930;
			}
			if(speed_y>MaxSpeed){
				speed_y=MaxSpeed;
			}
		}
		else{
			speed_y-=i;
			if(speed_y<=930){
				speed_y=930;
				fall=1;
			}
		}
	}
	public void setValue(DamageInfo di,final Creature cre,int delay){
		free=false;
		del=delay;
		range=di.range;
		mapid=di.mapid;
		xmod=di.xmod;
		ymod=di.ymod;
		if(di.width==0){
			width=cre.width;
		}
		else{
			width=di.width;
		}
		if(di.height==0){
			height=cre.height;
		}
		else{
			height=di.height;
		}
		speed_x=di.speed_x;
		speed_y=di.speed_y;
		griv=di.griv;
		area=di.area;
		sptime=di.sptime;
		sptcount=di.sptime;
		contime=di.contime;
		direct=cre.direction;
		attacker=cre;
		int sign=(direct+direct-1);
		if(di.xmod==0){
			x=cre.x;
		}
		else{
			x=cre.x+sign*(xmod+cre.width/2);
		}
		if(di.ymod==0){
			y=cre.y;
		}
		else{
			y=cre.y+ymod;
		}
		dammul=di.dammul;
	}
	public void release(){
		free=true;
		del=0;
		delcount=0;
		x=0;
		y=0;
		contime=-2;
		sptime=0;
		sptcount=0;
		mapid=0;
		width=0;
		height=0;
		speed_x=0;
		speed_y=0;
		contspeed_x=0;
		contspeed_y=0;
		fall=0;
		direct=0;
		attacker=null;
	}
	public int getMapID(){
		if(mapid==0){
			return 0;
		}
		return 300000+mapid*1000;
	}
}

