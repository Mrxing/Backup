/*
 * * file name: test.c
 * * purpose: a test program of module ex_04
 * * creator: Allan xing
 * * create time: 2012-09-26
 * */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>

#define TEST_MAGIC 'x'
#define TEST_MAX_NR 2

#define TEST_CLEAR _IO(TEST_MAGIC,1)
#define TEST_OFFSET _IO(TEST_MAGIC,2)

int main(int argc,char** argv)
{
	if(argc<3){
		fprintf(stderr,"Usage:%s\n",strerror(errno));
		exit(0);
	}
	int fd;
	if((fd=open(argv[1],O_RDWR | O_NONBLOCK | O_ASYNC))<0){
		fprintf(stderr,"open file error:%s\n",strerror(errno));
		exit(0);
	}
	write(fd,argv[2],10);
	printf("write: str= %s\n",argv[2]);
	ioctl(fd,TEST_OFFSET,-10);
	char buf[20];
	memset(buf,0,sizeof(buf));
//	lseek(fd,0,SEEK_SET);
	read(fd,buf,10);
	printf("read: %s\n",buf);
	close(fd);
	return 0;
}
