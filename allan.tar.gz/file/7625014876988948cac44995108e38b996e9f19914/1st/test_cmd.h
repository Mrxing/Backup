#ifndef _TEST_CMD_H
#define _TEST_CMD_H

#define TEST_CLEAR		0

#endif /*_TEST_CMD_H*/
