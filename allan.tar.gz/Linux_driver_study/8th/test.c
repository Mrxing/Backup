/*************************************************************************
  > File Name: test.c
  > Author: Allan Xing
  > Mail: xingpeng2010@hotmail.com 
  > Created Time: Wed 02 Jul 2014 02:38:29 PM CST
 ************************************************************************/

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/device.h>
#include <linux/slab.h>
#include "test_cmd.h"

#define DEBUG_SWITCH 1
#if DEBUG_SWITCH
#define P_DEBUG(fmt,args...) printk("<1>" "<kernel>[%s]"fmt,__FUNCTION__,##args);
#else
#define P_DEBUG(fmt,args...) printk("<7>" "<kernel>[%s]"fmt,__FUNCTION__,##args);
#endif

#define DEV_NAME "test"
#define MAX_SIZE 20

struct dev_t {
	unsigned int major;
	unsigned int minor;
	unsigned int cur_size;
	char kbuf[MAX_SIZE];
	dev_t devno;
	struct cdev test_dev;
};

struct dev_t mydev;
struct class* test_class;

static int test_open(struct inode* node, struct file* filp)
{
	struct dev_t* dev;
	dev = container_of(node->i_cdev, struct dev_t, test_dev);
	filp->private_data = dev;
	P_DEBUG("open device!\n");
	return 0;
}

static int test_close(struct inode* node, struct file* filp)
{
	P_DEBUG("close device!\n");
	return 0;
}

static ssize_t test_read(struct file* filp, char __user* buf, size_t count, loff_t* offset)
{
	ssize_t ret = 0;
	struct dev_t* dev = filp->private_data;
	P_DEBUG("read\n");
	if(!dev->cur_size)
	{
		return 0;
	}
	if(*offset >= MAX_SIZE)
	{
		return count ? -ENXIO : 0;
	}
	if(*offset + count > MAX_SIZE)
	{
		count = MAX_SIZE - *offset;
	}
	if(copy_to_user(buf,dev->kbuf + *offset,count))
	{
		P_DEBUG("read error!\n");
		return -EFAULT;
	}
	else
	{
		ret = count;
		dev->cur_size -= count;
		*offset += count;
	}
	P_DEBUG("buf = [%s]\n",buf);
	P_DEBUG("read %d bytes, cur_size [%d]\n",count,dev->cur_size);
	return ret;
}

static ssize_t test_write(struct file* filp, const char __user* buf, size_t count, loff_t* offset)
{
	ssize_t ret = 0;
	struct dev_t* dev = filp->private_data;
	P_DEBUG("write\n");
	if(*offset >= MAX_SIZE)
	{
		return count ? -ENXIO : 0;
	}
	if(*offset + count > MAX_SIZE )
	{
		count = MAX_SIZE - *offset;
	}
	if(copy_from_user(dev->kbuf + *offset, buf, count))
	{
		return -EFAULT;
	}
	else
	{
		ret = count;
		dev->cur_size += count;
		*offset += count;
	}
	P_DEBUG("kbuf = [%s]\n",dev->kbuf);
	P_DEBUG("write %d bytes, cur_size [%d]\n",count,dev->cur_size);
	return ret;
}

static loff_t test_llseek(struct file* filp, loff_t offset, int whence)
{
	loff_t new_pos = 0;
	loff_t old_pos = filp->f_pos;

	if(offset >= MAX_SIZE || offset < 0)
	{
		P_DEBUG("f_pos error!\n");
		return -EINVAL;
	}
	switch(whence)
	{
		case SEEK_SET:
			new_pos = offset;
			P_DEBUG("change offset! SEEK_SET\n");
			break;
		case SEEK_CUR:
			new_pos = old_pos + offset;
			P_DEBUG("change offset! SEEK_CUR\n");
			break;
		case SEEK_END:
			new_pos = MAX_SIZE + offset;
			P_DEBUG("change offset! SEEK_END\n");
			break;
		default:
			P_DEBUG("unkonwn whence!\n");
			break;
	}
	filp->f_pos = new_pos;
	return new_pos;
}

static long test_ioctl(struct file* filp, unsigned int cmd, unsigned long arg)
{
	long ret = 0;
	struct dev_t* dev = filp->private_data;

	struct ioctl_data val;

	if(_IOC_TYPE(cmd) != TEST_MAGIC) return -EINVAL;
	if(_IOC_NR(cmd) > TEST_MAX_NR) return -EINVAL;

	switch(cmd)
	{
		case TEST_OFFSET:
			filp->f_pos += (int)arg;
			P_DEBUG("ioctl change offset\n");
			ret = 0;
			break;
		case TEST_KBUF:
			if(copy_from_user(&val, (struct ioctl_data*)arg, sizeof(struct ioctl_data)))
			{
				return -EINVAL;
				goto RET;
			}
			memset(dev->kbuf, 0, MAX_SIZE);
			memcpy(dev->kbuf, val.buf, val.size);
			dev->cur_size = val.size;
			filp->f_pos = 0;
			P_DEBUG("ioctl change kbuf\n");
			ret = 0;
			break;
		default:
			P_DEBUG("error cmd\n");
			return -EINVAL;
			break;
	}
	return ret;

RET:
	return ret;
}

struct file_operations test_ops = {
	.owner = THIS_MODULE,
	.open = test_open,
	.release = test_close,
	.read = test_read,
	.write = test_write,
	.llseek = test_llseek,
	.unlocked_ioctl = test_ioctl,
};

static void setup_cdev(struct dev_t dev, int index)
{
	int ret = 0;

	cdev_init(&(mydev.test_dev), &test_ops);
	ret = cdev_add(&(mydev.test_dev), mydev.devno, 1);
	if(ret < 0)
	{
		P_DEBUG("add error!\n");
		goto err1;
	}
err1:
	unregister_chrdev_region(mydev.devno, 1);
}

static int __init test_init(void)
{
	int ret = 0;
	if(mydev.major)
	{
		mydev.devno = MKDEV(mydev.major, mydev.minor);
		ret = register_chrdev_region(mydev.devno, 1, DEV_NAME);
	}
	else
	{
		ret = alloc_chrdev_region(&(mydev.devno), mydev.minor, 1, DEV_NAME);
		mydev.major = MAJOR(mydev.devno);
		mydev.minor = MINOR(mydev.devno);
	}
	if(ret < 0)
	{
		P_DEBUG("register devno error!\n");
		goto err0;
	}
/*
	cdev_init(&(mydev.test_dev),&test_ops);
	ret = cdev_add(&(mydev.test_dev),mydev.devno,1);
	if(ret < 0)
	{
		P_DEBUG("add error!\n");
		goto err1;
	}
*/
	setup_cdev(mydev,0);

	test_class = class_create(THIS_MODULE,DEV_NAME);
	device_create(test_class, NULL, mydev.devno, NULL, DEV_NAME);

	printk("major=[%d], minor=[%d]\n", mydev.major, mydev.minor);
	P_DEBUG("hello kernel\n");
	return 0;
err0:
	return ret;
}

static void __exit test_exit(void)
{

	device_destroy(test_class,mydev.devno);
	class_destroy(test_class);

	cdev_del(&(mydev.test_dev));

	unregister_chrdev_region(mydev.devno,1);

	P_DEBUG("goodbye kernel!\n");
}

module_init(test_init);
module_exit(test_exit);

MODULE_LICENSE("GPL");
MODULE_VERSION("1.0");

