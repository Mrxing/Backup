#Linux_driver_study

Ioctl

long (*unlocked_ioctl)(struct file* file, unsigned int cmd, unsigned long arg);


long (*compat_ioctl)(struct file* file, unsigned int cmd, unsigned long arg);
