/*
	Descritpion: improve char dev driver
	Author: Allan
	Date: 06/26

Add: data struct

struct dev_t {
	unsigned int major;//major device number
	unsigned int minor;//minor device number
	dev_t devno;//device number
	char kbuf[MAX_SIZE];//kernel buff 
	unsigned int cur_size;//kernel buff size
	struct cdev char_dev;//device struct
};
*/

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include "test_cmd.h"

#include <linux/wait.h>
#include <linux/sched.h>

//Uncertain parameters definition
#define BUG_SWITCH 0
#if BUG_SWITCH
	#define P_DEBUG(fmt,args...) printk("<1>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#else
	#define P_DEBUG(fmt,args...) printk("<7>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#endif

#define MAX_SIZE 20
#define DEV_NAME "chardev"

struct dev_t{
	unsigned int major;
	unsigned int minor;
	char kbuf[MAX_SIZE];
	unsigned int cur_size;
	dev_t devno;
	struct cdev char_dev;
	wait_queue_head_t test_queue; //等待队列头
};

struct dev_t mydev;
struct class* driver_class;
static int char_open(struct inode* node, struct file* filp)
{
	struct dev_t* dev;
	dev = container_of(node->i_cdev,struct dev_t,char_dev);
	filp->private_data = dev;
	P_DEBUG("open device!\n");
	return 0;
}

static int char_close(struct inode* node, struct file* filp)
{
	P_DEBUG("close device!\n");
	return 0;
}

static ssize_t char_read(struct file* filp, char __user* buf, size_t count, loff_t* offset)
{
	ssize_t ret = 0;
	struct dev_t* dev = filp->private_data;
	if(filp->f_flags && O_NONBLOCK)
	{
		return -EAGAIN;
	}

	P_DEBUG("read data...\n");
	if(wait_event_interruptible(dev->test_queue, dev->cur_size > 0))
	{
		return -ERESTARTSYS;
	}
	if(!dev->cur_size)
	{
		return 0;
	}

	if(*offset >= MAX_SIZE || dev->cur_size == 0)
	{
		return count ? -ENXIO : 0;//ENXIO 越界
	}
	if(count + *offset > MAX_SIZE)
	{
		count = MAX_SIZE - *offset;//decrease read count
	}

	/*休眠*/

	if(copy_to_user(buf,dev->kbuf + *offset,count))
	{
		return -EFAULT;
	}
	else
	{
		ret = count;
		*offset += count;
		dev->cur_size -= count;
	}
	P_DEBUG("buf = [%s]\n",buf);
	P_DEBUG("read %d bytes, cur_size [%d]\n",count,dev->cur_size);
	return ret;
}

static ssize_t char_write(struct file* filp, const char __user* buf, size_t count, loff_t* offset)
{
	ssize_t ret = 0;
	struct dev_t* dev;
	dev = filp->private_data;

	if(*offset >= MAX_SIZE)
	{
		return count ? -ENXIO : 0;
	}
	if(count + *offset > MAX_SIZE)
	{
		count = MAX_SIZE - *offset;
	}

	if(copy_from_user(dev->kbuf + *offset,buf,count))
	{
		return -EFAULT;
	}
	else
	{
		ret = count;
		*offset += count;
		dev->cur_size += count;
	}
	P_DEBUG("kbuf = [%s]\n",dev->kbuf);
	P_DEBUG("write %d bytes, cur_size [%d]\n",count,dev->cur_size);

	/*唤醒*/
	wake_up_interruptible(&dev->test_queue);
	return ret;
}

static loff_t char_lseek(struct file* filp, loff_t offset, int whence)
{
	loff_t new_pos = 0;
	loff_t old_pos = filp->f_pos;

	if(new_pos < 0 || new_pos > MAX_SIZE)
	{
		P_DEBUG("fops error!\n");
		return -EINVAL;
	}
	P_DEBUG("llseek...\n");
	switch(whence){
		case SEEK_SET:
			new_pos = offset;
			break;
		case SEEK_CUR:
			new_pos = old_pos + offset;
			break;
		case SEEK_END:
			new_pos = MAX_SIZE + offset;
			break;
		default:
			printk("unkown whence!\n");
			break;
	}

	filp->f_pos = new_pos;
	return new_pos;
}

static long char_ioctl(struct file* filp, unsigned int cmd, unsigned long arg)
{
	long ret;
	struct dev_t* dev = filp->private_data;
	struct ioctl_data val;

	if(_IOC_TYPE(cmd) != TEST_MAGIC) return -EINVAL;
	if(_IOC_NR(cmd) > TEST_MAX_NR) return -EINVAL;

	switch(cmd){
		case TEST_CLEAR:
			memset(dev->kbuf,0,MAX_SIZE);
			dev->cur_size = 0;
			filp->f_pos = 0;
			P_DEBUG("Clear!\n");
			ret = 0;
			break;
		case TEST_OFFSET:
			filp->f_pos += (int)arg;
			P_DEBUG("change offset!\n");
			ret = 0;
			break;
		case TEST_KBUF:
			if(copy_from_user(&val, (struct ioctl_data*)arg, sizeof(struct ioctl_data)))
			{
				ret = -EFAULT;
				goto RET;
			}
			memset(dev->kbuf, 0, MAX_SIZE);
			memcpy(dev->kbuf, val.buf, val.size);
			dev->cur_size = val.size;
			filp->f_pos = 0;
			P_DEBUG("change kbuf!\n");
			ret = 0;
			break;
		default:
			P_DEBUG("error cmd!\n");
			return -EINVAL;
			break;
	}
	return ret;
RET:
	return ret;
}

struct file_operations char_ops = {
	.open = char_open,
	.release = char_close,
	.read = char_read,
	.write = char_write,
	.llseek = char_lseek,
	.unlocked_ioctl = char_ioctl,
	.owner = THIS_MODULE,
};

static void cdev_setup(struct dev_t dev, int index)
{
	int ret = 0;
	cdev_init(&(mydev.char_dev), &char_ops);
	/*初始化等待队列头*/
	init_waitqueue_head(&mydev.test_queue);

	ret = cdev_add(&(mydev.char_dev), mydev.devno, 1);
	if(ret < 0)
	{
		P_DEBUG("add error!\n");
		goto err1;
	}
err1:
	unregister_chrdev_region(mydev.devno, 1);
}

static int __init chardev_init(void)
{
	int ret = 0;
	if(mydev.major)
	{
		mydev.devno = MKDEV(mydev.major,mydev.minor);
		ret = register_chrdev_region(mydev.devno,1,DEV_NAME);
	}
	else
	{
		ret = alloc_chrdev_region(&(mydev.devno),mydev.minor,1,DEV_NAME);
		mydev.major = MAJOR(mydev.devno);
		mydev.minor = MINOR(mydev.devno);
	}

	if(ret < 0)
	{
		P_DEBUG("register error!\n");
		goto err0;
	}
/*
	cdev_init(&(mydev.char_dev),&char_ops);
	ret = cdev_add(&(mydev.char_dev),mydev.devno,1);
	if(ret < 0)
	{
		P_DEBUG("add dev error!\n");
		goto err1;
	}
*/
	cdev_setup(mydev, 0);
	printk("major = [%d], minor = [%d]\n",mydev.major,mydev.minor);

	driver_class = class_create(THIS_MODULE,DEV_NAME);
	device_create(driver_class, NULL, mydev.devno, NULL, DEV_NAME);

	P_DEBUG("hello kernel!\n");
	return 0;
err0:
	return ret;
}

static void __exit chardev_exit(void)
{
	device_destroy(driver_class,mydev.devno);
	class_destroy(driver_class);

	cdev_del(&(mydev.char_dev));

	unregister_chrdev_region(mydev.devno,1);

	P_DEBUG("goodbye kernel!\n");
}

module_init(chardev_init);
module_exit(chardev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Allan");
MODULE_VERSION("v2.0");
