/*************************************************************************
    > File Name: read.c
    > Author: Allan Xing
    > Mail: xingpeng2010@hotmail.com 
    > Created Time: Fri 04 Jul 2014 06:33:54 PM CST
 ************************************************************************/

#include<stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc, char** argv)
{
	int fd;
	char buf[20];

	if((fd = open("/dev/chardev", O_RDWR)) < 0)
	{
		printf("<read.c> open error!\n");
		return -1;
	}

	read(fd, buf, 10);

	printf("<read.c> buf is [%s]\n", buf);

	close(fd);
	return 0;
}
