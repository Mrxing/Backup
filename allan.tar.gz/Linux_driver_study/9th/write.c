/*************************************************************************
    > File Name: write.c
    > Author: Allan Xing
    > Mail: xingpeng2010@hotmail.com 
    > Created Time: Wed 09 Jul 2014 09:22:19 AM CST
 ************************************************************************/

#include<stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc, char* argv[])
{
	int fd;
	char buf[20];

	if((fd = open("/dev/chardev", O_RDWR)) < 0)
	{
		printf("<write.c> open error!\n");
		return -1;
	}

	write(fd, "<app> tes", 10);
	printf("<write.c> wrtie..\n");

	close(fd);
	return 0;
}
