/*
	#description: a simple driver module use parameters
	#Date:	06/23
	#Author: Allan
*/

#include <linux/module.h>
#include <linux/init.h>

#define DEBUG_SWITCH 0
#if DEBUG_SWITCH
	#define P_DEBUG(fmt,args...) printk("<1>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#else
	#define P_DEBUG(fmt,args...) printk("<7>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#endif

int num = 123;
char *name = "allan";

static int __init hello_init(void)
{
	printk("init module...\n");
	P_DEBUG("num=%d,name:[%s]\n",num,name);
	return 0;
}

static void __exit hello_exit(void)
{
	P_DEBUG("goodbye kernel!\n");
}

module_init(hello_init);
module_exit(hello_exit);

module_param(num,int,0644);
module_param(name,charp,0644);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Allan");
MODULE_VERSION("1.0");

