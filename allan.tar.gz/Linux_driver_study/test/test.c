/*
 *
 * Linux char dirver
 *
 * functions:
 *  open 
 *  close
 *  read
 *  write
 *  lseek
 *  ioctl
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/device.h>

#define DEBUG_SWITCH 0
#if DEBUG_SWITCH
    #define P_DEBUG(fmt,args...) printk("<7>" "<kernel>[%s]"fmt,__FUNCTION__,##args);
#else
    #define P_DEBUG(fmt,args...) printk("<1>" "<kernel>[%s]"fmt,__FUNCTION__,##args);
#endif

#define DEV_NAME "test"
#define MAX_SIZE 20
/*
 * dev struct
 */
struct dev_t {
    unsigned int major;
    unsigned int minor;
    unsigned int cur_size;
    char kbuf[MAX_SIZE];
    struct cdev test_dev;
    dev_t devno;
};

struct dev_t mydev;

struct file_operations test_ops = {
    .owner = THIS_MODULE
};

static int __init test_init(void)
{
    P_DEBUG("hello kernel!\n");
    return 0;
}

static void __exit test_exit(void)
{
    P_DEBUG("Bye kernel!\n");
}

module_init(test_init);
module_exit(test_exit);

MODULE_LICENSE("GPL");
MODULE_VERSION("v1.0");
