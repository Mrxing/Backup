/*
Description: a simple driver example
Date:	2014/06/23
Author: Allan
*/

#include <linux/module.h>
#include <linux/init.h>

#define DEBUG_SWITCH 0
#if DEBUG_SWITCH
	#define P_DEBUG(fmt,args...) printk("<1>" "<kernel>[%s]"fmt,__FUNCTION__,##args);
#else
	#define P_DEBUG(fmt,args...) printk("<7>" "<kernel>[%s]"fmt,__FUNCTION__,##args);
#endif

static int __init hello_init(void)
{
	printk("init driver...\n");
	printk("hello kernel!\n");
	P_DEBUG("hello kernel1!\n");
	return 0;
}

static void __exit hello_exit(void)
{
	printk("goodbye kernel!\n");
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Allan");
MODULE_VERSION("1.0");
