/*
	#description: a app to test char device function
	#Date: 06/25
	#Author: Allan

#solution:
	1, open : fd = open(/dev/char_dev,o_RDWR);
	2, close : close(fd);
*/

#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define debug(fmt,args...) printf("[%s][%d]"fmt,__FUNCTION__,__LINE__,##args);

int main(int argc, char** argv)
{
	int fd,count;
	char buf[20];
	if((fd = open("/dev/chardev",O_RDWR)) < 0)
	{
		printf("fd = %d\n",fd);
		debug("open device error!\n");
		return fd;
	}
	debug("open device success!\n");

	count = read(fd,buf,20);
	if(count == -1)
	{
		debug("read error\n");
	}
	debug("buf = [%s]\n",buf);

	count = write(fd,buf,10);
	
	if(count == -1)
	{
		debug("write error\n");
	}
	close(fd);

	debug("close device success!\n");
	return 0;
}
