/*
	#description: a char device driver has open close read write function
	#Date: 06/26
	#Author: Allan


#solutions:
	1, struct cdev char_dev;
	2, dev_t devno;
	3, struct file_operations char_ops;
	4, register_chrdev_region(devno,1,DEV_NAME);alloc_chrdev_region(&devno,minor,1,DEV_NAME);
	5, cdev_init(&char_dev,&char_ops);
		char_dev.owner = THIS_MODULE;
	6, cdev_add(&char_dev,devno,1);
	7, cdev_del(&char_dev);
	8, unregister_chrdev_region(devno,1);
*/

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>

#define DEBUG_SWITCH 0
#if DEBUG_SWITCH
	#define P_DEBUG(fmt,args...) printk("<1>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#else
	#define P_DEBUG(fmt,args...) printk("<7>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#endif

unsigned int major = 0;
unsigned int minor = 0;

#define DEV_NAME "chardev"

struct cdev char_dev;
dev_t devno;

static int char_open(struct inode* node, struct file* filp)
{
	P_DEBUG("open device!\n");
	return 0;
}

static int char_close(struct inode* node, struct file* filp)
{
	P_DEBUG("close device!\n");
	return 0;
}

static ssize_t char_read(struct file* filp, char __user* buf, size_t count, loff_t* offset)
{
	ssize_t ret = 0;

	if(copy_to_user(buf,"kernel message",count))
	{
		ret = -EFAULT;
	}
	else
	{
		ret = count;
	}
	P_DEBUG("buf = [%s]\n",buf);

	return ret;
}

static ssize_t char_write(struct file* filp, const char __user* buf, size_t count, loff_t* offset)
{
	ssize_t ret = 0;
	char kbuf[20];
	if(copy_from_user(kbuf,buf,count))
	{
		ret = -EFAULT;
	}
	else
	{
		ret = count;
	}
	P_DEBUG("kbuf = [%s]\n",kbuf);
	return ret;
	
}

struct file_operations char_ops = {
	.open = char_open,
	.release = char_close,
	.read = char_read,
	.write = char_write,
	.owner = THIS_MODULE,
};

static int __init chardev_init(void)
{
	int ret = 0;
	if(major)
	{
		devno = MKDEV(major,minor);
		ret = register_chrdev_region(devno,1,DEV_NAME);
	}
	else
	{
		ret = alloc_chrdev_region(&devno,minor,1,DEV_NAME);
		major = MAJOR(devno);
		minor = MINOR(devno);
	}

	if(ret < 0)
	{
		P_DEBUG("register devno error!\n");
		goto err0;
	}
	printk("major = [%d], minor = [%d]\n",major,minor);

	cdev_init(&char_dev,&char_ops);

	ret = cdev_add(&char_dev,devno,1);
	if(ret < 0)
	{
		P_DEBUG("add dev error!\n");
		goto err1;
	}

	P_DEBUG("hello kernel!\n");
	return 0;
err1:
	unregister_chrdev_region(devno,1);
err0:
	return ret;

}

static void __exit chardev_exit(void)
{
	cdev_del(&char_dev);

	unregister_chrdev_region(devno,1);

	P_DEBUG("goodbye kernel!\n");
}

module_init(chardev_init);
module_exit(chardev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Allan");
MODULE_VERSION("v1.2");
