char dev file operations: open write open close
