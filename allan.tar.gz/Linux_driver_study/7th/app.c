/*
	#description: a app to test char device function
	#Date: 06/25
	#Author: Allan

#solution:
	1, open : fd = open(/dev/char_dev,o_RDWR);
	2, close : close(fd);
*/

#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define debug(fmt,args...) printf("[%s][%d]"fmt,__FUNCTION__,__LINE__,##args);


int main(int argc, char** argv)
{
	int fd;
	char buf[20];
	int ret;
	if((fd = open("/dev/test",O_RDWR)) < 0)
	{
		printf("fd = %d\n",fd);
		debug("open device error!\n");
		return fd;
	}
	debug("open device success!\n");
	write(fd, "<app> tes", 10);
	ret = lseek(fd, 0, SEEK_SET);
	read(fd, buf, 10);
	debug("read2: buf = [%s]\n",buf);
	close(fd);

	debug("close device success!\n");
	return 0;
}
