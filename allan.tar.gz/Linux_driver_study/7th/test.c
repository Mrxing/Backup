/*
   a simple char dev driver
   */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>

#define DEBUG_SWITCH 0
#if DEBUG_SWITCH
#define P_DEBUG(fmt,args...) printk("<1>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#else
#define P_DEBUG(fmt,args...) printk("<7>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#endif



#define DEV_NAME "test"
#define MAX_SIZE 20



struct dev_t {
	unsigned int major;		//主设备号
	unsigned int minor;		//次设备号
	unsigned int cur_size;	//内核空间当前大小
	char kbuf[MAX_SIZE];	//内核空间缓冲区
	dev_t devno;			//设备号
	struct cdev test_dev;	//设备
};



struct dev_t mydev;


static int test_open(struct inode* node, struct file* filp)
{
	struct dev_t* dev;
	dev = container_of(node->i_cdev, struct dev_t, test_dev); //将设备结构体私有化，方便后面调用
	filp->private_data = dev;
	P_DEBUG("open device!\n");
	return 0;
}


static int test_close(struct inode* node, struct file* filp)
{
	P_DEBUG("close device!\n");
	return 0;
}

static ssize_t test_read(struct file* filp, char __user* buf, size_t count, loff_t* offset)
{
	ssize_t ret = 0;
	struct dev_t *dev = filp->private_data;
	if (!dev->cur_size)
	{
		return 0;
	}
	if (*offset >= MAX_SIZE)
	{
		return count ? -ENXIO : 0;
	}
	if (*offset + count > MAX_SIZE)
	{
		count = MAX_SIZE - *offset;
	}
	if (copy_to_user(buf, dev->kbuf + *offset, count))
	{
		P_DEBUG("read error!\n");
		return -EFAULT;
	}
	else
	{
		ret = count;
		dev->cur_size -= count;
		*offset += count;
	}
	P_DEBUG("read %d byte from kernel, cur_size=[%d]\n", count, dev->cur_size);
	return ret;
}

static ssize_t test_write(struct file* filp, const char __user* buf, size_t count, loff_t* offset)
{
	ssize_t ret = 0;
	struct dev_t *dev = filp->private_data;
	if (*offset >= MAX_SIZE)
	{
		return count ? -ENXIO : 0;
	}
	if (*offset + count > MAX_SIZE)
	{
		count = MAX_SIZE - *offset;
	}
	if (copy_from_user(dev->kbuf + *offset, buf, count))
	{
		P_DEBUG("write error!\n");
		return -EFAULT;
	}
	else
	{
		ret = count;
		dev->cur_size += count;
		*offset += count;
	}
	P_DEBUG("write %d bytes to user buf, cur_size=[%d]\n", count, dev->cur_size);
	return ret;
}

static loff_t test_llseek(struct file* filp, loff_t offset, int whence)
{
	loff_t new_pos = 0;
	loff_t old_pos = filp->f_pos;
	if (new_pos < 0 || new_pos > MAX_SIZE)
	{
		P_DEBUG("fpos error!\n");
		return -EINVAL;
	}
	switch(whence){
		case SEEK_SET:
			new_pos = offset;
			break;
		case SEEK_CUR:
			new_pos = old_pos + offset;
			break;
		case SEEK_END:
			new_pos = offset + MAX_SIZE;
			break;
		default:
			printk("unknown whence!\n");
			break;
	}
	filp->f_pos = new_pos;
	return new_pos;
}

struct file_operations test_ops = {
	.open = test_open,
	.release = test_close,
	.read = test_read,
	.write = test_write,
	.llseek = test_llseek,
	.owner = THIS_MODULE,
};

static int __init test_init(void)
{
	int ret = 0;
	if (mydev.major)
	{
		mydev.devno = MKDEV(mydev.major,mydev.minor);
		ret = register_chrdev_region(mydev.devno,1,DEV_NAME);
	}
	else
	{
		ret = alloc_chrdev_region(&(mydev.devno),mydev.minor,1,DEV_NAME);
		mydev.major = MAJOR(mydev.devno);
		mydev.minor = MINOR(mydev.devno);
	}

	P_DEBUG("major=[%d], minor=[%d]\n",mydev.major,mydev.minor);
	if (ret < 0)
	{
		P_DEBUG("register devno error!\n");
		goto err0;
	}

	cdev_init(&(mydev.test_dev),&test_ops);
	ret = cdev_add(&(mydev.test_dev),mydev.devno,1);
	if (ret < 0)
	{
		P_DEBUG("add device error!\n");
		goto err1;
	}
	P_DEBUG("hello kernel!\n");
	return 0;
err1:
	unregister_chrdev_region(mydev.devno,1);
err0:
	return ret;
}

static void __exit test_exit(void)
{
	cdev_del(&(mydev.test_dev));
	unregister_chrdev_region(mydev.devno,1);
	P_DEBUG("goodbye kernel!\n");
}

module_init(test_init);
module_exit(test_exit);

MODULE_LICENSE("GPL");
