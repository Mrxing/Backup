/*
	#file:	chardev.c
	#description: this is a simple char device driver
	#Date: 06/24
	#Author: Allan

#solutions:
	1. define device struct: struct cdev char_dev;
	2. define device num: unsigned int major = 0, unsigned int minor = 0;
	3. define device file operations struct
	4. init----
		(1) register device num : register_chrdev_region(devno,counts,dev_name);alloc_chrdev_region(&devno,minor,counts,dev_name);
		(2) init device:	cdev_init(&char_dev,&char_ops);
		(3) add device:	cdev_add(&char_dev,devno,1);
	5.	unregister device
		(1) del device:	cdev_del(&char_dev);
		(2) unregister device:	unregister_chrdev_region(devno,1);
*/

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>

#define DEBUG_SWITCH 0
#if DEBUG_SWITCH
	#define P_DEBUG(fmt,args...) printk("<1>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#else
	#define P_DEBUG(fmt,args...) printk("<7>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#endif

#define DEV_NAME "char_dev"

unsigned int major = 0;
unsigned int minor = 0;

struct cdev char_dev;//device struct
dev_t devno;//device number

struct file_operations char_ops;//device operater struct:open close read write....

static int __init chardev_init(void)
{
	int ret = 0;
	if(major)
	{
			devno = MKDEV(major,minor);
			ret = register_chrdev_region(devno,1,DEV_NAME);//register device number by using static way
	}
	else
	{
			ret = alloc_chrdev_region(&devno,minor,1,DEV_NAME);//register device number by using dynamic way
			major = MAJOR(devno);
			minor = MINOR(devno);
	}

	if(ret < 0)
	{
			P_DEBUG("register devno error!\n");
			goto err0;
	}
	//register device

	cdev_init(&char_dev,&char_ops);//init device
	char_dev.owner = THIS_MODULE;

	ret = cdev_add(&char_dev,devno,1);//add device
	if(ret < 0)
	{
			P_DEBUG("add device error!\n");
			goto err1;
	}

	printk("major= [%d], minor = [%d]\n",major,minor);
	P_DEBUG("hello kernel!\n");
	return 0;
err1:
	unregister_chrdev_region(devno,1);
err0:
	return ret;
}

static void __exit chardev_exit(void)
{
	cdev_del(&char_dev);//delete device

	unregister_chrdev_region(devno,1);//unregister device

	P_DEBUG("goodbye kernel!\n");
}

module_init(chardev_init);
module_exit(chardev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Allan");
MODULE_VERSION("v1.0");

