/*
	#Description: a module depend on another one
	#Date: 06/24
	#Author: Allan
*/

#include <linux/module.h>
#include <linux/init.h>
#include "module1.h"

#define DEBUG_SWITCH 0
#if DEBUG_SWITCH
	#define P_DEBUG(fmt,args...) printk("<1>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#else
	#define P_DEBUG(fmt,args...) printk("<7>""<kernel>[%s]"fmt,__FUNCTION__,##args);
#endif

static int __init module2_init(void)
{
	module1();
	P_DEBUG("I am module2...\n");
	return 0;
}

static void __exit module2_exit(void)
{
	P_DEBUG("goodbye kernel!\n");
}

module_init(module2_init);
module_exit(module2_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Allan");
MODULE_VERSION("1.0");
