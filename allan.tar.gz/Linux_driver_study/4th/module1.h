/*	
	#decription: head file for module1.c
	#date: 06/24
	#Author: Allan
*/

#ifndef __MODULE1_H__
#define __MODULE1_H__

int module1(void);

#endif
