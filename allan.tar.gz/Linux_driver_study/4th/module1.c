/*
	#description: a module of other module depend on
	#Date:	06/24
	#Author: Allan
*/

#include <linux/module.h>
#include <linux/init.h>
#include "module1.h"

int module1(void)
{
	printk("I am module1...\n");
	return 0;
}

EXPORT_SYMBOL(module1);

MODULE_LICENSE("GPL");
